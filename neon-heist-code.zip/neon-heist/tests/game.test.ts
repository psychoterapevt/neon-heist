import { describe, expect, it } from "vitest";
import { GameEngine } from "../src/game/GameEngine";
import { Player } from "../src/game/Player";
import { collides } from "../src/game/CollisionSystem";
import { LaserLow, LaserWall } from "../src/game/Laser";
import { Block } from "../src/game/Enemy";
import type { GestureKind } from "../src/types/gesture";

const STEP = 1000 / 60;
let vt = 0;
const ev = (gesture: GestureKind) => ({ gesture, confidence: 0.9, t: (vt += 500) });

/** A bot that reads the game's own hints and reacts with a human-like delay. */
function playLevel(e: GameEngine, opts: { reactMs?: number; maxMs?: number; skip?: GestureKind[] } = {}) {
  const react = opts.reactMs ?? 450;
  let pendingSince: number | null = null;
  let lastAction = -Infinity;
  for (let t = 0; t < (opts.maxMs ?? 180000); t += STEP) {
    e.update(STEP);
    if (e.state !== "running" && e.state !== "intro") break;
    const h = e.hint;
    if (!h || !h.expected) {
      pendingSince = null;
      continue;
    }
    pendingSince ??= e.clock;
    if (e.clock - pendingSince < react || e.clock - lastAction < 600) continue;
    let g: GestureKind | null = null;
    if (h.expected === "JUMP" && h.urgent) g = "JUMP";
    if (h.expected === "MOVE") g = h.direction === "left" ? "MOVE_LEFT" : "MOVE_RIGHT";
    if (h.expected === "SHIELD") g = "SHIELD";
    if (h.expected === "HACK") g = "HACK";
    if (g && !opts.skip?.includes(g)) {
      e.handleGesture(ev(g));
      lastAction = e.clock;
      pendingSince = null;
    }
  }
}

describe("collisions", () => {
  it("low laser hits a grounded player but not a jumping one", () => {
    const p = new Player();
    expect(collides(new LaserLow(1, 10), p)).toBe(true);
    p.height = 1;
    expect(collides(new LaserLow(1, 10), p)).toBe(false);
  });
  it("laser wall hits only the blocked lanes", () => {
    const p = new Player();
    p.lane = 1;
    p.x = 0;
    expect(collides(new LaserWall(1, 10, [1]), p)).toBe(true);
    expect(collides(new LaserWall(1, 10, [0, 2]), p)).toBe(false);
  });
  it("crate hits in its final lane", () => {
    const p = new Player();
    p.x = -1.6;
    expect(collides(new Block(1, 10, 2, 0), p)).toBe(true);
    expect(collides(new Block(1, 10, 0, 2), p)).toBe(false);
  });
});

describe("full levels with a hint-following player", () => {
  it("all 3 levels can be completed → victory", () => {
    const e = new GameEngine();
    for (let i = 0; i < 3; i++) {
      playLevel(e);
      if (e.state === "levelComplete") e.nextLevel();
    }
    expect(e.state).toBe("victory");
    expect(e.stats.hacks).toBe(1 + 1 + 4);
    expect(e.stats.damageTaken).toBe(0);
    expect(e.score).toBeGreaterThan(2000);
  });

  it("ignoring lasers costs HP and ends in GAME OVER", () => {
    const e = new GameEngine();
    playLevel(e, { skip: ["JUMP", "MOVE_LEFT", "MOVE_RIGHT"] });
    expect(e.state).toBe("gameOver");
    expect(e.hp).toBe(0);
  });

  it("drones hit without a shield and are blocked with one", () => {
    const e = new GameEngine();
    e.startLevel(1);
    playLevel(e, { skip: ["SHIELD"], maxMs: 9000 });
    expect(e.stats.damageTaken).toBeGreaterThanOrEqual(1);
    const f = new GameEngine();
    f.startLevel(1);
    playLevel(f, { maxMs: 9000 });
    expect(f.stats.damageTaken).toBe(0);
    expect(f.stats.obstaclesCleared).toBeGreaterThanOrEqual(1);
  });

  it("the run stops at a terminal until HACK; one hack per terminal", () => {
    const e = new GameEngine();
    playLevel(e, { skip: ["HACK"], maxMs: 60000 });
    expect(e.state).toBe("running");
    expect(e.hint?.expected).toBe("HACK");
    const d = e.distance;
    for (let i = 0; i < 60; i++) e.update(STEP);
    expect(e.distance).toBe(d);
    expect(e.handleGesture(ev("HACK")).applied).toBe(true);
    expect(e.handleGesture(ev("HACK")).applied).toBe(false);
    for (let i = 0; i < 90; i++) e.update(STEP);
    expect(e.state).toBe("levelComplete");
  });

  it("paused engine (tracking lost) freezes the world", () => {
    const e = new GameEngine();
    for (let i = 0; i < 200; i++) e.update(STEP);
    const d = e.distance;
    e.paused = true;
    for (let i = 0; i < 200; i++) e.update(STEP);
    expect(e.distance).toBe(d);
  });

  it("errors cost points and reset the combo; correct gestures raise it", () => {
    const e = new GameEngine();
    for (let i = 0; i < 200; i++) e.update(STEP); // past intro
    e.score = 500;
    for (let i = 0; i < 8; i++) e.handleGesture(ev(i % 2 ? "MOVE_LEFT" : "MOVE_RIGHT"));
    expect(e.combo).toBeGreaterThanOrEqual(3);
    e.handleFailure({ type: "SWIPE_TOO_SHORT", gesture: "MOVE_LEFT", title: "", message: "", severity: "warning", fromAttempt: true }, vt);
    expect(e.combo).toBe(1);
    expect(e.score).toBe(475);
  });
});
