/**
 * Synthetic landmark generator used by unit tests (and by the scripted e2e harness).
 * Produces anatomically plausible 21-point hands and 33-point poses in normalized,
 * mirrored coordinates — so gesture logic can be tested deterministically.
 */
import type { Landmarks, Point } from "../../src/types/vision";

export type FingerState = "extended" | "curled";

export interface HandSpec {
  /** Palm center-ish position (wrist is placed below it). */
  x: number;
  y: number;
  /** Hand size: wrist → middle MCP distance (frame-height units). */
  size?: number;
  fingers?: [FingerState, FingerState, FingerState, FingerState];
  thumb?: "extended" | "tucked";
  /** Spread of fingers: "wide" (open palm) or "together". */
  spread?: "wide" | "together";
  /** Pinch: 0 = thumb/index tips touching, 1 = wide apart. undefined = no pinch pose. */
  pinchGap?: number;
  /** 1 = palm faces camera, → 0 = hand seen edge-on. */
  facing?: number;
  /** Frame aspect (w/h) — x offsets are divided by it so the hand is not stretched. */
  aspect?: number;
}

const rad = (deg: number) => (deg * Math.PI) / 180;
const dirOf = (deg: number): Point => ({ x: Math.sin(rad(deg)), y: -Math.cos(rad(deg)) });
const add = (p: Point, d: Point, k: number): Point => ({ x: p.x + d.x * k, y: p.y + d.y * k });

const MCP_R = [0.95, 1.0, 0.95, 0.88];
const MCP_A = [-16, -3, 9, 20];
const BONES = [
  [0.45, 0.27, 0.22],
  [0.5, 0.3, 0.24],
  [0.46, 0.28, 0.22],
  [0.36, 0.22, 0.2],
];
const WIDE = [-22, -7, 8, 24];
const TOGETHER = [-5, -2, 1, 4];

export function makeHand(spec: HandSpec): Landmarks {
  const S = spec.size ?? 0.12;
  const fingers = spec.fingers ?? ["extended", "extended", "extended", "extended"];
  const spreadAngles = (spec.spread ?? "wide") === "wide" ? WIDE : TOGETHER;
  const wrist: Point = { x: spec.x, y: spec.y + S * 0.55 };
  const pts: Point[] = new Array(21);
  pts[0] = wrist;

  // Thumb chain.
  const cmc = add(wrist, dirOf(-55), S * 0.35);
  if ((spec.thumb ?? "extended") === "extended" && spec.pinchGap === undefined) {
    const mcp = add(cmc, dirOf(-48), S * 0.3);
    const ip = add(mcp, dirOf(-42), S * 0.26);
    pts[1] = cmc;
    pts[2] = mcp;
    pts[3] = ip;
    pts[4] = add(ip, dirOf(-38), S * 0.22);
  } else {
    pts[1] = cmc;
    pts[2] = add(cmc, dirOf(-30), S * 0.25);
    pts[3] = add(pts[2], dirOf(10), S * 0.2);
    pts[4] = add(pts[3], dirOf(40), S * 0.18);
  }

  for (let f = 0; f < 4; f++) {
    const base = 1 + 4 * (f + 1);
    const mcp = add(wrist, dirOf(MCP_A[f]), S * MCP_R[f]);
    const [l1, l2, l3] = BONES[f].map((b) => b * S);
    const d = dirOf(spreadAngles[f]);
    pts[base] = mcp;
    if (fingers[f] === "extended") {
      pts[base + 1] = add(mcp, d, l1);
      pts[base + 2] = add(pts[base + 1], d, l2);
      pts[base + 3] = add(pts[base + 2], d, l3);
    } else {
      // Curled: the finger folds back so the tip rests on the palm.
      pts[base + 1] = add(mcp, d, l1 * 0.55);
      const tip = { x: wrist.x + (mcp.x - wrist.x) * 0.66, y: wrist.y + (mcp.y - wrist.y) * 0.66 };
      pts[base + 2] = { x: (pts[base + 1].x + tip.x) / 2 + d.x * l2 * 0.15, y: (pts[base + 1].y + tip.y) / 2 };
      pts[base + 3] = tip;
    }
  }

  // Pinch: bend the index toward the thumb and bring the tips together.
  if (spec.pinchGap !== undefined) {
    const imcp = pts[5];
    const meet = add(imcp, dirOf(-60), S * 0.42);
    pts[6] = add(imcp, dirOf(-25), S * 0.35);
    pts[7] = add(pts[6], dirOf(-100), S * 0.16);
    pts[8] = meet;
    const gap = spec.pinchGap * S * 0.9;
    pts[4] = add(meet, dirOf(-150), gap + S * 0.02);
    pts[3] = add(pts[4], dirOf(150), S * 0.2);
    pts[2] = add(pts[1], dirOf(-35), S * 0.25);
  }

  // Edge-on rotation: compress X around the wrist.
  const facing = (spec.facing ?? 1) / (spec.aspect ?? 1);
  return pts.map((p) => ({ x: wrist.x + (p.x - wrist.x) * facing, y: p.y, z: 0 }));
}

export const openPalm = (x = 0.5, y = 0.45, extra: Partial<HandSpec> = {}) => makeHand({ x, y, ...extra });

export const relaxedHand = (x = 0.5, y = 0.45) =>
  makeHand({ x, y, fingers: ["extended", "extended", "curled", "curled"], thumb: "tucked", spread: "together" });

export const fist = (x = 0.5, y = 0.45) =>
  makeHand({ x, y, fingers: ["curled", "curled", "curled", "curled"], thumb: "tucked" });

/** 33-point pose, shoulders at y=0.62, wrists placed where given. */
export function makePose(opts: { cx?: number; shoulderY?: number; width?: number; wrists?: Point[] } = {}): Landmarks {
  const cx = opts.cx ?? 0.5;
  const sy = opts.shoulderY ?? 0.62;
  const w = opts.width ?? 0.3;
  const pts: Point[] = Array.from({ length: 33 }, () => ({ x: cx, y: 1.2, visibility: 0.05 }));
  const set = (i: number, x: number, y: number, v = 0.98) => (pts[i] = { x, y, visibility: v });
  set(0, cx, sy - w * 0.9);
  set(1, cx - w * 0.08, sy - w * 0.98);
  set(2, cx - w * 0.12, sy - w * 0.98);
  set(3, cx - w * 0.16, sy - w * 0.98);
  set(4, cx + w * 0.08, sy - w * 0.98);
  set(5, cx + w * 0.12, sy - w * 0.98);
  set(6, cx + w * 0.16, sy - w * 0.98);
  set(7, cx - w * 0.25, sy - w * 0.9);
  set(8, cx + w * 0.25, sy - w * 0.9);
  set(9, cx - w * 0.06, sy - w * 0.75);
  set(10, cx + w * 0.06, sy - w * 0.75);
  set(11, cx - w / 2, sy);
  set(12, cx + w / 2, sy);
  set(13, cx - w * 0.62, sy + w * 0.7, 0.9);
  set(14, cx + w * 0.62, sy + w * 0.7, 0.9);
  const wr = opts.wrists ?? [
    { x: cx - w * 0.6, y: sy + w * 1.3 },
    { x: cx + w * 0.6, y: sy + w * 1.3 },
  ];
  set(15, wr[0].x, wr[0].y, 0.8);
  if (wr[1]) set(16, wr[1].x, wr[1].y, 0.8);
  set(23, cx - w * 0.35, sy + w * 1.7, 0.2);
  set(24, cx + w * 0.35, sy + w * 1.7, 0.2);
  return pts;
}
