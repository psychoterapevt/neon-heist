import { describe, expect, it } from "vitest";
import { calculateAngle, calculateDistance, calculateVelocity } from "../src/utils/math";
import { detectSwipe, type MotionSample } from "../src/gestures/swipeDetector";
import { detectJump, JumpDetector } from "../src/gestures/jumpDetector";
import { detectPinch } from "../src/gestures/pinchDetector";
import { detectOpenPalm } from "../src/gestures/openPalmDetector";
import { classifyError } from "../src/errors/errorEngine";
import { getBestError } from "../src/errors/errorPriority";
import { GestureController } from "../src/gestures/gestureController";
import { isBodyVisible, isHandVisible } from "../src/vision/visibility";
import type { ExpectedAction, GestureError, GestureEvent, SwipeAttempt } from "../src/types/gesture";
import type { Landmarks, Point } from "../src/types/vision";
import { fist, makeHand, makePose, openPalm, relaxedHand } from "./fixtures/handFactory";

const UP: Point[] = [{ x: 0.35, y: 0.12 }, { x: 0.65, y: 0.12 }];
const LOW: Point[] = [{ x: 0.35, y: 0.45 }, { x: 0.65, y: 0.45 }];
const ONE: Point[] = [{ x: 0.35, y: 0.12 }, { x: 0.65, y: 0.95 }];
const DOWN: Point[] = [{ x: 0.3, y: 1.0 }, { x: 0.7, y: 1.0 }];

describe("math", () => {
  it("calculateDistance", () => {
    expect(calculateDistance({ x: 0, y: 0 }, { x: 0.3, y: 0.4 })).toBeCloseTo(0.5, 6);
  });
  it("calculateVelocity = distance / deltaTime", () => {
    const v = calculateVelocity([{ t: 0, x: 0.2, y: 0.5 }, { t: 500, x: 0.4, y: 0.5 }]);
    expect(v.vx).toBeCloseTo(0.4, 6);
    expect(v.speed).toBeCloseTo(0.4, 6);
  });
  it("calculateAngle", () => {
    expect(calculateAngle({ x: 1, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 1 })).toBeCloseTo(90, 4);
    expect(calculateAngle({ x: 1, y: 0 }, { x: 0, y: 0 }, { x: -1, y: 0 })).toBeCloseTo(180, 4);
  });
});

function stroke(x0: number, x1: number, ms: number): MotionSample[] {
  const n = Math.round(ms / 33);
  return Array.from({ length: n + 1 }, (_, i) => ({ t: (ms * i) / n, x: x0 + ((x1 - x0) * i) / n, y: 0.45, score: 0.95 }));
}

describe("detectSwipe", () => {
  it("fast wide stroke → direction", () => {
    expect(detectSwipe(stroke(0.35, 0.6, 300)).direction).toBe("right");
    expect(detectSwipe(stroke(0.6, 0.35, 300)).direction).toBe("left");
  });
  it("too short or too slow → null", () => {
    expect(detectSwipe(stroke(0.45, 0.52, 200)).direction).toBeNull();
    expect(detectSwipe(stroke(0.3, 0.6, 1600)).direction).toBeNull();
  });
});

describe("detectJump", () => {
  it("both wrists above the head → BOTH_UP", () => expect(detectJump(makePose({ wrists: UP })).pose).toBe("BOTH_UP"));
  it("hands raised but not high enough → TOO_LOW", () => expect(detectJump(makePose({ wrists: LOW })).pose).toBe("TOO_LOW"));
  it("one hand → ONE_UP", () => expect(detectJump(makePose({ wrists: ONE })).pose).toBe("ONE_UP"));
  it("hands down → DOWN", () => expect(detectJump(makePose({ wrists: DOWN })).pose).toBe("DOWN"));
  it("missing landmarks → NO_BODY", () => {
    expect(detectJump(null).pose).toBe("NO_BODY");
    const p = makePose({ wrists: UP });
    p[11] = { ...p[11], visibility: 0.1 };
    expect(detectJump(p).pose).toBe("NO_BODY");
  });
  it("a raised wrist the model can't see → HANDS_NOT_VISIBLE", () => {
    const p = makePose({ wrists: UP });
    p[16] = { ...p[16], visibility: 0.05 };
    expect(detectJump(p).pose).toBe("HANDS_NOT_VISIBLE");
  });
  it("JumpDetector: one raise = one jump; re-arms after lowering", () => {
    const d = new JumpDetector();
    const up = detectJump(makePose({ wrists: UP }));
    const down = detectJump(makePose({ wrists: DOWN }));
    let n = 0;
    for (let t = 0; t < 2000; t += 66) if (d.update(up, t).kind === "confirmed") n++;
    expect(n).toBe(1);
    d.update(down, 2100);
    for (let t = 2200; t < 2600; t += 66) if (d.update(up, t).kind === "confirmed") n++;
    expect(n).toBe(2);
  });
  it("a single frame never jumps", () => {
    const d = new JumpDetector();
    expect(d.update(detectJump(makePose({ wrists: UP })), 0).kind).toBe("none");
  });
});

describe("detectPinch / detectOpenPalm", () => {
  it("pinch closed vs open", () => {
    expect(detectPinch(makeHand({ x: 0.5, y: 0.45, pinchGap: 0 })).closed).toBe(true);
    expect(detectPinch(makeHand({ x: 0.5, y: 0.45, pinchGap: 0.9 })).closed).toBe(false);
    expect(detectPinch(fist()).closed).toBe(false);
  });
  it("open palm vs fist / fingers together", () => {
    expect(detectOpenPalm(openPalm()).isOpen).toBe(true);
    expect(detectOpenPalm(fist()).isOpen).toBe(false);
    expect(detectOpenPalm(makeHand({ x: 0.5, y: 0.45, facing: 0.15 })).missing).toContain("PALM_NOT_FACING");
  });
  it("isHandVisible / isBodyVisible", () => {
    expect(isHandVisible(openPalm(), 0.9)).toBe(true);
    expect(isHandVisible(openPalm(), 0.3)).toBe(false);
    expect(isHandVisible(openPalm(1.02, 0.45), 0.9)).toBe(false);
    expect(isBodyVisible(makePose())).toBe(true);
    expect(isBodyVisible(null)).toBe(false);
  });
});

function attempt(p: Partial<SwipeAttempt>): SwipeAttempt {
  return { direction: "right", start: { x: 0.35, y: 0.45 }, end: { x: 0.6, y: 0.45 }, peak: { x: 0.6, y: 0.45 }, dx: 0.25, dy: 0, durationMs: 300, avgSpeed: 0.8, peakSpeed: 1.2, leftFrame: false, meanY: 0.45, meanScore: 0.95, requiredDistance: 0.15, ...p };
}

describe("classifyError", () => {
  it("move: too short / too slow / out of frame", () => {
    expect(getBestError(classifyError({ kind: "swipe", attempt: attempt({ dx: 0.08 }) }))?.message).toBe("Move your hand farther.");
    expect(getBestError(classifyError({ kind: "swipe", attempt: attempt({ durationMs: 1400, avgSpeed: 0.18 }) }))?.message).toBe("Move faster.");
    expect(getBestError(classifyError({ kind: "swipe", attempt: attempt({ leftFrame: true, dx: 0.1 }) }))?.message).toBe("Keep your hand inside the frame.");
    expect(classifyError({ kind: "swipe", attempt: attempt({}) })).toHaveLength(0);
  });
  it("jump: too low / one hand / not visible", () => {
    const m = (w: Point[]) => getBestError(classifyError({ kind: "jump", analysis: detectJump(makePose({ wrists: w })) }))?.message;
    expect(m(LOW)).toBe("Raise both hands higher to jump.");
    expect(m(ONE)).toBe("Raise both hands.");
    const p = makePose({ wrists: UP });
    p[16] = { ...p[16], visibility: 0.05 };
    expect(getBestError(classifyError({ kind: "jump", analysis: detectJump(p) }))?.message).toBe("Move back so both hands are visible.");
  });
  it("jump error carries the ↑↑ visual and the jump line", () => {
    const e = getBestError(classifyError({ kind: "jump", analysis: detectJump(makePose({ wrists: LOW })) }));
    expect(e?.visual?.kind).toBe("jump");
  });
  it("shield: closed hand / not facing / too low", () => {
    const m = (lm: Landmarks, y = 0.45) => getBestError(classifyError({ kind: "palm", analysis: detectOpenPalm(lm), anchor: { x: 0.5, y }, lowLimitY: 0.8, presence: 0.95 }))?.message;
    expect(m(fist())).toBe("Open your hand.");
    expect(m(makeHand({ x: 0.5, y: 0.45, facing: 0.15 }))).toBe("Turn your palm toward the camera.");
    expect(m(openPalm(), 0.9)).toBe("Raise your hand.");
  });
  it("hack: too wide / poorly visible / low confidence", () => {
    const lm = makeHand({ x: 0.5, y: 0.45, pinchGap: 0.45 });
    const base = { kind: "pinch" as const, analysis: detectPinch(lm), presence: 0.95, thumb: lm[4], index: lm[8] };
    expect(getBestError(classifyError({ ...base, reason: "PINCH_TOO_WIDE" }))?.message).toBe("Bring your thumb and index finger closer.");
    expect(getBestError(classifyError({ ...base, reason: "PALM_NOT_FACING" }))?.message).toBe("Turn your hand toward the camera.");
    expect(getBestError(classifyError({ ...base, reason: "PINCH_TOO_WIDE", presence: 0.3 }))?.message).toBe("Hold the pinch for a moment.");
  });
});

/** Controller simulation at 30 fps (pose every 2nd frame). */
class Sim {
  c = new GestureController();
  t = 0;
  n = 0;
  events: GestureEvent[] = [];
  failures: GestureError[] = [];
  last = this.c.process({ t: 0, hands: [], poses: [], brightness: 120, aspect: 1 });
  constructor(expected: ExpectedAction = null) {
    this.c.setContext({ mode: "game", expected });
  }
  step(hand: Landmarks | null, wrists: Point[] = DOWN, presence = 0.95, poseOn = true) {
    this.t += 33;
    this.n++;
    this.last = this.c.process({
      t: this.t,
      hands: hand ? [{ landmarks: hand, score: presence }] : [],
      poses: this.n % 2 === 0 ? (poseOn ? [{ landmarks: makePose({ wrists }) }] : []) : null,
      brightness: 120,
      aspect: 1,
    });
    this.events.push(...this.last.events);
    this.failures.push(...this.last.failures);
  }
  hold(ms: number, hand: () => Landmarks | null, wrists: Point[] = DOWN, presence = 0.95) {
    for (let i = 0; i < ms / 33; i++) this.step(hand(), wrists, presence);
  }
  kinds() {
    return this.events.map((e) => e.gesture);
  }
}

describe("GestureController", () => {
  it("move right → exactly one MOVE_RIGHT", () => {
    const s = new Sim();
    s.hold(500, () => relaxedHand(0.3, 0.45));
    for (let i = 1; i <= 9; i++) s.step(relaxedHand(0.3 + i * 0.035, 0.45));
    s.hold(600, () => relaxedHand(0.62, 0.45));
    expect(s.kinds()).toEqual(["MOVE_RIGHT"]);
  });
  it("too-short move → no action + 'Move your hand farther.'", () => {
    const s = new Sim("MOVE");
    s.hold(500, () => relaxedHand(0.45, 0.45));
    for (let i = 1; i <= 5; i++) s.step(relaxedHand(0.45 + i * 0.018, 0.45));
    s.hold(400, () => relaxedHand(0.54, 0.45));
    expect(s.events).toHaveLength(0);
    expect(s.failures[0]?.message).toBe("Move your hand farther.");
  });
  it("both hands up and held → one JUMP (cooldown until hands come down)", () => {
    const s = new Sim();
    s.hold(300, () => null, DOWN);
    s.hold(1500, () => null, UP);
    expect(s.kinds()).toEqual(["JUMP"]);
    s.hold(300, () => null, DOWN);
    s.hold(500, () => null, UP);
    expect(s.kinds()).toEqual(["JUMP", "JUMP"]);
  });
  it("expected JUMP + hands too low → no jump, 'Raise both hands higher to jump.'", () => {
    const s = new Sim("JUMP");
    s.hold(300, () => null, DOWN);
    s.hold(900, () => null, LOW);
    expect(s.events).toHaveLength(0);
    expect(s.last.snapshot.error?.message).toBe("Raise both hands higher to jump.");
    expect(s.last.snapshot.error?.title).toBe("JUMP NOT READY");
  });
  it("one hand up while a shield is expected does NOT nag about jumping", () => {
    const s = new Sim("SHIELD");
    s.hold(1200, () => null, ONE);
    expect(s.failures.filter((f) => f.gesture === "JUMP")).toHaveLength(0);
  });
  it("pinch held for 2 s → exactly one HACK", () => {
    const s = new Sim("HACK");
    s.hold(300, () => makeHand({ x: 0.5, y: 0.45, pinchGap: 0.9 }));
    s.hold(2000, () => makeHand({ x: 0.5, y: 0.45, pinchGap: 0 }));
    expect(s.kinds()).toEqual(["HACK"]);
  });
  it("low confidence: a pinch with low presence never fires, and is explained", () => {
    const s = new Sim("HACK");
    s.hold(1500, () => makeHand({ x: 0.5, y: 0.45, pinchGap: 0 }), DOWN, 0.4);
    expect(s.events).toHaveLength(0);
    expect(s.last.snapshot.error?.message).toBe("Hold the pinch for a moment.");
  });
  it("open palm → SHIELD; fist while a drone charges → 'Open your hand.'", () => {
    const s = new Sim("SHIELD");
    s.hold(1000, () => fist(0.5, 0.45));
    expect(s.events).toHaveLength(0);
    expect(s.last.snapshot.error?.message).toBe("Open your hand.");
    s.hold(600, () => openPalm(0.5, 0.45));
    expect(s.kinds()).toEqual(["SHIELD"]);
  });
  it("missing landmarks: no body → TRACKING LOST and no gestures", () => {
    const s = new Sim();
    for (let i = 0; i < 40; i++) s.step(makeHand({ x: 0.5, y: 0.45, pinchGap: 0 }), DOWN, 0.95, false);
    expect(s.last.snapshot.tracking).toBe("lost");
    expect(s.events).toHaveLength(0);
  });
  it("two people → 'Only one player should be visible.'", () => {
    const c = new GestureController();
    c.setContext({ mode: "game" });
    let out = c.process({ t: 0, hands: [], poses: [], brightness: 1, aspect: 1 });
    for (let t = 33; t < 1500; t += 33) out = c.process({ t, hands: [], poses: [{ landmarks: makePose({ cx: 0.3 }) }, { landmarks: makePose({ cx: 0.7 }) }], brightness: 120, aspect: 1 });
    expect(out.snapshot.error?.message).toBe("Only one player should be visible.");
  });
});
