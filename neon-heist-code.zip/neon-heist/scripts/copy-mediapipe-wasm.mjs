// Copies the MediaPipe Tasks Vision wasm runtime from node_modules into /public,
// so the app serves it from its own origin (version-matched with the JS package,
// no third-party CDN needed at runtime).
import { cpSync, existsSync, mkdirSync, readdirSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");
const src = join(root, "node_modules", "@mediapipe", "tasks-vision", "wasm");
const dest = join(root, "public", "mediapipe", "wasm");

if (!existsSync(src)) {
  console.warn(
    "[motionos] @mediapipe/tasks-vision/wasm not found — run `npm install`. " +
      "The app will fall back to the jsDelivr CDN for the wasm runtime.",
  );
  process.exit(0);
}

mkdirSync(dest, { recursive: true });
cpSync(src, dest, { recursive: true });
console.log(`[motionos] copied MediaPipe wasm runtime (${readdirSync(dest).length} files) → public/mediapipe/wasm`);
