import type { GestureError, GestureErrorType } from "../types/gesture";

/**
 * When several problems exist at once, only the most fundamental is shown.
 * Root causes first (can't see the player → can't see the hand → shape problems).
 */
export const ERROR_PRIORITY: readonly GestureErrorType[] = [
  "MULTIPLE_PEOPLE",
  "TRACKING_LOST",
  "HANDS_NOT_VISIBLE",
  "HAND_OUT_OF_FRAME",
  "LOW_CONFIDENCE",
  "HAND_POORLY_VISIBLE",
  "PALM_NOT_FACING",
  "HAND_TOO_LOW",
  "ONE_HAND_TOO_LOW",
  "HANDS_TOO_LOW",
  "HAND_NOT_OPEN",
  "WRONG_DIRECTION",
  "SWIPE_TOO_SHORT",
  "SWIPE_TOO_SLOW",
  "PINCH_TOO_WIDE",
  "PINCH_NOT_HELD",
];

export function errorRank(type: GestureErrorType): number {
  const i = ERROR_PRIORITY.indexOf(type);
  return i === -1 ? ERROR_PRIORITY.length : i;
}

/** The single most important error (stable for equal ranks). */
export function getBestError(errors: readonly GestureError[]): GestureError | null {
  let best: GestureError | null = null;
  for (const e of errors) if (!best || errorRank(e.type) < errorRank(best.type)) best = e;
  return best;
}
