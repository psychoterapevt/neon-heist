import type { GestureError, GestureErrorType, GestureKind, SwipeAttempt } from "../types/gesture";
import type { Point } from "../types/vision";
import type { JumpAnalysis } from "../gestures/jumpDetector";
import type { OpenPalmAnalysis } from "../gestures/openPalmDetector";
import type { PinchAnalysis } from "../gestures/pinchDetector";
import { HAND_CFG, PINCH, SWIPE } from "../gestures/gestureConfig";
import { getBestError } from "./errorPriority";

/**
 * ERROR ENGINE
 * Converts measurements from the gesture state machines into ONE concrete,
 * fixable instruction. Never "gesture not recognized".
 *
 *   classifyError(input)  → every cause found (math rules below)
 *   getBestError(errors)  → the one to show (errorPriority.ts)
 *   ErrorTracker          → show / replace / resolve lifecycle
 */
export type ErrorInput =
  | { kind: "swipe"; attempt: SwipeAttempt }
  | { kind: "jump"; analysis: JumpAnalysis }
  | { kind: "palm"; analysis: OpenPalmAnalysis; anchor: Point; lowLimitY: number; presence: number }
  | {
      kind: "pinch";
      reason: "PINCH_TOO_WIDE" | "PINCH_NOT_HELD" | "PALM_NOT_FACING";
      analysis: PinchAnalysis;
      presence: number;
      thumb: Point;
      index: Point;
    };

type Fields = Omit<GestureError, "type" | "gesture" | "severity" | "fromAttempt"> & { severity?: GestureError["severity"] };

function make(type: GestureErrorType, gesture: GestureKind | undefined, f: Fields, fromAttempt = true): GestureError {
  return { type, gesture, severity: f.severity ?? "warning", fromAttempt, ...f };
}

/** MOVE errors. RULES: |dx| < minDistance → SWIPE_TOO_SHORT; speed < min → SWIPE_TOO_SLOW; edge → HAND_OUT_OF_FRAME. */
function classifySwipe(a: SwipeAttempt): GestureError[] {
  const gesture: GestureKind = a.direction === "right" ? "MOVE_RIGHT" : "MOVE_LEFT";
  const title = "MOVE INCOMPLETE";
  const absDx = Math.abs(a.dx);
  const targetX = a.start.x + (a.direction === "right" ? a.requiredDistance : -a.requiredDistance);
  const trajectory = { kind: "trajectory" as const, start: a.start, reached: a.peak, targetX };
  const progress = Math.min(1, absDx / a.requiredDistance);
  const out: GestureError[] = [];
  if (a.leftFrame) {
    out.push(
      make("HAND_OUT_OF_FRAME", gesture, {
        title,
        message: "Keep your hand inside the frame.",
        direction: a.end.x > 0.5 ? "left" : "right",
        visual: { kind: "arrow", from: a.end, direction: a.end.x > 0.5 ? "left" : "right" },
        progress,
      }),
    );
  }
  if (a.meanScore < SWIPE.minScore) {
    out.push(make("LOW_CONFIDENCE", gesture, { title, message: "Keep your palm toward the camera.", visual: { kind: "highlight-hand" } }));
  }
  if (Math.abs(a.dy) > absDx * SWIPE.maxVerticalRatio) {
    out.push(make("WRONG_DIRECTION", gesture, { title, message: "Move sideways, not up or down.", direction: a.direction, visual: trajectory, progress }));
  }
  if (absDx < a.requiredDistance) {
    out.push(make("SWIPE_TOO_SHORT", gesture, { title, message: "Move your hand farther.", direction: a.direction, visual: trajectory, progress }));
  }
  if (a.durationMs > SWIPE.maxDurationMs || a.avgSpeed < SWIPE.minAvgSpeed) {
    out.push(make("SWIPE_TOO_SLOW", gesture, { title, message: "Move faster.", direction: a.direction, visual: trajectory, progress }));
  }
  return out;
}

/** JUMP errors. RULE: both wristY < requiredY (eye line − k·shoulder width). */
function classifyJump(a: JumpAnalysis): GestureError[] {
  const title = "JUMP NOT READY";
  const visual = { kind: "jump" as const, lowWrists: a.lowWrists.length ? a.lowWrists : a.wrists.filter((w): w is Point => !!w && w.y >= a.requiredY), lineY: a.requiredY };
  switch (a.pose) {
    case "HANDS_NOT_VISIBLE":
      return [make("HANDS_NOT_VISIBLE", "JUMP", { title, message: "Move back so both hands are visible.", direction: "down", visual, progress: a.progress })];
    case "ONE_UP":
      return [make("ONE_HAND_TOO_LOW", "JUMP", { title, message: "Raise both hands.", direction: "up", visual, progress: a.progress })];
    case "TOO_LOW":
      return [make("HANDS_TOO_LOW", "JUMP", { title, message: "Raise both hands higher to jump.", direction: "up", visual, progress: a.progress })];
    default:
      return [];
  }
}

/** SHIELD errors. RULES: fingers extended & spread; palm facing ≥ threshold; hand above chest. */
function classifyPalm(i: Extract<ErrorInput, { kind: "palm" }>): GestureError[] {
  const title = "SHIELD NOT READY";
  const out: GestureError[] = [];
  if (i.presence < HAND_CFG.minPresence) out.push(make("LOW_CONFIDENCE", "SHIELD", { title, message: "Hold your hand still toward the camera.", visual: { kind: "highlight-hand" } }));
  if (i.anchor.y > i.lowLimitY) out.push(make("HAND_TOO_LOW", "SHIELD", { title, message: "Raise your hand.", direction: "up", visual: { kind: "arrow", from: i.anchor, direction: "up" } }));
  if (i.analysis.missing.includes("PALM_NOT_FACING")) out.push(make("PALM_NOT_FACING", "SHIELD", { title, message: "Turn your palm toward the camera.", visual: { kind: "highlight-hand" } }));
  if (i.analysis.missing.includes("FINGERS_CURLED") || i.analysis.missing.includes("FINGERS_NOT_SPREAD"))
    out.push(make("HAND_NOT_OPEN", "SHIELD", { title, message: "Open your hand.", visual: { kind: "highlight-hand" }, progress: i.analysis.score }));
  return out;
}

/** HACK errors. RULES: distance(indexTip, thumbTip)/handSize > closeRatio → PINCH_TOO_WIDE; palm edge-on → turn hand. */
function classifyPinch(i: Extract<ErrorInput, { kind: "pinch" }>): GestureError[] {
  const title = "HACK NOT READY";
  const gap = { kind: "pinch-gap" as const, thumb: i.thumb, index: i.index };
  const out: GestureError[] = [];
  if (i.presence < PINCH.minScore) out.push(make("LOW_CONFIDENCE", "HACK", { title, message: "Hold the pinch for a moment.", visual: gap }));
  if (i.reason === "PALM_NOT_FACING" || i.analysis.facing < PINCH.minFacing)
    out.push(make("HAND_POORLY_VISIBLE", "HACK", { title, message: "Turn your hand toward the camera.", visual: { kind: "highlight-hand" } }));
  if (i.reason === "PINCH_TOO_WIDE") out.push(make("PINCH_TOO_WIDE", "HACK", { title, message: "Bring your thumb and index finger closer.", visual: gap, progress: i.analysis.closeness }));
  if (i.reason === "PINCH_NOT_HELD") out.push(make("PINCH_NOT_HELD", "HACK", { title, message: "Hold the pinch for a moment.", visual: gap }));
  return out;
}

/** Classifies why an attempt failed. Empty array ⇒ nothing wrong (valid gesture). */
export function classifyError(input: ErrorInput): GestureError[] {
  switch (input.kind) {
    case "swipe":
      return classifySwipe(input.attempt);
    case "jump":
      return classifyJump(input.analysis);
    case "palm":
      return classifyPalm(input);
    case "pinch":
      return classifyPinch(input);
  }
}

export type ConditionType = Extract<GestureErrorType, "MULTIPLE_PEOPLE" | "TRACKING_LOST">;

export function conditionError(type: ConditionType): GestureError {
  return type === "MULTIPLE_PEOPLE"
    ? make(type, undefined, { title: "TOO MANY PLAYERS", message: "Only one player should be visible.", severity: "error" }, false)
    : make(type, undefined, { title: "TRACKING LOST", message: "Step back into view — upper body and hands.", severity: "error" }, false);
}

export interface ErrorTrackerState {
  error: GestureError | null;
  seq: number;
  /** Show "✓ READY" after the shown error was fixed. */
  ready: boolean;
}

/**
 * Lifecycle of the ONE error shown:
 * attempt errors live `ttlMs` or until the next success; conditions live while true.
 * Fixed → "✓ READY". Each new failed attempt counts as a prompt; flickering conditions count once.
 */
export class ErrorTracker {
  private attempt: GestureError | null = null;
  private attemptExpires = 0;
  private shown: GestureError | null = null;
  private readyUntil = 0;
  private seq = 0;
  private lastShownAt: Partial<Record<GestureErrorType, number>> = {};

  constructor(
    private readonly onShown: (e: GestureError) => void = () => {},
    private readonly ttlMs = 2400,
    private readonly readyMs = 1000,
  ) {}

  reportAttempt(errors: readonly GestureError[], t: number): GestureError | null {
    const best = getBestError(errors);
    if (!best) return null;
    this.attempt = best;
    this.attemptExpires = t + this.ttlMs;
    return best;
  }

  reportSuccess(t: number): void {
    this.attempt = null;
    if (this.shown?.fromAttempt) {
      this.shown = null;
      this.readyUntil = t + this.readyMs;
    }
  }

  reset(): void {
    this.attempt = null;
    this.shown = null;
    this.readyUntil = 0;
  }

  update(conditions: readonly GestureError[], t: number): ErrorTrackerState {
    let expired = false;
    if (this.attempt && t > this.attemptExpires) {
      this.attempt = null;
      expired = true;
    }
    const best = getBestError(this.attempt ? [...conditions, this.attempt] : conditions);
    if (best) {
      if (best !== this.shown) {
        const typeChanged = !this.shown || this.shown.type !== best.type;
        const last = this.lastShownAt[best.type] ?? -Infinity;
        if (best.fromAttempt || (typeChanged && t - last > 1500)) this.onShown(best);
        if (best.fromAttempt || typeChanged) this.seq++;
      }
      this.lastShownAt[best.type] = t;
      this.shown = best;
      this.readyUntil = 0;
      return { error: best, seq: this.seq, ready: false };
    }
    if (this.shown) {
      if (!(this.shown.fromAttempt && expired)) this.readyUntil = t + this.readyMs;
      this.shown = null;
    }
    return { error: null, seq: this.seq, ready: t < this.readyUntil };
  }
}

