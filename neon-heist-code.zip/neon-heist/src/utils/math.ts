import type { Point } from "../types/vision";

export const clamp = (v: number, min = 0, max = 1): number => (v < min ? min : v > max ? max : v);

export const lerp = (a: number, b: number, t: number): number => a + (b - a) * t;

/**
 * Euclidean distance between two normalized points.
 * `aspect` (= frameWidth / frameHeight) scales X so that distances are isotropic —
 * a 0.1 distance means the same physical length horizontally and vertically.
 * Result is expressed in frame-height units.
 */
export function calculateDistance(a: Point, b: Point, aspect = 1): number {
  const dx = (a.x - b.x) * aspect;
  const dy = a.y - b.y;
  return Math.sqrt(dx * dx + dy * dy);
}

export interface TimedPoint {
  t: number; // ms
  x: number;
  y: number;
}

/**
 * velocity = distance / deltaTime, in normalized units per second.
 * Uses first/last samples of the window (robust to per-frame jitter).
 */
export function calculateVelocity(samples: readonly TimedPoint[]): { vx: number; vy: number; speed: number } {
  if (samples.length < 2) return { vx: 0, vy: 0, speed: 0 };
  const a = samples[0];
  const b = samples[samples.length - 1];
  const dt = (b.t - a.t) / 1000;
  if (dt <= 0) return { vx: 0, vy: 0, speed: 0 };
  const vx = (b.x - a.x) / dt;
  const vy = (b.y - a.y) / dt;
  return { vx, vy, speed: Math.sqrt(vx * vx + vy * vy) };
}

export function mean(values: readonly number[]): number {
  if (values.length === 0) return 0;
  let s = 0;
  for (const v of values) s += v;
  return s / values.length;
}

export function centroid(points: readonly Point[]): Point {
  if (points.length === 0) return { x: 0, y: 0 };
  let x = 0;
  let y = 0;
  for (const p of points) {
    x += p.x;
    y += p.y;
  }
  return { x: x / points.length, y: y / points.length };
}

/** Angle in degrees between two 2D vectors (aspect-corrected). */
export function angleBetween(a: Point, b: Point, aspect = 1): number {
  const ax = a.x * aspect;
  const bx = b.x * aspect;
  const dot = ax * bx + a.y * b.y;
  const na = Math.sqrt(ax * ax + a.y * a.y);
  const nb = Math.sqrt(bx * bx + b.y * b.y);
  if (na === 0 || nb === 0) return 0;
  return (Math.acos(clamp(dot / (na * nb), -1, 1)) * 180) / Math.PI;
}

export const sub = (a: Point, b: Point): Point => ({ x: a.x - b.x, y: a.y - b.y });

/** 2D cross product (aspect-corrected). */
export const cross = (a: Point, b: Point, aspect = 1): number => a.x * aspect * b.y - a.y * b.x * aspect;

/** Maps value from [inMin,inMax] to [0,1] and clamps. */
export const normalize = (v: number, inMin: number, inMax: number): number =>
  clamp((v - inMin) / (inMax - inMin));

export function mostFrequent<T extends string>(counts: Partial<Record<T, number>>): T | null {
  let best: T | null = null;
  let bestCount = 0;
  for (const key of Object.keys(counts) as T[]) {
    const c = counts[key] ?? 0;
    if (c > bestCount) {
      best = key;
      bestCount = c;
    }
  }
  return best;
}

/** Angle ABC in degrees (at vertex b), aspect-corrected. */
export function calculateAngle(a: Point, b: Point, c: Point, aspect = 1): number {
  return angleBetween({ x: a.x - b.x, y: a.y - b.y }, { x: c.x - b.x, y: c.y - b.y }, aspect);
}
