import type { Point } from "./vision";

/** The five body gestures of NEON HEIST. */
export type GestureKind = "MOVE_LEFT" | "MOVE_RIGHT" | "JUMP" | "HACK" | "SHIELD";

/** Temporal state machine phases shared by every gesture detector. */
export type GesturePhase =
  | "IDLE"
  | "POSSIBLE"
  | "TRACKING"
  | "GESTURE_CONFIRMED"
  | "ACTION_TRIGGERED"
  | "COOLDOWN";

export type Direction = "up" | "down" | "left" | "right" | "center";

export type GestureErrorType =
  | "MULTIPLE_PEOPLE"
  | "TRACKING_LOST"
  | "HANDS_NOT_VISIBLE"
  | "HAND_OUT_OF_FRAME"
  | "LOW_CONFIDENCE"
  | "HAND_POORLY_VISIBLE"
  | "ONE_HAND_TOO_LOW"
  | "HANDS_TOO_LOW"
  | "HAND_TOO_LOW"
  | "HAND_NOT_OPEN"
  | "PALM_NOT_FACING"
  | "WRONG_DIRECTION"
  | "SWIPE_TOO_SHORT"
  | "SWIPE_TOO_SLOW"
  | "PINCH_TOO_WIDE"
  | "PINCH_NOT_HELD";

export type Severity = "info" | "warning" | "error";

/** What the overlay should draw to make the error obvious without reading. */
export type ErrorVisual =
  | { kind: "trajectory"; start: Point; reached: Point; targetX: number }
  | { kind: "arrow"; from: Point; direction: Direction }
  /** Up-arrows above each wrist that is too low + the required "jump line". */
  | { kind: "jump"; lowWrists: Point[]; lineY: number }
  | { kind: "pinch-gap"; thumb: Point; index: Point }
  | { kind: "highlight-hand" };

export interface GestureError {
  type: GestureErrorType;
  gesture?: GestureKind;
  /** Short headline, e.g. "JUMP NOT READY". */
  title: string;
  /** The one instruction, e.g. "Raise both hands higher to jump." */
  message: string;
  severity: Severity;
  direction?: Direction;
  visual?: ErrorVisual;
  /** Progress towards the goal 0..1 (e.g. swipe distance achieved / required). */
  progress?: number;
  /** true when produced by a finished/near-miss attempt (vs. a continuous condition). */
  fromAttempt: boolean;
}

/** Measurements of a finished swipe stroke. */
export interface SwipeAttempt {
  direction: "left" | "right";
  start: Point;
  end: Point;
  peak: Point;
  dx: number;
  dy: number;
  durationMs: number;
  avgSpeed: number;
  peakSpeed: number;
  leftFrame: boolean;
  meanY: number;
  meanScore: number;
  requiredDistance: number;
}

export interface GestureEvent {
  gesture: GestureKind;
  /** 0..1 detection confidence — internal quality indicator, not a probability. */
  confidence: number;
  t: number;
}

/** What the game currently expects the player to do (drives context-aware errors). */
export type ExpectedAction = "MOVE" | "JUMP" | "HACK" | "SHIELD" | null;
