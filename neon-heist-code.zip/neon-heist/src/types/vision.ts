/**
 * Vision types. All coordinates are normalized to [0..1] of the camera frame
 * and already MIRRORED (selfie view): x grows toward the right side of the screen
 * as the user sees it. This is done once at ingestion so gesture logic can use
 * screen-intuitive directions ("swipe right" = hand moves to the right of the screen).
 */
export interface Point {
  x: number;
  y: number;
  z?: number;
  /** Pose landmarks only: model's estimate that the point is visible (0..1). */
  visibility?: number;
}

export type Landmarks = Point[];

export interface HandObservation {
  /** 21 hand landmarks (MediaPipe Hand Landmarker topology). */
  landmarks: Landmarks;
  /** Hand presence score from the model's handedness head (0..1). */
  score: number;
}

export interface PoseObservation {
  /** 33 body landmarks (MediaPipe Pose Landmarker topology). */
  landmarks: Landmarks;
}

export interface VisionFrame {
  /** performance.now() timestamp in ms. */
  t: number;
  hands: HandObservation[];
  /** null when pose was not evaluated on this frame (pose runs at a lower rate). */
  poses: PoseObservation[] | null;
  /** Average luma 0..255 of a downscaled frame, null when not sampled this frame. */
  brightness: number | null;
  /** videoWidth / videoHeight. Used to make distances isotropic. */
  aspect: number;
}

/** Hand landmark indices (MediaPipe topology). */
export const HAND = {
  WRIST: 0,
  THUMB_CMC: 1,
  THUMB_MCP: 2,
  THUMB_IP: 3,
  THUMB_TIP: 4,
  INDEX_MCP: 5,
  INDEX_PIP: 6,
  INDEX_DIP: 7,
  INDEX_TIP: 8,
  MIDDLE_MCP: 9,
  MIDDLE_PIP: 10,
  MIDDLE_DIP: 11,
  MIDDLE_TIP: 12,
  RING_MCP: 13,
  RING_PIP: 14,
  RING_DIP: 15,
  RING_TIP: 16,
  PINKY_MCP: 17,
  PINKY_PIP: 18,
  PINKY_DIP: 19,
  PINKY_TIP: 20,
} as const;

/** Pose landmark indices used by MotionOS (MediaPipe topology). */
export const POSE = {
  NOSE: 0,
  LEFT_EYE: 2,
  RIGHT_EYE: 5,
  LEFT_EAR: 7,
  RIGHT_EAR: 8,
  LEFT_SHOULDER: 11,
  RIGHT_SHOULDER: 12,
  LEFT_ELBOW: 13,
  RIGHT_ELBOW: 14,
  LEFT_WRIST: 15,
  RIGHT_WRIST: 16,
  LEFT_HIP: 23,
  RIGHT_HIP: 24,
} as const;

export const HAND_CONNECTIONS: ReadonlyArray<readonly [number, number]> = [
  [0, 1], [1, 2], [2, 3], [3, 4],
  [0, 5], [5, 6], [6, 7], [7, 8],
  [5, 9], [9, 10], [10, 11], [11, 12],
  [9, 13], [13, 14], [14, 15], [15, 16],
  [13, 17], [17, 18], [18, 19], [19, 20],
  [0, 17],
];

export const POSE_UPPER_BODY_CONNECTIONS: ReadonlyArray<readonly [number, number]> = [
  [11, 12], [11, 13], [13, 15], [12, 14], [14, 16],
  [11, 23], [12, 24], [23, 24],
  [0, 2], [0, 5], [2, 7], [5, 8],
];

export type VisionStatus = "idle" | "loading" | "ready" | "error";
