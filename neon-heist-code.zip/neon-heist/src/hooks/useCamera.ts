import { useCallback, useEffect, useRef, useState } from "react";

export type CameraStatus = "idle" | "requesting" | "ready" | "error";
export type CameraErrorKind = "permission-denied" | "not-found" | "in-use" | "insecure" | "unsupported" | "unknown";

export interface CameraError {
  kind: CameraErrorKind;
  title: string;
  message: string;
}

const ERRORS: Record<CameraErrorKind, Omit<CameraError, "kind">> = {
  "permission-denied": {
    title: "Camera access was blocked",
    message:
      "Click the camera icon in your browser's address bar, allow access for this site, then try again. MotionOS processes video only on your device.",
  },
  "not-found": {
    title: "No camera found",
    message: "Connect a webcam (or use a laptop/phone with a front camera) and try again.",
  },
  "in-use": {
    title: "Camera is busy",
    message: "Another app (Zoom, Meet, Teams…) is using the camera. Close it and try again.",
  },
  insecure: {
    title: "Camera needs a secure page",
    message: "Browsers only allow the camera on https:// or localhost. Open MotionOS via its https link.",
  },
  unsupported: {
    title: "Browser not supported",
    message: "This browser can't access the camera. Please use a recent Chrome, Edge, Safari or Firefox.",
  },
  unknown: {
    title: "Camera could not start",
    message: "Something went wrong while starting the camera. Reload the page and try again.",
  },
};

function classify(err: unknown): CameraErrorKind {
  const name = (err as { name?: string })?.name ?? "";
  if (name === "NotAllowedError" || name === "SecurityError" || name === "PermissionDeniedError") return "permission-denied";
  if (name === "NotFoundError" || name === "DevicesNotFoundError" || name === "OverconstrainedError") return "not-found";
  if (name === "NotReadableError" || name === "TrackStartError" || name === "AbortError") return "in-use";
  return "unknown";
}

/**
 * Camera access via getUserMedia (front camera preferred, no audio).
 * The stream is only ever attached to a local <video> element.
 */
export function useCamera() {
  const [status, setStatus] = useState<CameraStatus>("idle");
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [error, setError] = useState<CameraError | null>(null);
  const streamRef = useRef<MediaStream | null>(null);

  const stop = useCallback(() => {
    streamRef.current?.getTracks().forEach((t) => t.stop());
    streamRef.current = null;
    setStream(null);
    setStatus("idle");
  }, []);

  const start = useCallback(async () => {
    const fail = (kind: CameraErrorKind) => {
      setError({ kind, ...ERRORS[kind] });
      setStatus("error");
    };
    if (!window.isSecureContext) return fail("insecure");
    if (!navigator.mediaDevices?.getUserMedia) return fail("unsupported");
    setStatus("requesting");
    setError(null);
    try {
      let s: MediaStream;
      try {
        s = await navigator.mediaDevices.getUserMedia({
          audio: false,
          video: { facingMode: "user", width: { ideal: 1280 }, height: { ideal: 720 }, frameRate: { ideal: 30, max: 30 } },
        });
      } catch (e) {
        // Some devices reject the ideal constraints — retry with the bare minimum.
        if ((e as { name?: string })?.name === "OverconstrainedError") {
          s = await navigator.mediaDevices.getUserMedia({ audio: false, video: true });
        } else throw e;
      }
      streamRef.current = s;
      setStream(s);
      setStatus("ready");
      s.getVideoTracks()[0]?.addEventListener("ended", () => {
        setError({ kind: "in-use", title: "Camera disconnected", message: "The camera stopped. Reconnect it and try again." });
        setStatus("error");
      });
    } catch (e) {
      fail(classify(e));
    }
  }, []);

  useEffect(() => () => streamRef.current?.getTracks().forEach((t) => t.stop()), []);

  return { status, stream, error, start, stop };
}
