import { useCallback, useMemo, useRef, useState } from "react";
import { GestureController, type ControllerContext, type ControllerOutput, type ControllerSnapshot } from "../gestures/gestureController";
import type { VisionFrame } from "../types/vision";

/** React UI refresh interval (the camera overlay & game canvas update every frame). */
const UI_INTERVAL_MS = 90;

/**
 * Bridges the pure GestureController into React. Every vision frame is processed
 * synchronously (events go straight to the game), while React state is throttled.
 */
export function useGestureController(onOutput: (out: ControllerOutput) => void) {
  const ref = useRef<GestureController | null>(null);
  if (!ref.current) ref.current = new GestureController();
  const [snapshot, setSnapshot] = useState<ControllerSnapshot | null>(null);
  const latest = useRef<ControllerSnapshot | null>(null);
  const lastUi = useRef(0);
  const lastSeq = useRef(-1);
  const lastReady = useRef(false);
  const lastTracking = useRef<string>("");
  const onOutputRef = useRef(onOutput);
  onOutputRef.current = onOutput;

  const process = useCallback((frame: VisionFrame) => {
    const out = ref.current!.process(frame);
    latest.current = out.snapshot;
    onOutputRef.current(out);
    const s = out.snapshot;
    const important = out.events.length > 0 || s.errorSeq !== lastSeq.current || s.ready !== lastReady.current || s.tracking !== lastTracking.current;
    if (important || frame.t - lastUi.current >= UI_INTERVAL_MS) {
      lastUi.current = frame.t;
      lastSeq.current = s.errorSeq;
      lastReady.current = s.ready;
      lastTracking.current = s.tracking;
      setSnapshot(s);
    }
  }, []);

  const setContext = useCallback((patch: Partial<ControllerContext>) => ref.current!.setContext(patch), []);
  const controller = ref.current;
  return useMemo(() => ({ controller, snapshot, latest, process, setContext }), [controller, snapshot, process, setContext]);
}
