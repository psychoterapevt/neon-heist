import { useEffect, useRef, useState, type RefObject } from "react";
import type { VisionFrame, VisionStatus } from "../types/vision";
import { createHandDetector, type HandDetector } from "../vision/handDetector";
import { createPoseDetector, type PoseDetector } from "../vision/poseDetector";
import { BrightnessSampler } from "../vision/brightness";

export interface VisionOptions {
  /** Run pose every N camera frames (pose is heavier than hands). */
  poseEvery: number;
  onFrame: (frame: VisionFrame) => void;
}

export type VisionStage = "runtime" | "hand-model" | "pose-model" | "done";

type VideoWithRVFC = HTMLVideoElement & {
  requestVideoFrameCallback?: (cb: () => void) => number;
  cancelVideoFrameCallback?: (id: number) => void;
};

/**
 * Real-time inference loop.
 * - camera frames: driven by requestVideoFrameCallback (one inference per NEW video frame)
 * - vision inference: hands every frame, pose every `poseEvery` frames, brightness ~2×/s
 * - gesture processing + overlay: in `onFrame` (synchronous, no React re-render)
 * - UI: React state is updated by the consumer at a throttled rate.
 */
export function useVision(videoRef: RefObject<HTMLVideoElement | null>, stream: MediaStream | null, opts: VisionOptions) {
  const [status, setStatus] = useState<VisionStatus>("idle");
  const [stage, setStage] = useState<VisionStage>("runtime");
  const [error, setError] = useState<string | null>(null);
  const [fps, setFps] = useState(0);
  const [poseAvailable, setPoseAvailable] = useState(true);
  const optsRef = useRef(opts);
  optsRef.current = opts;

  useEffect(() => {
    if (!stream) return;
    let cancelled = false;
    let hand: HandDetector | null = null;
    let pose: PoseDetector | null = null;
    let rafId = 0;
    let rvfcId = 0;
    let frameNo = 0;
    let lastTs = 0;
    let fpsCount = 0;
    let fpsSince = performance.now();
    const brightness = new BrightnessSampler();

    const video = videoRef.current as VideoWithRVFC | null;

    const schedule = () => {
      if (cancelled || !video) return;
      if (video.requestVideoFrameCallback) rvfcId = video.requestVideoFrameCallback(tick);
      else rafId = requestAnimationFrame(tick);
    };

    const tick = () => {
      if (cancelled || !video || !hand) return;
      try {
        if (video.readyState >= 2 && video.videoWidth > 0) {
          let ts = performance.now();
          if (ts <= lastTs) ts = lastTs + 1; // MediaPipe needs strictly increasing timestamps
          lastTs = ts;
          frameNo++;
          const hands = hand.detect(video, ts);
          const poses = pose && frameNo % Math.max(1, optsRef.current.poseEvery) === 0 ? pose.detect(video, ts) : null;
          const b = frameNo % 15 === 1 ? brightness.sample(video) : null;
          optsRef.current.onFrame({
            t: ts,
            hands,
            poses,
            brightness: b,
            aspect: video.videoWidth / video.videoHeight,
          });
          fpsCount++;
          if (ts - fpsSince >= 1000) {
            setFps(Math.round((fpsCount * 1000) / (ts - fpsSince)));
            fpsCount = 0;
            fpsSince = ts;
          }
        }
      } catch (e) {
        console.error("[motionos] inference error", e);
      }
      schedule();
    };

    (async () => {
      setStatus("loading");
      setError(null);
      setStage("hand-model");
      const h = await createHandDetector();
      if (cancelled) {
        h.close();
        return;
      }
      hand = h;
      setStage("pose-model");
      try {
        const p = await createPoseDetector();
        if (cancelled) {
          p.close();
          return;
        }
        pose = p;
        setPoseAvailable(true);
      } catch (e) {
        console.warn("[motionos] pose model unavailable — continuing with hands only", e);
        pose = null;
        setPoseAvailable(false);
      }
      if (cancelled) return;
      setStage("done");
      setStatus("ready");
      schedule();
    })().catch((e: unknown) => {
      if (cancelled) return;
      console.error("[motionos] vision init failed", e);
      setError(
        "The hand-tracking model could not be loaded. Check your internet connection (the model downloads once) and reload.",
      );
      setStatus("error");
    });

    return () => {
      cancelled = true;
      if (rvfcId && video?.cancelVideoFrameCallback) video.cancelVideoFrameCallback(rvfcId);
      if (rafId) cancelAnimationFrame(rafId);
      hand?.close();
      pose?.close();
    };
  }, [stream, videoRef]);

  return { status, stage, error, fps, poseAvailable };
}
