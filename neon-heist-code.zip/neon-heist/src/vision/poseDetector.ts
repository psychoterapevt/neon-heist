import { PoseLandmarker } from "@mediapipe/tasks-vision";
import type { PoseObservation } from "../types/vision";
import { MODELS, getVisionFileset } from "./visionRuntime";

export interface PoseDetector {
  detect(video: HTMLVideoElement, timestampMs: number): PoseObservation[];
  close(): void;
}

async function create(delegate: "GPU" | "CPU"): Promise<PoseLandmarker> {
  const fileset = await getVisionFileset();
  return PoseLandmarker.createFromOptions(fileset, {
    baseOptions: { modelAssetPath: MODELS.pose, delegate },
    runningMode: "VIDEO",
    // 2 poses so we can tell the user when more than one person is in frame.
    numPoses: 2,
    minPoseDetectionConfidence: 0.55,
    minPosePresenceConfidence: 0.55,
    minTrackingConfidence: 0.5,
  });
}

/**
 * MediaPipe Pose Landmarker (lite) wrapper — 33 body landmarks, mirrored.
 * Used for camera setup checks (face / shoulders / distance / people count),
 * chest-level estimation and the HAND_UP gesture.
 */
export async function createPoseDetector(): Promise<PoseDetector> {
  let landmarker: PoseLandmarker;
  try {
    landmarker = await create("GPU");
  } catch {
    landmarker = await create("CPU");
  }
  return {
    detect(video, timestampMs) {
      const result = landmarker.detectForVideo(video, timestampMs);
      return result.landmarks.map((lm) => ({
        landmarks: lm.map((p) => ({ x: 1 - p.x, y: p.y, z: p.z, visibility: p.visibility })),
      }));
    },
    close() {
      landmarker.close();
    },
  };
}
