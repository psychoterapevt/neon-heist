import { POSE, type Landmarks } from "../types/vision";
import { frameCoverage } from "./handMetrics";

/** isHandVisible — a hand is usable when the model is confident and most of it is in frame. */
export function isHandVisible(hand: Landmarks | null, presence: number, minPresence = 0.55): boolean {
  return !!hand && presence >= minPresence && frameCoverage(hand, 0) >= 0.85;
}

/** isBodyVisible — shoulders (and the face) are tracked with enough visibility. */
export function isBodyVisible(pose: Landmarks | null, minVisibility = 0.5): boolean {
  if (!pose) return false;
  const pts = [POSE.LEFT_SHOULDER, POSE.RIGHT_SHOULDER, POSE.NOSE].map((i) => pose[i]);
  return pts.every((p) => !!p && (p.visibility ?? 1) >= minVisibility && p.x > -0.02 && p.x < 1.02 && p.y > -0.02 && p.y < 1.02);
}
