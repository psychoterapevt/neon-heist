import type { Landmarks, Point } from "../types/vision";
import { calculateDistance } from "../utils/math";

/**
 * Exponential smoothing of a single landmark.
 * alpha = 1 → no smoothing, alpha → 0 → very smooth (more lag).
 */
export function smoothLandmark(prev: Point, next: Point, alpha: number): Point {
  return {
    x: prev.x + alpha * (next.x - prev.x),
    y: prev.y + alpha * (next.y - prev.y),
    z: next.z === undefined || prev.z === undefined ? next.z : prev.z + alpha * (next.z - prev.z),
    visibility: next.visibility,
  };
}

export interface SmootherOptions {
  /** Alpha when the hand is still — strong smoothing kills jitter. */
  minAlpha: number;
  /** Alpha when the hand moves fast — light smoothing keeps swipes responsive. */
  maxAlpha: number;
  /** Per-frame displacement (frame-height units) at which maxAlpha is reached. */
  fastMotion: number;
  /** Reset the filter if no frame arrived for this long (ms). */
  resetAfterMs: number;
}

const DEFAULTS: SmootherOptions = {
  minAlpha: 0.35,
  maxAlpha: 0.85,
  fastMotion: 0.03,
  resetAfterMs: 250,
};

/**
 * LandmarkSmoother — adaptive exponential smoothing for a whole landmark set.
 * Alpha adapts to motion speed (small motion = jitter → smooth hard;
 * big motion = intentional gesture → follow closely). This is a simplified
 * version of the "1€ filter" idea: stability when still, low lag when moving.
 */
export class LandmarkSmoother {
  private state: Landmarks | null = null;
  private lastT = 0;
  private readonly opts: SmootherOptions;

  constructor(opts: Partial<SmootherOptions> = {}) {
    this.opts = { ...DEFAULTS, ...opts };
  }

  reset(): void {
    this.state = null;
  }

  smooth(landmarks: Landmarks, t: number, aspect = 1): Landmarks {
    const { minAlpha, maxAlpha, fastMotion, resetAfterMs } = this.opts;
    if (!this.state || this.state.length !== landmarks.length || t - this.lastT > resetAfterMs) {
      this.state = landmarks.map((p) => ({ ...p }));
      this.lastT = t;
      return this.state;
    }
    // Motion estimate from the wrist + middle MCP (rigid part of the hand).
    const motion =
      (calculateDistance(this.state[0], landmarks[0], aspect) +
        calculateDistance(this.state[9] ?? this.state[0], landmarks[9] ?? landmarks[0], aspect)) /
      2;
    const k = Math.min(1, motion / fastMotion);
    const alpha = minAlpha + (maxAlpha - minAlpha) * k;
    const prev = this.state;
    this.state = landmarks.map((p, i) => smoothLandmark(prev[i], p, alpha));
    this.lastT = t;
    return this.state;
  }
}
