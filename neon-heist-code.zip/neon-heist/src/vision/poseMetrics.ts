import { POSE, type Landmarks, type Point } from "../types/vision";

const VIS = 0.5;

const visible = (p: Point | undefined, min = VIS): p is Point =>
  !!p && (p.visibility ?? 1) >= min && p.x > -0.02 && p.x < 1.02 && p.y > -0.02 && p.y < 1.02;

export interface BodyMetrics {
  faceVisible: boolean;
  shouldersVisible: boolean;
  armsVisible: boolean;
  /** Shoulder width in frame-height units (aspect-corrected). */
  shoulderWidth: number;
  shoulderMid: Point | null;
  /** Y below which a hand is considered "too low" for gestures (waist level). */
  lowHandLimitY: number;
  /** Y of chest level (where we ask users to hold their hand). */
  chestY: number;
  /** Y above which a wrist counts as "above the head". */
  headTopY: number | null;
  wrists: Point[];
}

/** Derives body-level metrics from pose landmarks (mirrored normalized coords). */
export function analyzeBody(lm: Landmarks, aspect = 1): BodyMetrics {
  const nose = lm[POSE.NOSE];
  const le = lm[POSE.LEFT_EYE];
  const re = lm[POSE.RIGHT_EYE];
  const ls = lm[POSE.LEFT_SHOULDER];
  const rs = lm[POSE.RIGHT_SHOULDER];
  const faceVisible = visible(nose) && (visible(le) || visible(re));
  const shouldersVisible = visible(ls) && visible(rs);
  const armsVisible = visible(lm[POSE.LEFT_ELBOW], 0.4) || visible(lm[POSE.RIGHT_ELBOW], 0.4);

  let shoulderWidth = 0;
  let shoulderMid: Point | null = null;
  if (ls && rs) {
    shoulderWidth = Math.hypot((ls.x - rs.x) * aspect, ls.y - rs.y);
    shoulderMid = { x: (ls.x + rs.x) / 2, y: (ls.y + rs.y) / 2 };
  }

  // Torso proportions (in shoulder widths below the shoulder line):
  // chest ≈ 0.3, lower chest / belly ≈ 0.7. Below that a swipe is "too low".
  // Capped so that it stays meaningful when the lower body is outside the frame.
  const lowHandLimitY = shoulderMid && shoulderWidth > 0 ? Math.min(0.9, shoulderMid.y + shoulderWidth * 0.7) : 0.86;
  const chestY = shoulderMid && shoulderWidth > 0 ? Math.min(0.85, shoulderMid.y + shoulderWidth * 0.3) : 0.6;

  let headTopY: number | null = null;
  if (faceVisible && nose) {
    const eyeY = Math.min(le?.y ?? nose.y, re?.y ?? nose.y);
    const scale = shoulderWidth > 0 ? shoulderWidth : 0.2;
    headTopY = eyeY - scale * 0.35;
  }

  const wrists: Point[] = [];
  for (const i of [POSE.LEFT_WRIST, POSE.RIGHT_WRIST]) {
    const w = lm[i];
    if (w && (w.visibility ?? 1) >= 0.5) wrists.push(w);
  }

  return { faceVisible, shouldersVisible, armsVisible, shoulderWidth, shoulderMid, lowHandLimitY, chestY, headTopY, wrists };
}

export type PositionStatus =
  | "NO_PERSON"
  | "MULTIPLE_PEOPLE"
  | "MOVE_BACK"
  | "MOVE_CLOSER"
  | "SHOW_FACE"
  | "SHOW_SHOULDERS"
  | "SHOW_YOUR_HAND"
  | "LOW_LIGHT"
  | "GOOD_POSITION";

export interface PositionCheck {
  status: PositionStatus;
  checks: {
    face: boolean;
    shoulders: boolean;
    arms: boolean;
    hands: boolean;
    distance: boolean;
    light: boolean;
    singlePerson: boolean;
  };
  /** Shoulder width relative to the shorter side of the frame. */
  bodyScale: number;
}

/**
 * Thresholds for "too close" / "too far": shoulder width relative to the SHORTER
 * side of the frame (works for landscape laptops and portrait phones alike).
 * Typical good position ≈ 0.45–0.95.
 */
export const DISTANCE_LIMITS = { tooClose: 1.15, tooFar: 0.25 } as const;

/** Shoulder width (frame-height units) → relative to the shorter frame side. */
export const bodyScaleOf = (shoulderWidth: number, aspect: number): number =>
  aspect >= 1 ? shoulderWidth : shoulderWidth / aspect;

/**
 * Camera setup check: is the user positioned so gestures can work?
 * Priority order: multiple people → no person → light → distance → face → shoulders → hand.
 */
export function checkPosition(
  poses: Landmarks[],
  handCount: number,
  brightness: number | null,
  aspect = 1,
): PositionCheck {
  const light = brightness === null || brightness >= 40;
  const base = {
    face: false,
    shoulders: false,
    arms: false,
    hands: handCount > 0,
    distance: false,
    light,
    singlePerson: poses.length <= 1,
  };
  if (poses.length > 1) return { status: "MULTIPLE_PEOPLE", checks: base, bodyScale: 0 };
  if (poses.length === 0) {
    return { status: light ? "NO_PERSON" : "LOW_LIGHT", checks: base, bodyScale: 0 };
  }
  const body = analyzeBody(poses[0], aspect);
  const lm = poses[0];
  const ls = lm[POSE.LEFT_SHOULDER];
  const rs = lm[POSE.RIGHT_SHOULDER];
  const shouldersCut =
    !!ls && !!rs && (ls.x < 0.01 || ls.x > 0.99 || rs.x < 0.01 || rs.x > 0.99 || ls.y > 0.99 || rs.y > 0.99);
  const bodyScale = bodyScaleOf(body.shoulderWidth, aspect);
  const tooClose = bodyScale > DISTANCE_LIMITS.tooClose || (body.faceVisible && shouldersCut);
  const tooFar = bodyScale > 0 && bodyScale < DISTANCE_LIMITS.tooFar;
  const checks = {
    ...base,
    face: body.faceVisible,
    shoulders: body.shouldersVisible && !shouldersCut,
    arms: body.armsVisible,
    distance: !tooClose && !tooFar && body.shoulderWidth > 0,
  };
  let status: PositionStatus = "GOOD_POSITION";
  if (!light) status = "LOW_LIGHT";
  else if (tooClose) status = "MOVE_BACK";
  else if (tooFar) status = "MOVE_CLOSER";
  else if (!checks.face) status = "SHOW_FACE";
  else if (!checks.shoulders) status = "SHOW_SHOULDERS";
  else if (!checks.hands) status = "SHOW_YOUR_HAND";
  return { status, checks, bodyScale };
}
