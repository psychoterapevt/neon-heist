import type { ControllerSnapshot } from "../gestures/gestureController";
import type { Direction, ErrorVisual } from "../types/gesture";
import { HAND, HAND_CONNECTIONS, POSE_UPPER_BODY_CONNECTIONS, type Landmarks, type Point } from "../types/vision";

export interface OverlayFx {
  now: number;
  /** Skeleton flashes green until this time after a successful gesture. */
  successUntil: number;
  reducedMotion: boolean;
  /** Draw body skeleton (setup / calibration) or only a light version. */
  bodyDetail: "full" | "light";
}

const COLORS = {
  bone: "rgba(169, 188, 255, 0.95)",
  boneDim: "rgba(169, 188, 255, 0.35)",
  joint: "#f8fafc",
  body: "rgba(226, 232, 240, 0.55)",
  ok: "#34d399",
  warn: "#fbbf24",
  bad: "#f87171",
  accent: "#7c9cff",
};

interface Mapper {
  (p: Point): { x: number; y: number };
  scale: number;
}

/** Maps normalized (mirrored) coords to canvas pixels, matching CSS object-fit: cover. */
function makeMapper(cw: number, ch: number, vw: number, vh: number): Mapper {
  const s = Math.max(cw / vw, ch / vh);
  const dw = vw * s;
  const dh = vh * s;
  const ox = (cw - dw) / 2;
  const oy = (ch - dh) / 2;
  const f = ((p: Point) => ({ x: ox + p.x * dw, y: oy + p.y * dh })) as Mapper;
  f.scale = dh;
  return f;
}

function drawSkeleton(
  ctx: CanvasRenderingContext2D,
  lm: Landmarks,
  map: Mapper,
  conns: ReadonlyArray<readonly [number, number]>,
  color: string,
  width: number,
  jointR: number,
  minVis = 0,
) {
  ctx.lineCap = "round";
  ctx.lineJoin = "round";
  ctx.strokeStyle = color;
  ctx.lineWidth = width;
  ctx.beginPath();
  for (const [a, b] of conns) {
    const pa = lm[a];
    const pb = lm[b];
    if (!pa || !pb) continue;
    if ((pa.visibility ?? 1) < minVis || (pb.visibility ?? 1) < minVis) continue;
    const A = map(pa);
    const B = map(pb);
    ctx.moveTo(A.x, A.y);
    ctx.lineTo(B.x, B.y);
  }
  ctx.stroke();
  if (jointR > 0) {
    const used = new Set<number>();
    for (const [a, b] of conns) {
      used.add(a);
      used.add(b);
    }
    for (const i of used) {
      const p = lm[i];
      if (!p || (p.visibility ?? 1) < minVis) continue;
      const P = map(p);
      ctx.beginPath();
      ctx.fillStyle = COLORS.joint;
      ctx.arc(P.x, P.y, jointR, 0, Math.PI * 2);
      ctx.fill();
      ctx.lineWidth = 1.5;
      ctx.strokeStyle = color;
      ctx.stroke();
    }
  }
}

function arrowHead(ctx: CanvasRenderingContext2D, x: number, y: number, angle: number, size: number) {
  ctx.beginPath();
  ctx.moveTo(x, y);
  ctx.lineTo(x - size * Math.cos(angle - 0.45), y - size * Math.sin(angle - 0.45));
  ctx.lineTo(x - size * Math.cos(angle + 0.45), y - size * Math.sin(angle + 0.45));
  ctx.closePath();
  ctx.fill();
}

const DIR_ANGLE: Record<Exclude<Direction, "center">, number> = {
  right: 0,
  down: Math.PI / 2,
  left: Math.PI,
  up: -Math.PI / 2,
};

function drawDirectionArrow(ctx: CanvasRenderingContext2D, from: { x: number; y: number }, dir: Direction, fx: OverlayFx, color: string) {
  if (dir === "center") return;
  const a = DIR_ANGLE[dir];
  const pulse = fx.reducedMotion ? 0 : (Math.sin(fx.now / 180) + 1) * 6;
  const start = 34 + pulse;
  const len = 64;
  const x0 = from.x + Math.cos(a) * start;
  const y0 = from.y + Math.sin(a) * start;
  const x1 = x0 + Math.cos(a) * len;
  const y1 = y0 + Math.sin(a) * len;
  ctx.strokeStyle = color;
  ctx.fillStyle = color;
  ctx.lineWidth = 6;
  ctx.lineCap = "round";
  ctx.beginPath();
  ctx.moveTo(x0, y0);
  ctx.lineTo(x1, y1);
  ctx.stroke();
  arrowHead(ctx, x1 + Math.cos(a) * 10, y1 + Math.sin(a) * 10, a, 22);
}

function label(ctx: CanvasRenderingContext2D, text: string, x: number, y: number, color: string) {
  ctx.font = "600 13px ui-sans-serif, system-ui, -apple-system, Segoe UI, sans-serif";
  const w = ctx.measureText(text).width + 16;
  ctx.fillStyle = "rgba(7, 9, 13, 0.78)";
  const h = 24;
  ctx.beginPath();
  ctx.roundRect(x - w / 2, y - h / 2, w, h, 8);
  ctx.fill();
  ctx.fillStyle = color;
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.fillText(text, x, y + 0.5);
}

function drawErrorVisual(ctx: CanvasRenderingContext2D, v: ErrorVisual, map: Mapper, fx: OverlayFx, cw: number) {
  if (v.kind === "trajectory") {
    const S = map(v.start);
    const R = map(v.reached);
    const T = map({ x: v.targetX, y: v.start.y });
    const y = S.y;
    // required path (dashed)
    ctx.setLineDash([10, 8]);
    ctx.strokeStyle = COLORS.warn;
    ctx.lineWidth = 4;
    ctx.beginPath();
    ctx.moveTo(S.x, y);
    ctx.lineTo(T.x, y);
    ctx.stroke();
    ctx.setLineDash([]);
    // achieved path
    ctx.strokeStyle = COLORS.bad;
    ctx.lineWidth = 7;
    ctx.lineCap = "round";
    ctx.beginPath();
    ctx.moveTo(S.x, y);
    ctx.lineTo(R.x, y);
    ctx.stroke();
    // start dot & target flag
    ctx.fillStyle = COLORS.joint;
    ctx.beginPath();
    ctx.arc(S.x, y, 6, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = COLORS.warn;
    arrowHead(ctx, T.x + (T.x > S.x ? 14 : -14), y, T.x > S.x ? 0 : Math.PI, 20);
    ctx.fillRect(T.x - 2, y - 26, 4, 52);
    label(ctx, "MINIMUM DISTANCE", (S.x + T.x) / 2, y - 34, COLORS.warn);
    label(ctx, "HAND", S.x, y + 30, COLORS.bad);
  } else if (v.kind === "jump") {
    // required "jump line" + ↑ arrows above each wrist that is too low
    const L = map({ x: 0, y: v.lineY });
    ctx.setLineDash([10, 8]);
    ctx.strokeStyle = COLORS.warn;
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(0, L.y);
    ctx.lineTo(cw, L.y);
    ctx.stroke();
    ctx.setLineDash([]);
    label(ctx, "JUMP LINE", cw / 2, L.y - 16, COLORS.warn);
    for (const w of v.lowWrists) drawDirectionArrow(ctx, map(w), "up", fx, COLORS.warn);
  } else if (v.kind === "arrow") {
    drawDirectionArrow(ctx, map(v.from), v.direction, fx, COLORS.warn);
  } else if (v.kind === "pinch-gap") {
    const A = map(v.thumb);
    const B = map(v.index);
    ctx.setLineDash([6, 6]);
    ctx.strokeStyle = COLORS.warn;
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(A.x, A.y);
    ctx.lineTo(B.x, B.y);
    ctx.stroke();
    ctx.setLineDash([]);
    const mx = (A.x + B.x) / 2;
    const my = (A.y + B.y) / 2;
    ctx.strokeStyle = COLORS.warn;
    ctx.beginPath();
    ctx.arc(mx, my, 10, 0, Math.PI * 2);
    ctx.stroke();
  }
}

/**
 * Draws the complete overlay: body skeleton, hand skeleton (state-colored),
 * progress rings, live swipe trajectory and the Error Engine's visual hint.
 * Called once per processed frame from the vision loop (not via React).
 */
export function renderOverlay(
  ctx: CanvasRenderingContext2D,
  cw: number,
  ch: number,
  vw: number,
  vh: number,
  snap: ControllerSnapshot | null,
  fx: OverlayFx,
): void {
  ctx.clearRect(0, 0, cw, ch);
  if (!snap || !vw || !vh) return;
  const map = makeMapper(cw, ch, vw, vh);
  const success = fx.now < fx.successUntil;
  const err = snap.error;
  const handProblem = !!err && err.severity !== "info" && !!err.visual;

  // Body
  if (snap.pose) {
    drawSkeleton(
      ctx,
      snap.pose,
      map,
      POSE_UPPER_BODY_CONNECTIONS,
      success ? "rgba(52, 211, 153, 0.6)" : COLORS.body,
      fx.bodyDetail === "full" ? 3 : 2,
      fx.bodyDetail === "full" ? 3.5 : 0,
      0.5,
    );
  }

  // Other hands (dimmed)
  for (const other of snap.otherHands) drawSkeleton(ctx, other, map, HAND_CONNECTIONS, COLORS.boneDim, 2, 0);

  // Primary hand
  if (snap.hand) {
    const color = success ? COLORS.ok : handProblem ? COLORS.warn : COLORS.bone;
    if (success || handProblem) {
      ctx.save();
      ctx.shadowColor = color;
      ctx.shadowBlur = 14;
      drawSkeleton(ctx, snap.hand, map, HAND_CONNECTIONS, color, 5, 0);
      ctx.restore();
    }
    drawSkeleton(ctx, snap.hand, map, HAND_CONNECTIONS, color, 3, 3.5);

    const palm = snap.anchor ? map(snap.anchor) : null;
    // Open-palm hold ring
    if (palm && snap.palmProgress > 0.02) {
      const r = map.scale * 0.11;
      ctx.lineWidth = 5;
      ctx.strokeStyle = "rgba(255,255,255,0.15)";
      ctx.beginPath();
      ctx.arc(palm.x, palm.y, r, 0, Math.PI * 2);
      ctx.stroke();
      ctx.strokeStyle = COLORS.ok;
      ctx.beginPath();
      ctx.arc(palm.x, palm.y, r, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * snap.palmProgress);
      ctx.stroke();
    }
    // Pinch indicator: thumb–index line lights up as the fingers close
    if (snap.pinchCloseness > 0.35) {
      const A = map(snap.hand[HAND.THUMB_TIP]);
      const B = map(snap.hand[HAND.INDEX_TIP]);
      ctx.strokeStyle = snap.pinchClosed ? COLORS.ok : `rgba(124, 156, 255, ${0.35 + 0.6 * snap.pinchCloseness})`;
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.moveTo(A.x, A.y);
      ctx.lineTo(B.x, B.y);
      ctx.stroke();
    }
  }

  // Live swipe trajectory
  if (snap.liveSwipe) {
    const s = snap.liveSwipe;
    const S = map(s.start);
    const C = map({ x: s.current.x, y: s.start.y });
    const T = map({ x: s.start.x + (s.direction === "right" ? s.required : -s.required), y: s.start.y });
    ctx.setLineDash([8, 8]);
    ctx.strokeStyle = "rgba(255,255,255,0.35)";
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(S.x, S.y);
    ctx.lineTo(T.x, T.y);
    ctx.stroke();
    ctx.setLineDash([]);
    ctx.strokeStyle = COLORS.accent;
    ctx.fillStyle = COLORS.accent;
    ctx.lineWidth = 6;
    ctx.lineCap = "round";
    ctx.beginPath();
    ctx.moveTo(S.x, S.y);
    ctx.lineTo(C.x, C.y);
    ctx.stroke();
    arrowHead(ctx, C.x + (s.direction === "right" ? 12 : -12), C.y, s.direction === "right" ? 0 : Math.PI, 18);
  }

  // Error Engine visual hint
  if (err?.visual) drawErrorVisual(ctx, err.visual, map, fx, cw);
}
