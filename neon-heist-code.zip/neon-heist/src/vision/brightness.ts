/**
 * Estimates scene brightness from a tiny (32×18) downscaled copy of the frame.
 * Pixels are read into a local canvas and discarded immediately — nothing is stored.
 */
export class BrightnessSampler {
  private canvas: HTMLCanvasElement | OffscreenCanvas | null = null;
  private ctx: CanvasRenderingContext2D | OffscreenCanvasRenderingContext2D | null = null;
  private readonly w = 32;
  private readonly h = 18;

  sample(video: HTMLVideoElement): number | null {
    try {
      if (!this.ctx) {
        this.canvas =
          typeof OffscreenCanvas !== "undefined"
            ? new OffscreenCanvas(this.w, this.h)
            : Object.assign(document.createElement("canvas"), { width: this.w, height: this.h });
        this.ctx = this.canvas.getContext("2d", { willReadFrequently: true }) as
          | CanvasRenderingContext2D
          | OffscreenCanvasRenderingContext2D
          | null;
      }
      if (!this.ctx) return null;
      this.ctx.drawImage(video, 0, 0, this.w, this.h);
      const data = this.ctx.getImageData(0, 0, this.w, this.h).data;
      let sum = 0;
      for (let i = 0; i < data.length; i += 4) {
        sum += 0.2126 * data[i] + 0.7152 * data[i + 1] + 0.0722 * data[i + 2];
      }
      return sum / (data.length / 4);
    } catch {
      return null;
    }
  }
}
