import { HandLandmarker } from "@mediapipe/tasks-vision";
import type { HandObservation } from "../types/vision";
import { MODELS, getVisionFileset } from "./visionRuntime";

export interface HandDetector {
  detect(video: HTMLVideoElement, timestampMs: number): HandObservation[];
  close(): void;
  delegate: "GPU" | "CPU";
}

async function create(delegate: "GPU" | "CPU"): Promise<HandLandmarker> {
  const fileset = await getVisionFileset();
  return HandLandmarker.createFromOptions(fileset, {
    baseOptions: { modelAssetPath: MODELS.hand, delegate },
    runningMode: "VIDEO",
    numHands: 2,
    minHandDetectionConfidence: 0.6,
    minHandPresenceConfidence: 0.6,
    minTrackingConfidence: 0.5,
  });
}

/**
 * MediaPipe Hand Landmarker wrapper. Returns 21 landmarks per hand, MIRRORED
 * (x → 1 - x) so that coordinates match the selfie view the user sees.
 * Tries the GPU delegate first and falls back to CPU.
 */
export async function createHandDetector(): Promise<HandDetector> {
  let landmarker: HandLandmarker;
  let delegate: "GPU" | "CPU" = "GPU";
  try {
    landmarker = await create("GPU");
  } catch {
    delegate = "CPU";
    landmarker = await create("CPU");
  }
  return {
    delegate,
    detect(video, timestampMs) {
      const result = landmarker.detectForVideo(video, timestampMs);
      const handedness = result.handedness ?? [];
      return result.landmarks.map((lm, i) => ({
        landmarks: lm.map((p) => ({ x: 1 - p.x, y: p.y, z: p.z })),
        score: handedness[i]?.[0]?.score ?? 0.9,
      }));
    },
    close() {
      landmarker.close();
    },
  };
}
