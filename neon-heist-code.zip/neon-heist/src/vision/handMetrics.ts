import { HAND, type Landmarks, type Point } from "../types/vision";
import { calculateDistance, centroid, clamp, cross, sub } from "../utils/math";

/**
 * Reference scale of a hand: distance wrist → middle-finger MCP (frame-height units).
 * Every hand-shape threshold is expressed relative to this, so recognition works
 * the same whether the hand is near or far, on any camera resolution.
 */
export function handSize(lm: Landmarks, aspect = 1): number {
  return calculateDistance(lm[HAND.WRIST], lm[HAND.MIDDLE_MCP], aspect);
}

/** Stable anchor used for motion: centroid of the palm (wrist + 4 MCP joints). */
export function palmCenter(lm: Landmarks): Point {
  return centroid([lm[HAND.WRIST], lm[HAND.INDEX_MCP], lm[HAND.MIDDLE_MCP], lm[HAND.RING_MCP], lm[HAND.PINKY_MCP]]);
}

/** Fraction (0..1) of landmarks inside the frame with a safety margin. */
export function frameCoverage(lm: Landmarks, margin = 0.01): number {
  let inside = 0;
  for (const p of lm) {
    if (p.x >= margin && p.x <= 1 - margin && p.y >= margin && p.y <= 1 - margin) inside++;
  }
  return lm.length ? inside / lm.length : 0;
}

/** true when every landmark is inside the frame (with a margin). */
export function isHandInFrame(lm: Landmarks, margin = 0.01): boolean {
  return frameCoverage(lm, margin) === 1;
}

/** Which way the hand should move to get back into the frame. */
export function directionToFrameCenter(lm: Landmarks): "left" | "right" | "up" | "down" | "center" {
  let minX = 1;
  let maxX = 0;
  let minY = 1;
  let maxY = 0;
  for (const p of lm) {
    minX = Math.min(minX, p.x);
    maxX = Math.max(maxX, p.x);
    minY = Math.min(minY, p.y);
    maxY = Math.max(maxY, p.y);
  }
  const overflow = {
    left: Math.max(0, 0.02 - minX),
    right: Math.max(0, maxX - 0.98),
    up: Math.max(0, 0.02 - minY),
    down: Math.max(0, maxY - 0.98),
  };
  // Move opposite to the edge that is overflowing the most.
  const worst = (Object.keys(overflow) as Array<keyof typeof overflow>).reduce((a, b) =>
    overflow[a] >= overflow[b] ? a : b,
  );
  if (overflow[worst] === 0) return "center";
  return worst === "left" ? "right" : worst === "right" ? "left" : worst === "up" ? "down" : "up";
}

const FINGERS = [
  { mcp: HAND.INDEX_MCP, pip: HAND.INDEX_PIP, dip: HAND.INDEX_DIP, tip: HAND.INDEX_TIP },
  { mcp: HAND.MIDDLE_MCP, pip: HAND.MIDDLE_PIP, dip: HAND.MIDDLE_DIP, tip: HAND.MIDDLE_TIP },
  { mcp: HAND.RING_MCP, pip: HAND.RING_PIP, dip: HAND.RING_DIP, tip: HAND.RING_TIP },
  { mcp: HAND.PINKY_MCP, pip: HAND.PINKY_PIP, dip: HAND.PINKY_DIP, tip: HAND.PINKY_TIP },
] as const;

/**
 * Straightness of a finger: direct MCP→TIP distance divided by the length of
 * the bone chain MCP→PIP→DIP→TIP. 1.0 = perfectly straight, ~0.4 = curled.
 */
export function fingerStraightness(lm: Landmarks, finger: number, aspect = 1): number {
  const f = FINGERS[finger];
  const chain =
    calculateDistance(lm[f.mcp], lm[f.pip], aspect) +
    calculateDistance(lm[f.pip], lm[f.dip], aspect) +
    calculateDistance(lm[f.dip], lm[f.tip], aspect);
  if (chain === 0) return 0;
  return calculateDistance(lm[f.mcp], lm[f.tip], aspect) / chain;
}

/**
 * A finger counts as extended when it is straight AND its tip is clearly
 * farther from the wrist than its PIP joint (rules out a straight-but-folded finger).
 */
export function isFingerExtended(lm: Landmarks, finger: number, aspect = 1): boolean {
  const f = FINGERS[finger];
  const straight = fingerStraightness(lm, finger, aspect) > 0.82;
  const reach =
    calculateDistance(lm[HAND.WRIST], lm[f.tip], aspect) > calculateDistance(lm[HAND.WRIST], lm[f.pip], aspect) * 1.12;
  return straight && reach;
}

/** Thumb is extended when its tip is far from the index MCP (relative to hand size). */
export function isThumbExtended(lm: Landmarks, aspect = 1): boolean {
  const size = handSize(lm, aspect);
  if (size === 0) return false;
  return calculateDistance(lm[HAND.THUMB_TIP], lm[HAND.INDEX_MCP], aspect) / size > 0.55;
}

/** Number of extended fingers among index, middle, ring, pinky (0..4). */
export function countExtendedFingers(lm: Landmarks, aspect = 1): number {
  let n = 0;
  for (let i = 0; i < 4; i++) if (isFingerExtended(lm, i, aspect)) n++;
  return n;
}

/**
 * Finger spread: angle (degrees) between index-finger and pinky-finger
 * directions (MCP → TIP). Fingers pressed together ≈ 5–12°, a wide open hand ≈ 30–50°.
 */
export function fingerSpreadAngle(lm: Landmarks, aspect = 1): number {
  const index = sub(lm[HAND.INDEX_TIP], lm[HAND.INDEX_MCP]);
  const pinky = sub(lm[HAND.PINKY_TIP], lm[HAND.PINKY_MCP]);
  const ax = index.x * aspect;
  const bx = pinky.x * aspect;
  const dot = ax * bx + index.y * pinky.y;
  const na = Math.hypot(ax, index.y);
  const nb = Math.hypot(bx, pinky.y);
  if (na === 0 || nb === 0) return 0;
  return (Math.acos(clamp(dot / (na * nb), -1, 1)) * 180) / Math.PI;
}

/**
 * How much the palm plane faces the camera (0..~0.7).
 * Area of the triangle wrist / index MCP / pinky MCP, normalized by hand size².
 * A palm (or back of hand) facing the camera ≈ 0.45–0.65; a hand seen edge-on → < 0.15.
 */
export function palmFacingScore(lm: Landmarks, aspect = 1): number {
  const size = handSize(lm, aspect);
  if (size === 0) return 0;
  const a = sub(lm[HAND.INDEX_MCP], lm[HAND.WRIST]);
  const b = sub(lm[HAND.PINKY_MCP], lm[HAND.WRIST]);
  return Math.abs(cross(a, b, aspect)) / (size * size);
}

/** Normalized thumb-tip ↔ index-tip distance (relative to hand size). */
export function calculateFingerDistance(lm: Landmarks, aspect = 1): number {
  const size = handSize(lm, aspect);
  if (size === 0) return Infinity;
  return calculateDistance(lm[HAND.THUMB_TIP], lm[HAND.INDEX_TIP], aspect) / size;
}

/**
 * Tracks landmark "shape jitter": how much the hand's internal configuration
 * changes between frames once position and scale are factored out.
 * Low jitter ⇒ the model sees the hand clearly ⇒ higher detection confidence.
 */
export class ShapeJitterTracker {
  private prevRel: Point[] | null = null;
  private ema = 0;

  reset(): void {
    this.prevRel = null;
    this.ema = 0;
  }

  update(lm: Landmarks, aspect = 1): number {
    const size = handSize(lm, aspect) || 1;
    const c = palmCenter(lm);
    const rel = lm.map((p) => ({ x: ((p.x - c.x) * aspect) / size, y: (p.y - c.y) / size }));
    if (this.prevRel) {
      let d = 0;
      for (let i = 0; i < rel.length; i++) d += Math.hypot(rel[i].x - this.prevRel[i].x, rel[i].y - this.prevRel[i].y);
      d /= rel.length;
      this.ema = this.ema * 0.8 + d * 0.2;
    }
    this.prevRel = rel;
    return this.ema;
  }

  /** 0..1 stability score derived from jitter. */
  stability(): number {
    return clamp(1 - Math.max(0, this.ema - 0.02) / 0.12, 0.3, 1);
  }
}
