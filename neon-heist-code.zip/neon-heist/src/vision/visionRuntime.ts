import { FilesetResolver } from "@mediapipe/tasks-vision";

type WasmFileset = Awaited<ReturnType<typeof FilesetResolver.forVisionTasks>>;

const BASE = import.meta.env.BASE_URL.replace(/\/$/, "");

/** Self-hosted wasm runtime (copied from node_modules by scripts/copy-mediapipe-wasm.mjs). */
export const LOCAL_WASM = `${BASE}/mediapipe/wasm`;
/** Fallback if the local copy is missing (e.g. dev without the copy step). */
export const CDN_WASM = "https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.21/wasm";

export const MODELS = {
  hand: `${BASE}/models/hand_landmarker.task`,
  pose: `${BASE}/models/pose_landmarker_lite.task`,
} as const;

let filesetPromise: Promise<WasmFileset> | null = null;

async function localWasmAvailable(): Promise<boolean> {
  try {
    const res = await fetch(`${LOCAL_WASM}/vision_wasm_internal.js`, { method: "HEAD" });
    const type = res.headers.get("content-type") ?? "";
    // SPA hosts may answer unknown paths with index.html — make sure it's JS.
    return res.ok && !type.includes("text/html");
  } catch {
    return false;
  }
}

/**
 * Loads the MediaPipe Tasks Vision wasm runtime once.
 * Only the model + runtime are downloaded; camera frames never leave the device.
 */
export function getVisionFileset(): Promise<WasmFileset> {
  if (!filesetPromise) {
    filesetPromise = (async () => {
      const base = (await localWasmAvailable()) ? LOCAL_WASM : CDN_WASM;
      return FilesetResolver.forVisionTasks(base);
    })();
    filesetPromise.catch(() => {
      filesetPromise = null;
    });
  }
  return filesetPromise;
}
