import type { GesturePhase, SwipeAttempt } from "../types/gesture";
import { calculateVelocity, mean } from "../utils/math";
import { SWIPE } from "./gestureConfig";

/** One smoothed observation of the hand anchor (palm center). */
export interface MotionSample {
  t: number;
  x: number;
  y: number;
  /** Detection presence score 0..1. */
  score: number;
}

export type SwipeDirection = "left" | "right";

/** Travel within this distance of the maximum counts as "reached the peak". */
const PEAK_TOLERANCE = 0.006;

export interface SwipeDirectionResult {
  direction: SwipeDirection | null;
  dx: number;
  dy: number;
  durationMs: number;
  avgSpeed: number;
}

/**
 * Pure classification of a motion stroke: returns the swipe direction if the
 * stroke is a valid horizontal swipe (far enough, fast enough, horizontal enough).
 * `dx = currentX - startX`, `velocity = distance / deltaTime`.
 */
export function detectSwipeDirection(
  samples: readonly MotionSample[],
  minDistance: number = SWIPE.minDistance,
): SwipeDirectionResult {
  if (samples.length < 2) return { direction: null, dx: 0, dy: 0, durationMs: 0, avgSpeed: 0 };
  const start = samples[0];
  // Peak = first sample within PEAK_TOLERANCE of the largest horizontal displacement.
  let maxAbs = 0;
  for (const s of samples) maxAbs = Math.max(maxAbs, Math.abs(s.x - start.x));
  const peak = samples.find((s) => Math.abs(s.x - start.x) >= maxAbs - PEAK_TOLERANCE) ?? samples[0];
  const dx = peak.x - start.x;
  const dy = peak.y - start.y;
  const durationMs = Math.max(1, peak.t - start.t);
  const avgSpeed = Math.abs(dx) / (durationMs / 1000);
  const horizontal = Math.abs(dy) <= Math.abs(dx) * SWIPE.maxVerticalRatio;
  const valid =
    Math.abs(dx) >= minDistance && horizontal && durationMs <= SWIPE.maxDurationMs && avgSpeed >= SWIPE.minAvgSpeed;
  return { direction: valid ? (dx > 0 ? "right" : "left") : null, dx, dy, durationMs, avgSpeed };
}

/** Hand speed (frame-widths/s) over the last `windowMs` of samples. */
export function calculateHandVelocity(samples: readonly MotionSample[], windowMs = 110) {
  if (samples.length < 2) return { vx: 0, vy: 0, speed: 0 };
  const tEnd = samples[samples.length - 1].t;
  let i = samples.length - 1;
  while (i > 0 && tEnd - samples[i - 1].t <= windowMs) i--;
  if (i === samples.length - 1) i = samples.length - 2;
  return calculateVelocity(samples.slice(i));
}

export type SwipeUpdate =
  | { kind: "none" }
  /** A stroke in this detector's direction finished and needs classification. */
  | { kind: "stroke"; attempt: SwipeAttempt; samples: MotionSample[] };

/**
 * Temporal state machine for ONE swipe direction.
 *
 * IDLE ──(speed in direction > startSpeed)──▶ POSSIBLE
 * POSSIBLE ──(sustained for startFrames)──▶ TRACKING   (else back to IDLE)
 * TRACKING ──(motion stops / reverses / hand lost)──▶ stroke emitted
 *    → engine classifies it: valid → GESTURE_CONFIRMED → ACTION_TRIGGERED → COOLDOWN
 *                            invalid → IDLE (with a concrete error)
 * COOLDOWN ──(time elapsed AND hand settled)──▶ IDLE
 *
 * One physical swipe can therefore emit at most one stroke, and the cooldown
 * + settle requirement prevents one swipe from causing several slide changes.
 */
export class SwipeDetector {
  phase: GesturePhase = "IDLE";
  readonly direction: SwipeDirection;
  private readonly sign: 1 | -1;
  private minDistance: number;

  private history: MotionSample[] = [];
  private stroke: MotionSample[] = [];
  private fastFrames = 0;
  private slowSince: number | null = null;
  private missingSince: number | null = null;
  private leftFrame = false;
  private cooldownUntil = 0;
  private suppressedUntil = 0;

  constructor(direction: SwipeDirection, minDistance: number = SWIPE.minDistance) {
    this.direction = direction;
    this.sign = direction === "right" ? 1 : -1;
    this.minDistance = minDistance;
  }

  setMinDistance(d: number): void {
    this.minDistance = d;
  }

  getMinDistance(): number {
    return this.minDistance;
  }

  /** Current stroke (for live overlay drawing). */
  getStroke(): readonly MotionSample[] {
    return this.phase === "TRACKING" ? this.stroke : [];
  }

  /** Called by the engine when the stroke was accepted and the action fired. */
  markTriggered(t: number): void {
    this.phase = "COOLDOWN";
    this.cooldownUntil = t + SWIPE.cooldownMs;
    this.stroke = [];
  }

  /**
   * Called by the engine when the stroke was classified as invalid: wait until
   * the hand settles so the rest of the same movement can't start a new stroke.
   */
  markRejected(t: number): void {
    this.phase = "COOLDOWN";
    this.cooldownUntil = t;
    this.stroke = [];
  }

  /** Ignore strokes in this direction until t (return-stroke suppression). */
  suppressUntil(t: number): void {
    this.suppressedUntil = Math.max(this.suppressedUntil, t);
  }

  isSuppressed(t: number): boolean {
    return t < this.suppressedUntil;
  }

  reset(): void {
    this.phase = "IDLE";
    this.history = [];
    this.stroke = [];
    this.fastFrames = 0;
    this.slowSince = null;
    this.missingSince = null;
    this.leftFrame = false;
  }

  /**
   * Feed one frame. `sample` is null when no hand is visible.
   * `t` is the frame timestamp (needed when sample is null).
   */
  update(sample: MotionSample | null, t: number): SwipeUpdate {
    if (sample) {
      // A gap in tracking breaks motion continuity: never compute velocity across it.
      const last = this.history[this.history.length - 1];
      if (last && sample.t - last.t > 250 && this.phase !== "TRACKING") this.history = [];
      this.history.push(sample);
      while (this.history.length > 2 && sample.t - this.history[0].t > 700) this.history.shift();
    }

    switch (this.phase) {
      case "COOLDOWN": {
        const v = calculateHandVelocity(this.history);
        const settled = !sample || Math.abs(v.vx) < SWIPE.startSpeed;
        if (t >= this.cooldownUntil && settled) this.phase = "IDLE";
        return { kind: "none" };
      }
      case "GESTURE_CONFIRMED":
      case "ACTION_TRIGGERED":
        return { kind: "none" };
      case "IDLE":
      case "POSSIBLE": {
        if (!sample) {
          this.fastFrames = 0;
          this.phase = "IDLE";
          return { kind: "none" };
        }
        const v = calculateHandVelocity(this.history);
        if (v.vx * this.sign > SWIPE.startSpeed) {
          this.fastFrames++;
          this.phase = "POSSIBLE";
          if (this.fastFrames >= SWIPE.startFrames) this.beginTracking(sample.t);
        } else {
          this.fastFrames = 0;
          this.phase = "IDLE";
        }
        return { kind: "none" };
      }
      case "TRACKING":
        return this.track(sample, t);
    }
  }

  private beginTracking(now: number): void {
    // Backtrack to where the movement in this direction actually began.
    let i = this.history.length - 1;
    while (i > 0) {
      const cur = this.history[i];
      const prev = this.history[i - 1];
      // Walk back only while the hand was actually moving our way (not standing still).
      const movingOurWay = (cur.x - prev.x) * this.sign > 0.0015;
      if (!movingOurWay || now - prev.t > 350 || cur.t - prev.t > 150) break;
      i--;
    }
    this.stroke = this.history.slice(i);
    this.phase = "TRACKING";
    this.slowSince = null;
    this.missingSince = null;
    this.leftFrame = this.stroke.some((s) => s.x < SWIPE.edgeMargin || s.x > 1 - SWIPE.edgeMargin);
  }

  private track(sample: MotionSample | null, t: number): SwipeUpdate {
    const start = this.stroke[0];
    if (!sample) {
      // Short dropouts happen with fast motion blur: tolerate ~150 ms.
      this.missingSince ??= t;
      if (t - this.missingSince > 150) {
        const last = this.stroke[this.stroke.length - 1];
        if (last.x < 0.15 || last.x > 0.85) this.leftFrame = true;
        return this.finish(true);
      }
      return { kind: "none" };
    }
    this.missingSince = null;
    this.stroke.push(sample);
    if (sample.x < SWIPE.edgeMargin || sample.x > 1 - SWIPE.edgeMargin) this.leftFrame = true;

    const v = calculateHandVelocity(this.history);
    const along = v.vx * this.sign;
    if (along < SWIPE.stopSpeed) {
      this.slowSince ??= sample.t;
    } else {
      this.slowSince = null;
    }
    const peakAlong = Math.max(...this.stroke.map((s) => (s.x - start.x) * this.sign));
    const curAlong = (sample.x - start.x) * this.sign;
    const reversed = peakAlong - curAlong > SWIPE.reversalDistance;
    const stopped = this.slowSince !== null && sample.t - this.slowSince >= SWIPE.stopHoldMs;
    const tooLong = sample.t - start.t > SWIPE.abortAfterMs;
    // Early confirm: once the stroke is clearly long enough, don't wait for the
    // hand to stop — this keeps the action latency low (snappy slide change).
    const clearlyLongEnough = curAlong >= this.minDistance * 1.1;
    if (reversed || stopped || tooLong || clearlyLongEnough) return this.finish(false);
    return { kind: "none" };
  }

  private finish(lostTracking: boolean): SwipeUpdate {
    const samples = this.stroke;
    this.stroke = [];
    this.phase = "IDLE";
    this.fastFrames = 0;
    this.slowSince = null;
    this.missingSince = null;
    if (samples.length < 2) return { kind: "none" };

    const start = samples[0];
    // Peak = first sample that got (almost) as far as the maximum travel. Ignoring the
    // last few millimetres stops the smoothing filter's slow "creep" from inflating duration.
    let maxTravel = 0;
    for (const s of samples) maxTravel = Math.max(maxTravel, (s.x - start.x) * this.sign);
    let peakIdx = 0;
    while (peakIdx < samples.length - 1 && (samples[peakIdx].x - start.x) * this.sign < maxTravel - PEAK_TOLERANCE) peakIdx++;
    const peak = samples[peakIdx];
    const end = samples[samples.length - 1];
    const dx = peak.x - start.x;
    const durationMs = Math.max(1, peak.t - start.t);

    // Silently ignore fidgeting — tiny motions, or short AND slow drifts, are not gesture attempts.
    const travel = dx * this.sign;
    const speed = travel / (durationMs / 1000);
    const slowDrift = speed < SWIPE.driftSpeed || (speed < SWIPE.minAvgSpeed && travel < this.minDistance * 0.6);
    if (travel < SWIPE.minAttemptDistance || slowDrift) return { kind: "none" };

    let peakSpeed = 0;
    for (let i = 1; i < samples.length; i++) {
      const dt = (samples[i].t - samples[i - 1].t) / 1000;
      if (dt > 0) peakSpeed = Math.max(peakSpeed, Math.abs(samples[i].x - samples[i - 1].x) / dt);
    }

    // Did the hand reach the frame edge BEFORE covering the required distance?
    let reachedBeforeEdge = 0;
    let hitEdge = false;
    for (const s of samples) {
      if (s.x < SWIPE.edgeMargin || s.x > 1 - SWIPE.edgeMargin) {
        hitEdge = true;
        break;
      }
      reachedBeforeEdge = Math.max(reachedBeforeEdge, (s.x - start.x) * this.sign);
    }
    const leftFrame = (this.leftFrame || lostTracking) && (hitEdge || lostTracking) && reachedBeforeEdge < this.minDistance;
    this.leftFrame = false;

    const attempt: SwipeAttempt = {
      direction: this.direction,
      start: { x: start.x, y: start.y },
      end: { x: end.x, y: end.y },
      peak: { x: peak.x, y: peak.y },
      dx,
      dy: peak.y - start.y,
      durationMs,
      avgSpeed: Math.abs(dx) / (durationMs / 1000),
      peakSpeed,
      leftFrame: leftFrame && (hitEdge || end.x < 0.15 || end.x > 0.85),
      meanY: mean(samples.map((s) => s.y)),
      meanScore: mean(samples.map((s) => s.score)),
      requiredDistance: this.minDistance,
    };
    // lostTracking away from the edges is reported via a low score (motion blur).
    if (lostTracking && !attempt.leftFrame && Math.abs(dx) < this.minDistance) {
      attempt.meanScore = Math.min(attempt.meanScore, 0.4);
    }
    return { kind: "stroke", attempt, samples };
  }
}


/** detectSwipe — alias used by the game docs/tests: classify a stroke into left/right/null. */
export const detectSwipe = detectSwipeDirection;
