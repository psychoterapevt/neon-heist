import type { GesturePhase } from "../types/gesture";
import type { Landmarks } from "../types/vision";
import { HAND } from "../types/vision";
import { calculateFingerDistance, handSize, palmFacingScore } from "../vision/handMetrics";
import { calculateDistance, clamp } from "../utils/math";
import { PINCH } from "./gestureConfig";

export interface PinchAnalysis {
  /** Thumb-tip ↔ index-tip distance / hand size. */
  ratio: number;
  closed: boolean;
  /** 0..1 how close the fingers are to a full pinch (1 = touching). */
  closeness: number;
  facing: number;
  /** Index-tip distance from the wrist / hand size. A fist curls the index into the palm (< ~0.9). */
  indexReach: number;
}

/** Below this index reach the hand is a fist, not a pinch. */
export const MIN_INDEX_REACH = 0.9;

/**
 * Pinch = thumb tip and index tip close together, measured relative to hand
 * size: distance(indexTip, thumbTip) / distance(wrist, middleMCP).
 * `wasClosed` enables hysteresis (close < 0.30, release > 0.45) so the state
 * doesn't flicker around a single threshold.
 */
export function detectPinch(lm: Landmarks, aspect = 1, wasClosed = false): PinchAnalysis {
  const ratio = calculateFingerDistance(lm, aspect);
  const size = handSize(lm, aspect) || 1;
  const indexReach = calculateDistance(lm[HAND.WRIST], lm[HAND.INDEX_TIP], aspect) / size;
  const fingersTouch = wasClosed ? ratio < PINCH.releaseRatio : ratio < PINCH.closeRatio;
  // A fist also brings thumb and index together — require the index to reach forward.
  const closed = fingersTouch && indexReach >= MIN_INDEX_REACH;
  const closeness = clamp(1 - (ratio - 0.1) / (PINCH.approachRatio - 0.1));
  return { ratio, closed, closeness, facing: palmFacingScore(lm, aspect), indexReach };
}

export type PinchUpdate =
  | { kind: "none" }
  | { kind: "confirmed"; confidence: number }
  | { kind: "near-miss"; reason: "PINCH_TOO_WIDE" | "PINCH_NOT_HELD" | "PALM_NOT_FACING"; analysis: PinchAnalysis };

/**
 * Pinch state machine:
 * IDLE → POSSIBLE (fingers approaching) → TRACKING (closed, debounce holdMs)
 *      → GESTURE_CONFIRMED → ACTION_TRIGGERED → COOLDOWN (until released) → IDLE
 */
export class PinchDetector {
  phase: GesturePhase = "IDLE";
  closed = false;
  lastAnalysis: PinchAnalysis | null = null;
  private closedSince: number | null = null;
  private approachSince: number | null = null;
  private approachReported = false;
  private flickers: number[] = [];
  private edgeOnSince: number | null = null;
  private edgeOnReported = false;

  reset(): void {
    this.phase = "IDLE";
    this.closed = false;
    this.lastAnalysis = null;
    this.closedSince = null;
    this.approachSince = null;
    this.approachReported = false;
    this.flickers = [];
    this.edgeOnSince = null;
    this.edgeOnReported = false;
  }

  markTriggered(): void {
    this.phase = "COOLDOWN";
  }

  update(lm: Landmarks | null, aspect: number, t: number, presence = 1): PinchUpdate {
    if (!lm) {
      this.closed = false;
      this.closedSince = null;
      this.approachSince = null;
      this.lastAnalysis = null;
      this.phase = "IDLE"; // hand gone = released
      return { kind: "none" };
    }
    const a = detectPinch(lm, aspect, this.closed);
    this.lastAnalysis = a;
    const wasClosed = this.closed;
    this.closed = a.closed;

    if (this.phase === "COOLDOWN") {
      if (!a.closed) this.phase = "IDLE";
      return { kind: "none" };
    }

    if (a.closed) {
      this.approachSince = null;
      this.closedSince ??= t;
      this.phase = "TRACKING";
      if (t - this.closedSince >= PINCH.holdMs) {
        // Confirmed → the action fires once; stay in COOLDOWN until the fingers open again.
        this.phase = "COOLDOWN";
        this.closedSince = null;
        const confidence = clamp((0.55 + 0.45 * a.closeness) * presence * clamp(a.facing / 0.35, 0.6, 1));
        return { kind: "confirmed", confidence };
      }
      return { kind: "none" };
    }

    // Released before the hold time → a flicker.
    if (wasClosed && this.closedSince !== null && t - this.closedSince < PINCH.holdMs) {
      this.flickers.push(t);
    }
    this.closedSince = null;
    this.flickers = this.flickers.filter((f) => t - f < PINCH.flickerWindowMs);
    if (this.flickers.length >= 2) {
      this.flickers = [];
      return { kind: "near-miss", reason: "PINCH_NOT_HELD", analysis: a };
    }

    // Edge-on hand: thumb/index can't be measured reliably.
    if (a.facing < PINCH.minFacing) {
      this.edgeOnSince ??= t;
      if (!this.edgeOnReported && t - this.edgeOnSince > 700) {
        this.edgeOnReported = true;
        return { kind: "near-miss", reason: "PALM_NOT_FACING", analysis: a };
      }
    } else {
      this.edgeOnSince = null;
      this.edgeOnReported = false;
    }

    if (a.ratio < PINCH.approachRatio) {
      this.phase = "POSSIBLE";
      this.approachSince ??= t;
      if (!this.approachReported && t - this.approachSince >= PINCH.nearMissMs) {
        this.approachReported = true;
        return { kind: "near-miss", reason: "PINCH_TOO_WIDE", analysis: a };
      }
    } else {
      this.phase = "IDLE";
      this.approachSince = null;
      this.approachReported = false;
    }
    return { kind: "none" };
  }
}
