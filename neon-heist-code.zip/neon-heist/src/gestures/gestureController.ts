import type { ExpectedAction, GestureError, GestureEvent, GestureKind, GesturePhase, SwipeAttempt } from "../types/gesture";
import { HAND, type Landmarks, type Point, type VisionFrame } from "../types/vision";
import { LandmarkSmoother } from "../vision/landmarkSmoother";
import { ShapeJitterTracker, frameCoverage, handSize, palmCenter } from "../vision/handMetrics";
import { analyzeBody, checkPosition, type BodyMetrics, type PositionCheck } from "../vision/poseMetrics";
import { calculateDistance, clamp } from "../utils/math";
import { SwipeDetector, calculateHandVelocity, type MotionSample } from "./swipeDetector";
import { JumpDetector, detectJump, type JumpAnalysis } from "./jumpDetector";
import { OpenPalmDetector, detectOpenPalm } from "./openPalmDetector";
import { PinchDetector } from "./pinchDetector";
import { ACTION_COOLDOWN_MS, HAND_CFG, PALM, PINCH, SWIPE } from "./gestureConfig";
import { ErrorTracker, classifyError, conditionError } from "../errors/errorEngine";

export type ControllerMode = "idle" | "setup" | "tutorial" | "game";

export interface ControllerContext {
  mode: ControllerMode;
  /** What the game currently expects — context-aware error explanations. */
  expected: ExpectedAction;
  /** Which gestures can fire right now. */
  enabled: Record<GestureKind, boolean>;
}

export interface LiveSwipe {
  direction: "left" | "right";
  start: Point;
  current: Point;
  required: number;
}

export type TrackingStatus = "tracking" | "lost" | "multiple";

export interface ControllerSnapshot {
  t: number;
  aspect: number;
  hand: Landmarks | null;
  otherHands: Landmarks[];
  pose: Landmarks | null;
  body: BodyMetrics | null;
  position: PositionCheck | null;
  anchor: Point | null;
  /** 0..1 live detection confidence (internal quality indicator, not a probability). */
  confidence: number;
  phases: Record<GestureKind, GesturePhase>;
  jump: JumpAnalysis | null;
  palmProgress: number;
  pinchCloseness: number;
  pinchClosed: boolean;
  liveSwipe: LiveSwipe | null;
  error: GestureError | null;
  errorSeq: number;
  ready: boolean;
  tracking: TrackingStatus;
  lastEvent: GestureEvent | null;
}

export interface ControllerOutput {
  events: GestureEvent[];
  /** Failed attempts (one best error each) — statistics & score penalty. */
  failures: GestureError[];
  /** Errors newly shown this frame. */
  prompts: GestureError[];
  snapshot: ControllerSnapshot;
}

export const ALL_ENABLED: Record<GestureKind, boolean> = { MOVE_LEFT: true, MOVE_RIGHT: true, JUMP: true, HACK: true, SHIELD: true };


/**
 * GestureController — custom recognition pipeline for NEON HEIST.
 *   landmarks → primary hand → smoothing → 5 temporal state machines
 *   → context-aware Error Engine → gesture events for the game.
 * Pure TypeScript (no DOM): the whole pipeline is unit-tested with synthetic landmarks.
 */
export class GestureController {
  context: ControllerContext = { mode: "idle", expected: null, enabled: { ...ALL_ENABLED } };

  readonly moveRight = new SwipeDetector("right", SWIPE.minDistance);
  readonly moveLeft = new SwipeDetector("left", SWIPE.minDistance);
  readonly jump = new JumpDetector();
  readonly shield = new OpenPalmDetector();
  readonly hack = new PinchDetector();

  private smoother = new LandmarkSmoother();
  private jitter = new ShapeJitterTracker();
  private tracker: ErrorTracker;
  private prompts: GestureError[] = [];
  private prevAnchor: Point | null = null;
  private motion: MotionSample[] = [];
  private lastHandAt = -Infinity;
  private handVisibleSince: number | null = null;
  private lastPoses: Landmarks[] = [];
  private lastPoseAt = -Infinity;
  private lastBodyAt = -Infinity;
  private lastJump: JumpAnalysis | null = null;
  private lastFired: Partial<Record<GestureKind, number>> = {};
  private lastEvent: GestureEvent | null = null;
  private lastFailedStroke: { direction: "left" | "right"; endX: number; t: number } | null = null;
  private multipleSince: number | null = null;
  private shieldTrySince: number | null = null;
  private lastShieldHint = -Infinity;
  private actionShownUntil: Partial<Record<GestureKind, number>> = {};

  constructor() {
    this.tracker = new ErrorTracker((e) => this.prompts.push(e));
  }

  setContext(patch: Partial<ControllerContext>): void {
    const prevMode = this.context.mode;
    const prevExpected = this.context.expected;
    this.context = { ...this.context, ...patch, enabled: { ...this.context.enabled, ...(patch.enabled ?? {}) } };
    if (patch.mode && patch.mode !== prevMode) this.tracker.reset();
    if (patch.expected !== undefined && patch.expected !== prevExpected) this.shieldTrySince = null;
  }

  process(frame: VisionFrame): ControllerOutput {
    const t = frame.t;
    const aspect = frame.aspect || 1;
    const events: GestureEvent[] = [];
    const failures: GestureError[] = [];
    this.prompts = [];
    const { mode, expected, enabled } = this.context;
    const active = mode === "tutorial" || mode === "game";

    // ---------- body (pose runs at a lower rate) ----------
    if (frame.poses) {
      this.lastPoses = frame.poses.map((p) => p.landmarks);
      this.lastPoseAt = t;
    } else if (t - this.lastPoseAt > 700) this.lastPoses = [];
    const pose = this.lastPoses[0] ?? null;
    const body = pose ? analyzeBody(pose, aspect) : null;
    if (body?.shouldersVisible) this.lastBodyAt = t;
    const lowLimitY = body?.lowHandLimitY ?? 0.86;

    // ---------- primary hand ----------
    let primaryIdx = -1;
    let best = -Infinity;
    frame.hands.forEach((h, i) => {
      const c = palmCenter(h.landmarks);
      const continuity = this.prevAnchor ? Math.max(0, 0.3 - calculateDistance(c, this.prevAnchor, aspect)) * 4 : 0;
      const s = handSize(h.landmarks, aspect) * h.score + continuity;
      if (s > best) {
        best = s;
        primaryIdx = i;
      }
    });
    const primary = primaryIdx >= 0 ? frame.hands[primaryIdx] : null;
    let hand: Landmarks | null = null;
    let anchor: Point | null = null;
    let presence = 0;
    let coverage = 0;
    if (primary) {
      if (t - this.lastHandAt > 250) this.motion = [];
      hand = this.smoother.smooth(primary.landmarks, t, aspect);
      anchor = palmCenter(hand);
      presence = primary.score;
      coverage = frameCoverage(hand, 0.005);
      this.jitter.update(hand, aspect);
      this.lastHandAt = t;
      this.prevAnchor = anchor;
      this.handVisibleSince ??= t;
      this.motion.push({ t, x: anchor.x, y: anchor.y, score: presence });
    } else {
      this.smoother.reset();
      this.jitter.reset();
      this.handVisibleSince = null;
      if (t - this.lastHandAt > 400) this.prevAnchor = null;
    }
    while (this.motion.length > 2 && t - this.motion[0].t > 600) this.motion.shift();
    const speed = primary ? calculateHandVelocity(this.motion).speed : 0;
    const confidence = primary ? clamp(presence * this.jitter.stability() * (0.4 + 0.6 * coverage)) : 0;

    // ---------- global conditions ----------
    const many = this.lastPoses.length > 1 || frame.hands.length > 2;
    if (many) this.multipleSince ??= t;
    else this.multipleSince = null;
    const multiple = this.multipleSince !== null && t - this.multipleSince > 600;
    const lost = active && t - this.lastBodyAt > HAND_CFG.trackingLostMs;
    const tracking: TrackingStatus = multiple ? "multiple" : lost ? "lost" : "tracking";
    const blocked = multiple || lost;

    const want = (g: GestureKind) => active && enabled[g] && !blocked;
    const fire = (gesture: GestureKind, conf: number) => {
      if (t - (this.lastFired[gesture] ?? -Infinity) < ACTION_COOLDOWN_MS) return;
      const ev: GestureEvent = { gesture, confidence: clamp(conf), t };
      this.lastFired[gesture] = t;
      this.lastEvent = ev;
      this.actionShownUntil[gesture] = t + 300;
      events.push(ev);
      this.tracker.reportSuccess(t);
    };
    const fail = (errs: GestureError[]) => {
      const e = this.tracker.reportAttempt(errs, t);
      if (e) failures.push(e);
    };

    // ---------- JUMP (pose frames only) ----------
    let jumpA: JumpAnalysis | null = this.lastJump;
    if (want("JUMP")) {
      if (frame.poses) {
        jumpA = detectJump(pose);
        this.lastJump = jumpA;
        const vis = Math.min(...[15, 16].map((i) => pose?.[i]?.visibility ?? 0));
        const u = this.jump.update(jumpA, t, 0.5 + 0.5 * clamp(vis));
        if (u.kind === "confirmed") fire("JUMP", u.confidence);
        else if (u.kind === "near-miss" && expected === "JUMP") fail(classifyError({ kind: "jump", analysis: u.analysis }));
      }
    } else {
      this.jump.reset();
    }
    const armsUp = this.jump.phase !== "IDLE";

    // ---------- MOVE LEFT / MOVE RIGHT (two independent swipe state machines) ----------
    const sample = primary && anchor && presence >= HAND_CFG.minPresence ? { t, x: anchor.x, y: anchor.y, score: presence } : null;
    for (const det of [this.moveRight, this.moveLeft]) {
      const other = det === this.moveRight ? this.moveLeft : this.moveRight;
      const gesture: GestureKind = det.direction === "right" ? "MOVE_RIGHT" : "MOVE_LEFT";
      if (!want(gesture)) {
        det.reset();
        continue;
      }
      const u = det.update(sample, t);
      if (u.kind !== "stroke") continue;
      const strokeStart = u.samples[0].t;
      if (det.isSuppressed(strokeStart) || armsUp) {
        det.markRejected(t); // hand returning after a move, or arms moving for a jump — not a move
        continue;
      }
      const failed = this.lastFailedStroke;
      this.lastFailedStroke = null;
      if (failed && failed.direction !== det.direction && strokeStart - failed.t < SWIPE.repositionWindowMs && Math.abs(u.attempt.start.x - failed.endX) < SWIPE.repositionRadius) {
        det.markRejected(t);
        continue;
      }
      other.suppressUntil(t + SWIPE.returnStrokeMs);
      const errs = classifyError({ kind: "swipe", attempt: u.attempt });
      if (errs.length === 0) {
        det.markTriggered(t);
        fire(gesture, this.swipeConfidence(u.attempt));
      } else {
        det.markRejected(t);
        this.lastFailedStroke = { direction: det.direction, endX: u.attempt.peak.x, t };
        // Diagonal/vertical strokes are only explained when a move is actually expected.
        const relevant = errs.filter((e) => e.type !== "WRONG_DIRECTION" || expected === "MOVE");
        if (relevant.length) fail(relevant);
      }
    }

    // ---------- SHIELD (open palm) ----------
    if (want("SHIELD")) {
      const analysis = hand ? detectOpenPalm(hand, aspect) : null;
      const aboveHead = !!anchor && !!jumpA && jumpA.pose !== "NO_BODY" && anchor.y < jumpA.requiredY;
      const eligible = !!anchor && !aboveHead && !armsUp && anchor.y < lowLimitY && presence >= HAND_CFG.minPresence && coverage >= 0.85;
      const u = this.shield.update(analysis, speed, t, eligible, presence);
      if (u.kind === "confirmed") {
        fire("SHIELD", u.confidence * this.jitter.stability());
        this.shieldTrySince = null;
      }
      // Context-aware explanation: a drone is charging and the shield isn't coming.
      if (expected === "SHIELD" && hand && anchor && analysis && this.shield.phase !== "TRACKING" && this.shield.phase !== "COOLDOWN") {
        this.shieldTrySince ??= t;
        if (t - this.shieldTrySince >= PALM.nearMissMs && t - this.lastShieldHint > 1800) {
          const errs = classifyError({ kind: "palm", analysis, anchor, lowLimitY, presence });
          if (errs.length) {
            this.lastShieldHint = t;
            fail(errs);
          }
        }
      } else if (!hand || this.shield.phase === "COOLDOWN") {
        this.shieldTrySince = null;
      }
    } else {
      this.shield.reset();
    }

    // ---------- HACK (pinch) ----------
    if (want("HACK")) {
      const trusted = hand && presence >= PINCH.minScore ? hand : null; // low confidence never fires
      const u = this.hack.update(trusted, aspect, t, presence);
      if (u.kind === "confirmed") fire("HACK", u.confidence * this.jitter.stability());
      else if (u.kind === "near-miss" && expected === "HACK" && hand) {
        fail(classifyError({ kind: "pinch", reason: u.reason, analysis: u.analysis, presence, thumb: hand[HAND.THUMB_TIP], index: hand[HAND.INDEX_TIP] }));
      }
      if (expected === "HACK" && hand && !trusted && this.handVisibleSince !== null && t - this.handVisibleSince > 800) {
        const a = { ratio: 1, closed: false, closeness: 0, facing: 1, indexReach: 1 };
        fail(classifyError({ kind: "pinch", reason: "PINCH_NOT_HELD", analysis: a, presence, thumb: hand[HAND.THUMB_TIP], index: hand[HAND.INDEX_TIP] }));
        this.handVisibleSince = t;
      }
    } else {
      this.hack.reset();
    }

    // ---------- conditions & error lifecycle ----------
    const cond: GestureError[] = [];
    if (active && multiple) cond.push(conditionError("MULTIPLE_PEOPLE"));
    if (lost) cond.push(conditionError("TRACKING_LOST"));
    const tracked = this.tracker.update(cond, t);

    // ---------- snapshot ----------
    const trk = this.moveRight.phase === "TRACKING" ? this.moveRight : this.moveLeft.phase === "TRACKING" ? this.moveLeft : null;
    const stroke = trk?.getStroke();
    const liveSwipe: LiveSwipe | null =
      trk && stroke && stroke.length && anchor
        ? { direction: trk.direction, start: { x: stroke[0].x, y: stroke[0].y }, current: anchor, required: trk.getMinDistance() }
        : null;

    const snapshot: ControllerSnapshot = {
      t,
      aspect,
      hand,
      otherHands: frame.hands.filter((_, i) => i !== primaryIdx).map((h) => h.landmarks),
      pose,
      body,
      position: this.lastPoses.length || mode === "setup" ? checkPosition(this.lastPoses, frame.hands.length, frame.brightness, aspect) : null,
      anchor,
      confidence,
      phases: this.phases(t),
      jump: jumpA,
      palmProgress: this.shield.progress,
      pinchCloseness: this.hack.lastAnalysis?.closeness ?? 0,
      pinchClosed: this.hack.closed,
      liveSwipe,
      error: tracked.error,
      errorSeq: tracked.seq,
      ready: tracked.ready,
      tracking,
      lastEvent: this.lastEvent,
    };
    return { events, failures, prompts: this.prompts, snapshot };
  }

  private phases(t: number): Record<GestureKind, GesturePhase> {
    const p: Record<GestureKind, GesturePhase> = {
      MOVE_LEFT: this.moveLeft.phase,
      MOVE_RIGHT: this.moveRight.phase,
      JUMP: this.jump.phase,
      HACK: this.hack.phase,
      SHIELD: this.shield.phase,
    };
    for (const g of Object.keys(p) as GestureKind[]) if (t < (this.actionShownUntil[g] ?? 0)) p[g] = "ACTION_TRIGGERED";
    return p;
  }

  private swipeConfidence(a: SwipeAttempt): number {
    const d = clamp(Math.abs(a.dx) / (a.requiredDistance * 1.3));
    const s = clamp(a.avgSpeed / (SWIPE.minAvgSpeed * 2.2));
    return clamp(a.meanScore * (0.6 + 0.25 * d + 0.15 * s) * this.jitter.stability());
  }
}

