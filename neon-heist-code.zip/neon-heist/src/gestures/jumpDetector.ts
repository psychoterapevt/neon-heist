import type { GesturePhase } from "../types/gesture";
import { POSE, type Landmarks, type Point } from "../types/vision";
import { clamp } from "../utils/math";
import { JUMP } from "./gestureConfig";

export type JumpPose =
  /** Both wrists clearly above the head → jump. */
  | "BOTH_UP"
  /** One wrist above the head, the other below the shoulders. */
  | "ONE_UP"
  /** Both wrists raised above the shoulders but not above the head. */
  | "TOO_LOW"
  /** Hands down (resting). */
  | "DOWN"
  /** Shoulders visible but a raised wrist can't be seen (out of frame / occluded). */
  | "HANDS_NOT_VISIBLE"
  /** No usable body landmarks. */
  | "NO_BODY";

export interface JumpAnalysis {
  pose: JumpPose;
  /** Y the wrists must be above (normalized, smaller = higher). */
  requiredY: number;
  /** Y above which a wrist counts as "raised". */
  raisedY: number;
  /** Visible wrists in screen order (left, right) — null when not visible. */
  wrists: [Point | null, Point | null];
  /** Wrists that are raised but still too low (for the ↑↑ visual). */
  lowWrists: Point[];
  /** 0..1 how close the lower wrist is to the required height. */
  progress: number;
}

const vis = (p: Point | undefined, min: number) => !!p && (p.visibility ?? 1) >= min;

/**
 * detectJump — pure analysis of one pose frame.
 * RULE: both wrists must be above (eye line − JUMP.aboveEyes × shoulder width).
 * All distances are relative to the shoulder width, so it works near or far.
 */
export function detectJump(pose: Landmarks | null): JumpAnalysis {
  const empty: JumpAnalysis = { pose: "NO_BODY", requiredY: 0, raisedY: 0, wrists: [null, null], lowWrists: [], progress: 0 };
  if (!pose) return empty;
  const ls = pose[POSE.LEFT_SHOULDER];
  const rs = pose[POSE.RIGHT_SHOULDER];
  if (!vis(ls, JUMP.minShoulderVisibility) || !vis(rs, JUMP.minShoulderVisibility)) return empty;

  const shoulderY = (ls.y + rs.y) / 2;
  const sw = Math.max(0.05, Math.abs(ls.x - rs.x)); // x-width is enough for a relative scale
  const le = pose[POSE.LEFT_EYE];
  const re = pose[POSE.RIGHT_EYE];
  const nose = pose[POSE.NOSE];
  const eyeY = vis(le, 0.4) || vis(re, 0.4) ? Math.min(le?.y ?? 1, re?.y ?? 1) : (nose?.y ?? shoulderY - sw * 0.6);
  const requiredY = eyeY - JUMP.aboveEyes * sw;
  const raisedY = shoulderY - JUMP.raisedAboveShoulders * sw;

  // Order wrists by screen x (mirrored coordinates) so left/right match what the player sees.
  const raw = [pose[POSE.LEFT_WRIST], pose[POSE.RIGHT_WRIST]]
    .map((w) => (vis(w, JUMP.minWristVisibility) ? { x: w.x, y: w.y } : null));
  const wrists: [Point | null, Point | null] =
    raw[0] && raw[1] ? (raw[0].x <= raw[1].x ? [raw[0], raw[1]] : [raw[1], raw[0]]) : [raw[0], raw[1]];

  const up = wrists.map((w) => !!w && w.y < requiredY);
  const raised = wrists.map((w) => !!w && w.y < raisedY);
  const visibleCount = wrists.filter(Boolean).length;
  const lowWrists = wrists.filter((w): w is Point => !!w && w.y < raisedY && w.y >= requiredY);

  // progress: how high the LOWER wrist is between shoulders (0) and the jump line (1)
  const lowest = Math.max(...wrists.map((w) => (w ? w.y : shoulderY)));
  const progress = clamp((shoulderY - lowest) / Math.max(1e-6, shoulderY - requiredY));

  // Elbows above the shoulder line while a wrist is invisible ⇒ that hand is up but out of frame.
  const elbowUp = [pose[POSE.LEFT_ELBOW], pose[POSE.RIGHT_ELBOW]].some((e) => vis(e, 0.5) && e.y < shoulderY);

  let jp: JumpPose;
  if (up[0] && up[1]) jp = "BOTH_UP";
  else if (visibleCount < 2 && (raised.some(Boolean) || elbowUp)) jp = "HANDS_NOT_VISIBLE";
  else if (raised[0] && raised[1]) jp = "TOO_LOW";
  else if (up[0] || up[1] || raised[0] || raised[1]) jp = "ONE_UP";
  else jp = "DOWN";

  return { pose: jp, requiredY, raisedY, wrists, lowWrists, progress };
}

export type JumpUpdate =
  | { kind: "none" }
  | { kind: "confirmed"; confidence: number }
  | { kind: "near-miss"; analysis: JumpAnalysis };

/**
 * JUMP state machine (runs on pose frames):
 * IDLE → POSSIBLE (a hand is raised) → TRACKING (both above the head)
 *      → GESTURE_CONFIRMED after JUMP.holdMs → ACTION_TRIGGERED
 *      → COOLDOWN until BOTH hands come down → IDLE.
 * One raise = one jump, however long the hands stay up.
 */
export class JumpDetector {
  phase: GesturePhase = "IDLE";
  private upSince: number | null = null;
  private nearMissSince: number | null = null;
  private nearMissPose: JumpPose | null = null;
  private reported = false;

  reset(): void {
    this.phase = "IDLE";
    this.upSince = null;
    this.nearMissSince = null;
    this.nearMissPose = null;
    this.reported = false;
  }

  /** @param a null when pose was not evaluated on this frame (keeps state). */
  update(a: JumpAnalysis | null, t: number, visibility = 1): JumpUpdate {
    if (!a) return { kind: "none" };

    if (this.phase === "COOLDOWN") {
      if (a.pose === "DOWN" || a.pose === "NO_BODY") {
        this.phase = "IDLE";
        this.reported = false;
      }
      return { kind: "none" };
    }

    if (a.pose === "BOTH_UP") {
      this.nearMissSince = null;
      this.upSince ??= t;
      this.phase = "TRACKING";
      if (t - this.upSince >= JUMP.holdMs) {
        this.phase = "COOLDOWN";
        this.upSince = null;
        return { kind: "confirmed", confidence: clamp(visibility) };
      }
      return { kind: "none" };
    }
    this.upSince = null;

    if (a.pose === "ONE_UP" || a.pose === "TOO_LOW" || a.pose === "HANDS_NOT_VISIBLE") {
      this.phase = "POSSIBLE";
      if (this.nearMissPose !== a.pose) {
        this.nearMissPose = a.pose;
        this.nearMissSince = t;
        this.reported = false;
      }
      if (!this.reported && this.nearMissSince !== null && t - this.nearMissSince >= JUMP.nearMissMs) {
        this.reported = true;
        return { kind: "near-miss", analysis: a };
      }
      return { kind: "none" };
    }

    // DOWN / NO_BODY
    this.phase = "IDLE";
    this.nearMissSince = null;
    this.nearMissPose = null;
    this.reported = false;
    return { kind: "none" };
  }
}
