import type { GesturePhase } from "../types/gesture";
import type { Landmarks } from "../types/vision";
import {
  countExtendedFingers,
  fingerSpreadAngle,
  isThumbExtended,
  palmFacingScore,
} from "../vision/handMetrics";
import { clamp, normalize } from "../utils/math";
import { PALM } from "./gestureConfig";

export interface OpenPalmAnalysis {
  isOpen: boolean;
  /** 0..1 shape quality (how clearly this is an open palm). */
  score: number;
  extendedFingers: number;
  thumbExtended: boolean;
  spreadAngle: number;
  facing: number;
  /** What is missing for an open palm (empty when isOpen). */
  missing: Array<"FINGERS_CURLED" | "FINGERS_NOT_SPREAD" | "PALM_NOT_FACING">;
}

/**
 * Open palm = 4 fingers extended (straight + reaching away from the wrist),
 * thumb away from the index MCP, fingers spread (index↔pinky angle) and
 * the palm plane facing the camera. All measures are relative (angles, ratios).
 */
export function detectOpenPalm(lm: Landmarks, aspect = 1): OpenPalmAnalysis {
  const extendedFingers = countExtendedFingers(lm, aspect);
  const thumbExtended = isThumbExtended(lm, aspect);
  const spreadAngle = fingerSpreadAngle(lm, aspect);
  const facing = palmFacingScore(lm, aspect);

  const missing: OpenPalmAnalysis["missing"] = [];
  if (extendedFingers < PALM.minExtendedFingers || !thumbExtended) missing.push("FINGERS_CURLED");
  if (spreadAngle < PALM.minSpreadAngle) missing.push("FINGERS_NOT_SPREAD");
  if (facing < PALM.minFacing) missing.push("PALM_NOT_FACING");

  const score =
    (extendedFingers / 4) * 0.4 +
    (thumbExtended ? 0.15 : 0) +
    normalize(spreadAngle, 8, PALM.minSpreadAngle + 12) * 0.25 +
    normalize(facing, 0.1, PALM.minFacing + 0.2) * 0.2;

  return {
    isOpen: missing.length === 0,
    score: clamp(score),
    extendedFingers,
    thumbExtended,
    spreadAngle,
    facing,
    missing,
  };
}

export type PalmUpdate =
  | { kind: "none" }
  | { kind: "confirmed"; confidence: number }
  /** User is clearly trying (hand still, mostly open) but something is off. */
  | { kind: "near-miss"; analysis: OpenPalmAnalysis };

/**
 * Open-palm state machine:
 * IDLE → POSSIBLE (palm open) → TRACKING (held still, progress 0..1)
 *      → GESTURE_CONFIRMED → ACTION_TRIGGERED → COOLDOWN (until the hand closes/leaves) → IDLE
 * The hold + stillness requirement separates "show palm" from a swipe
 * (which also uses an open hand but moves fast).
 */
export class OpenPalmDetector {
  phase: GesturePhase = "IDLE";
  /** 0..1 hold progress for the UI ring. */
  progress = 0;
  private openSince: number | null = null;
  private notOpenSince: number | null = null;
  private nearMissSince: number | null = null;
  private nearMissReported = false;
  private scores: number[] = [];

  reset(): void {
    this.phase = "IDLE";
    this.progress = 0;
    this.openSince = null;
    this.notOpenSince = null;
    this.nearMissSince = null;
    this.nearMissReported = false;
    this.scores = [];
  }

  markTriggered(): void {
    this.phase = "COOLDOWN";
    this.progress = 0;
    this.openSince = null;
    this.notOpenSince = null;
  }

  /**
   * @param analysis open-palm analysis of the current frame, null if no hand.
   * @param speed palm speed (frame-widths/s).
   * @param eligible false when the hand is in a position where the palm gesture
   *        should not count (e.g. raised above the head for HAND_UP).
   */
  update(analysis: OpenPalmAnalysis | null, speed: number, t: number, eligible = true, presence = 1): PalmUpdate {
    const open = !!analysis && analysis.isOpen && eligible;

    if (this.phase === "COOLDOWN") {
      // Re-arm only after the hand has been NOT open for a moment (or left).
      if (!open) {
        this.notOpenSince ??= t;
        if (t - this.notOpenSince >= PALM.rearmMs) this.phase = "IDLE";
      } else {
        this.notOpenSince = null;
      }
      return { kind: "none" };
    }

    if (!open || speed > PALM.maxHoldSpeed) {
      this.openSince = null;
      this.progress = 0;
      this.scores = [];
      this.phase = "IDLE";
      return this.checkNearMiss(analysis, speed, t, eligible);
    }

    this.nearMissSince = null;
    this.nearMissReported = false;
    this.openSince ??= t;
    this.scores.push(analysis.score * presence);
    const held = t - this.openSince;
    this.progress = clamp(held / PALM.holdMs);
    this.phase = held < 80 ? "POSSIBLE" : "TRACKING";
    if (held >= PALM.holdMs) {
      // Confirmed → action fires once; COOLDOWN until the hand closes or leaves.
      this.markTriggered();
      const confidence = this.scores.reduce((a, b) => a + b, 0) / this.scores.length;
      this.scores = [];
      return { kind: "confirmed", confidence };
    }
    return { kind: "none" };
  }

  private checkNearMiss(analysis: OpenPalmAnalysis | null, speed: number, t: number, eligible: boolean): PalmUpdate {
    // A near miss: hand still, at least 3 fingers extended, but not a valid open palm.
    const trying =
      !!analysis && eligible && speed < PALM.maxHoldSpeed && analysis.extendedFingers >= 3 && !analysis.isOpen;
    if (!trying) {
      this.nearMissSince = null;
      this.nearMissReported = false;
      return { kind: "none" };
    }
    this.nearMissSince ??= t;
    if (!this.nearMissReported && t - this.nearMissSince >= PALM.nearMissMs) {
      this.nearMissReported = true;
      return { kind: "near-miss", analysis };
    }
    return { kind: "none" };
  }
}
