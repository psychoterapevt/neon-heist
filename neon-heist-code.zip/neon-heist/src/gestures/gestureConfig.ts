/**
 * gestureConfig — EVERY recognition threshold in one place (tunable).
 * Units:
 *  - positions: normalized frame coordinates (0..1), mirrored (selfie view)
 *  - speeds: frame-widths per second
 *  - hand-shape ratios: relative to hand size (wrist → middle-finger MCP)
 *  - body ratios: relative to shoulder width
 *  - times: milliseconds
 */

/** MOVE LEFT / MOVE RIGHT — horizontal hand swipe. */
export const SWIPE = {
  /** Minimum horizontal travel to count as a move (fraction of frame width). */
  minDistance: 0.15,
  /** Smaller motions are fidgeting — ignored silently. */
  minAttemptDistance: 0.07,
  /** Slower than this is repositioning, not an attempt — ignored silently. */
  driftSpeed: 0.16,
  /** Horizontal speed that starts tracking a possible swipe. */
  startSpeed: 0.15,
  /** Frames above startSpeed needed for POSSIBLE → TRACKING. */
  startFrames: 2,
  /** Speed below which the stroke is considered finished. */
  stopSpeed: 0.1,
  stopHoldMs: 90,
  /** Travel back from the peak that ends the stroke. */
  reversalDistance: 0.035,
  /** A valid move must be completed within this time … */
  maxDurationMs: 850,
  /** … with at least this average speed. */
  minAvgSpeed: 0.35,
  abortAfterMs: 2200,
  /** Max |dy| / |dx| for a horizontal move. */
  maxVerticalRatio: 0.85,
  /** Hand closer than this to the left/right frame edge = leaving the frame. */
  edgeMargin: 0.035,
  /** Minimum mean hand-presence score during the stroke (low-confidence guard). */
  minScore: 0.55,
  /** Per-detector cooldown after a move. */
  cooldownMs: 450,
  /** Opposite-direction stroke right after a move = hand returning — ignored. */
  returnStrokeMs: 900,
  /** Opposite stroke starting where a FAILED stroke ended = repositioning — ignored. */
  repositionWindowMs: 3000,
  repositionRadius: 0.09,
} as const;

/** JUMP — both hands above the head (pose landmarks). */
export const JUMP = {
  /** Wrist must be above: eye line − this × shoulder width ("above the head"). */
  aboveEyes: 0.1,
  /** A wrist above the shoulder line counts as "raised" (an attempt is in progress). */
  raisedAboveShoulders: 0.05,
  /** Both hands must stay up this long (≈ 2 pose frames) — never a single frame. */
  holdMs: 110,
  /** Near-miss (one hand / too low) must persist this long before we explain it. */
  nearMissMs: 450,
  /** Minimum pose visibility for a wrist to count. */
  minWristVisibility: 0.35,
  /** Minimum pose visibility for shoulders. */
  minShoulderVisibility: 0.5,
} as const;

/** SHIELD — open palm toward the camera. */
export const PALM = {
  minExtendedFingers: 4,
  /** index ↔ pinky spread angle (degrees). */
  minSpreadAngle: 14,
  /** Palm-plane facing score (see palmFacingScore). */
  minFacing: 0.24,
  /** Hold the open palm this long (fast for gameplay, still > 1 frame). */
  holdMs: 250,
  /** Max palm speed while holding (a swipe is faster). */
  maxHoldSpeed: 0.45,
  /** Hand must be "not open" this long before the shield can fire again. */
  rearmMs: 250,
  /** Near-miss duration before an explanation. */
  nearMissMs: 600,
} as const;

/** HACK — pinch (thumb tip ↔ index tip). */
export const PINCH = {
  /** distance(indexTip, thumbTip) / handSize below which the pinch is closed. */
  closeRatio: 0.3,
  /** Hysteresis: released above this. */
  releaseRatio: 0.45,
  /** "Trying to pinch" band. */
  approachRatio: 0.55,
  /** Pinch must stay closed this long (debounce). */
  holdMs: 120,
  nearMissMs: 800,
  flickerWindowMs: 1600,
  minFacing: 0.16,
  /** Below this hand-presence score a pinch never fires. */
  minScore: 0.6,
} as const;

export const HAND_CFG = {
  /** Hand size relative to the shorter frame side below which the hand is too far. */
  minSize: 0.045,
  conditionDelayMs: 450,
  /** No body for this long → TRACKING LOST (game pauses). */
  trackingLostMs: 900,
  /** Minimum hand-presence score for any hand gesture. */
  minPresence: 0.55,
} as const;

/** Global minimum time between any two gesture actions of the same kind. */
export const ACTION_COOLDOWN_MS = 350;
