import type { SoundName } from "../game/GameEngine";

/**
 * Procedural sound effects + ambience with the Web Audio API.
 * No audio files, nothing copyrighted.
 */
const MUTE_KEY = "neonheist.muted";

class SoundManager {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private ambience: { stop: () => void } | null = null;
  private last: Partial<Record<SoundName, number>> = {};
  muted = false;

  constructor() {
    try {
      this.muted = localStorage.getItem(MUTE_KEY) === "1";
    } catch {
      this.muted = false;
    }
  }

  /** Call from a click once (autoplay policy). */
  unlock(): void {
    try {
      if (!this.ctx) {
        const C = window.AudioContext ?? (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
        if (!C) return;
        this.ctx = new C();
        this.master = this.ctx.createGain();
        this.master.gain.value = this.muted ? 0 : 0.9;
        this.master.connect(this.ctx.destination);
      }
      if (this.ctx.state === "suspended") void this.ctx.resume();
    } catch {
      this.ctx = null;
    }
  }

  setMuted(m: boolean): void {
    this.muted = m;
    if (this.master && this.ctx) this.master.gain.setTargetAtTime(m ? 0 : 0.9, this.ctx.currentTime, 0.05);
    try {
      localStorage.setItem(MUTE_KEY, m ? "1" : "0");
    } catch {
      /* ignore */
    }
  }

  private ok(): boolean {
    return !!this.ctx && !!this.master && this.ctx.state === "running";
  }

  private tone(freq: number, at: number, dur: number, type: OscillatorType, gain: number, to?: number) {
    const ctx = this.ctx!;
    const o = ctx.createOscillator();
    const g = ctx.createGain();
    o.type = type;
    o.frequency.setValueAtTime(freq, at);
    if (to) o.frequency.exponentialRampToValueAtTime(to, at + dur);
    g.gain.setValueAtTime(0.0001, at);
    g.gain.exponentialRampToValueAtTime(gain, at + 0.01);
    g.gain.exponentialRampToValueAtTime(0.0001, at + dur);
    o.connect(g).connect(this.master!);
    o.start(at);
    o.stop(at + dur + 0.03);
  }

  private noise(at: number, dur: number, gain: number, freq = 1200) {
    const ctx = this.ctx!;
    const len = Math.floor(ctx.sampleRate * dur);
    const buf = ctx.createBuffer(1, len, ctx.sampleRate);
    const d = buf.getChannelData(0);
    for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * (1 - i / len);
    const src = ctx.createBufferSource();
    src.buffer = buf;
    const f = ctx.createBiquadFilter();
    f.type = "bandpass";
    f.frequency.value = freq;
    const g = ctx.createGain();
    g.gain.value = gain;
    src.connect(f).connect(g).connect(this.master!);
    src.start(at);
  }

  play(name: SoundName): void {
    if (!this.ok()) return;
    const now = performance.now();
    if (now - (this.last[name] ?? -Infinity) < (name === "error" ? 900 : 70)) return;
    this.last[name] = now;
    const t = this.ctx!.currentTime;
    switch (name) {
      case "move":
        this.tone(520, t, 0.06, "sine", 0.08, 700);
        break;
      case "jump":
        this.tone(300, t, 0.22, "square", 0.06, 900);
        break;
      case "hack":
        [880, 1320, 990, 1480, 1175].forEach((f, i) => this.tone(f, t + i * 0.07, 0.06, "square", 0.05));
        break;
      case "shield":
        this.tone(180, t, 0.5, "sawtooth", 0.05, 720);
        this.tone(360, t + 0.05, 0.45, "sine", 0.08, 1100);
        break;
      case "blocked":
        this.noise(t, 0.18, 0.35, 2600);
        this.tone(1200, t, 0.18, "triangle", 0.1, 600);
        break;
      case "laserHit":
        this.noise(t, 0.3, 0.6, 800);
        this.tone(160, t, 0.35, "sawtooth", 0.12, 60);
        break;
      case "error":
        this.tone(260, t, 0.18, "triangle", 0.1, 190);
        break;
      case "success":
        this.tone(660, t, 0.08, "sine", 0.14);
        this.tone(990, t + 0.07, 0.14, "sine", 0.12);
        break;
      case "levelComplete":
        [523, 659, 784, 1047, 1319].forEach((f, i) => this.tone(f, t + i * 0.1, 0.3, "triangle", 0.1));
        break;
      case "gameOver":
        [392, 311, 262, 196].forEach((f, i) => this.tone(f, t + i * 0.18, 0.35, "sawtooth", 0.07));
        break;
    }
  }

  /** Very quiet procedural "server room" drone with a slow filter sweep. */
  startAmbience(): void {
    if (!this.ok() || this.ambience) return;
    const ctx = this.ctx!;
    const g = ctx.createGain();
    g.gain.value = 0.035;
    const f = ctx.createBiquadFilter();
    f.type = "lowpass";
    f.frequency.value = 420;
    const lfo = ctx.createOscillator();
    const lfoGain = ctx.createGain();
    lfo.frequency.value = 0.07;
    lfoGain.gain.value = 180;
    lfo.connect(lfoGain).connect(f.frequency);
    const oscs = [55, 82.4, 110.3].map((fr) => {
      const o = ctx.createOscillator();
      o.type = "sawtooth";
      o.frequency.value = fr;
      o.connect(f);
      o.start();
      return o;
    });
    f.connect(g).connect(this.master!);
    lfo.start();
    this.ambience = {
      stop: () => {
        g.gain.setTargetAtTime(0, ctx.currentTime, 0.2);
        window.setTimeout(() => {
          oscs.forEach((o) => o.stop());
          lfo.stop();
        }, 800);
      },
    };
  }

  stopAmbience(): void {
    this.ambience?.stop();
    this.ambience = null;
  }
}

export const soundManager = new SoundManager();
