import type { LevelDef } from "./types";

/** LEVEL 2 — SECURITY: lasers, moving crates and attacking drones (shield). */
export const level2: LevelDef = {
  id: 2,
  name: "SECURITY",
  objective: "Survive the security sweep",
  speed: 4.4,
  events: [
    { at: 14, type: "drone" },
    { at: 42, type: "laserWall", lanes: [0, 2] },
    { at: 62, type: "block", from: 0, to: 1 },
    { at: 84, type: "laserLow" },
    { at: 100, type: "drone" },
    { at: 128, type: "laserWall", lanes: [1, 2] },
    { at: 148, type: "block", from: 2, to: 0 },
    { at: 168, type: "laserLow" },
    { at: 184, type: "drone" },
    { at: 212, type: "door" },
  ],
};
