import type { LevelDef } from "./types";

/** LEVEL 3 — CORE: everything together, 3 terminals, then steal the Data Core. */
export const level3: LevelDef = {
  id: 3,
  name: "CORE",
  objective: "Hack 3 terminals and steal the Data Core",
  speed: 4.5,
  events: [
    { at: 18, type: "laserLow" },
    { at: 34, type: "terminal" },
    { at: 54, type: "laserWall", lanes: [0, 1] },
    { at: 70, type: "drone" },
    { at: 98, type: "block", from: 2, to: 1 },
    { at: 116, type: "terminal" },
    { at: 134, type: "laserLow" },
    { at: 150, type: "drone" },
    { at: 178, type: "laserWall", lanes: [1, 2] },
    { at: 196, type: "terminal" },
    { at: 214, type: "laserLow" },
    { at: 234, type: "core" },
  ],
};
