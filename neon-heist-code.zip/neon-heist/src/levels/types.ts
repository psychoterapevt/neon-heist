/** Declarative level format: events placed along the track (metres from the start). */
export type LevelEvent =
  | { at: number; type: "laserLow" }
  | { at: number; type: "laserWall"; lanes: number[] }
  | { at: number; type: "block"; from: number; to: number }
  | { at: number; type: "drone" }
  | { at: number; type: "terminal" }
  | { at: number; type: "door" }
  | { at: number; type: "core" };

export interface LevelDef {
  id: number;
  name: string;
  objective: string;
  /** Base forward speed (m/s) before adaptive difficulty. */
  speed: number;
  events: LevelEvent[];
}
