import type { LevelDef } from "./types";

/** LEVEL 1 — INFILTRATION: move, jump, reach the security door and hack it. */
export const level1: LevelDef = {
  id: 1,
  name: "INFILTRATION",
  objective: "Reach the security door",
  speed: 4.2,
  events: [
    { at: 24, type: "laserWall", lanes: [1] },
    { at: 46, type: "laserLow" },
    { at: 70, type: "laserWall", lanes: [0, 1] },
    { at: 92, type: "laserLow" },
    { at: 116, type: "laserWall", lanes: [1, 2] },
    { at: 138, type: "laserLow" },
    { at: 158, type: "door" },
  ],
};
