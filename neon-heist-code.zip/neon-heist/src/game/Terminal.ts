export type TerminalVariant = "terminal" | "door" | "core";
export type TerminalState = "locked" | "waiting" | "hacking" | "done";

/**
 * A hackable object. The run stops in front of it until the player PINCHes;
 * then a hack animation plays for PLAYER.hackMs.
 * - terminal: side console (level 3 has three)
 * - door: security door at the end of a level
 * - core: the Data Core (final objective)
 */
export class Terminal {
  readonly kind = "terminal" as const;
  state: TerminalState = "locked";
  hackStart = 0;
  doneAt = 0;
  passed = false;
  constructor(
    readonly id: number,
    readonly at: number,
    readonly variant: TerminalVariant,
  ) {}

  /** Distance ahead at which the run stops. */
  get stopZ(): number {
    return this.variant === "terminal" ? 3.4 : 4.2;
  }

  get label(): string {
    return this.variant === "door" ? "SECURITY DOOR" : this.variant === "core" ? "DATA CORE" : "TERMINAL";
  }

  progress(clock: number, hackMs: number): number {
    if (this.state === "done") return 1;
    if (this.state !== "hacking") return 0;
    return Math.min(1, (clock - this.hackStart) / hackMs);
  }
}
