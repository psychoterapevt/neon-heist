import { laneX, type LaneIndex } from "./types";

export const PLAYER = {
  /** Jump: initial vertical speed (m/s) and gravity — a floaty 1.4 s hop for gesture latency. */
  jumpVelocity: 6.3,
  gravity: 9,
  /** Small crouch before take-off (anticipation). */
  anticipationMs: 90,
  /** Lane change duration. */
  laneChangeMs: 220,
  /** Longer than a drone's charge, so raising the shield any time during the charge works. */
  shieldMs: 2800,
  shieldRechargeMs: 2200,
  hackMs: 1200,
  invulnerableMs: 1300,
} as const;

/** The little hacker. Pure state + physics; drawn by renderer.ts. */
export class Player {
  lane: LaneIndex = 1;
  /** Current (animated) lateral position in metres. */
  x = 0;
  /** Height above the floor in metres. */
  height = 0;
  vy = 0;
  jumpQueuedAt: number | null = null;
  shieldUntil = 0;
  shieldReadyAt = 0;
  hackUntil = 0;
  hitAt = -Infinity;
  invulnerableUntil = 0;
  runPhase = 0;
  lastJumpAt = -Infinity;

  reset(): void {
    this.lane = 1;
    this.x = 0;
    this.height = 0;
    this.vy = 0;
    this.jumpQueuedAt = null;
    this.shieldUntil = 0;
    this.shieldReadyAt = 0;
    this.hackUntil = 0;
    this.hitAt = -Infinity;
    this.invulnerableUntil = 0;
  }

  get airborne(): boolean {
    return this.height > 0.001 || this.vy > 0 || this.jumpQueuedAt !== null;
  }

  moveLeft(): boolean {
    if (this.lane === 0) return false;
    this.lane = (this.lane - 1) as LaneIndex;
    return true;
  }

  moveRight(): boolean {
    if (this.lane === 2) return false;
    this.lane = (this.lane + 1) as LaneIndex;
    return true;
  }

  jump(now: number): boolean {
    if (this.airborne) return false;
    this.jumpQueuedAt = now;
    this.lastJumpAt = now;
    return true;
  }

  shieldActive(now: number): boolean {
    return now < this.shieldUntil;
  }

  activateShield(now: number): "on" | "active" | "recharging" {
    if (this.shieldActive(now)) return "active";
    if (now < this.shieldReadyAt) return "recharging";
    this.shieldUntil = now + PLAYER.shieldMs;
    this.shieldReadyAt = this.shieldUntil + PLAYER.shieldRechargeMs;
    return "on";
  }

  hacking(now: number): boolean {
    return now < this.hackUntil;
  }

  hit(now: number): boolean {
    if (now < this.invulnerableUntil) return false;
    this.hitAt = now;
    this.invulnerableUntil = now + PLAYER.invulnerableMs;
    return true;
  }

  update(dt: number, now: number, running: boolean): void {
    // lateral: critically-damped approach to the lane centre
    const target = laneX(this.lane);
    const k = 1 - Math.exp(-dt / (PLAYER.laneChangeMs / 1000 / 3));
    this.x += (target - this.x) * k;

    if (this.jumpQueuedAt !== null && now - this.jumpQueuedAt >= PLAYER.anticipationMs) {
      this.jumpQueuedAt = null;
      this.vy = PLAYER.jumpVelocity;
    }
    if (this.height > 0 || this.vy > 0) {
      this.vy -= PLAYER.gravity * dt;
      this.height += this.vy * dt;
      if (this.height <= 0) {
        this.height = 0;
        this.vy = 0;
      }
    }
    if (running) this.runPhase += dt * 9;
  }
}
