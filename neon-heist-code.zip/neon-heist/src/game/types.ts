import type { ExpectedAction, GestureKind } from "../types/gesture";

export type LaneIndex = 0 | 1 | 2;
export const LANE_WIDTH = 1.6; // metres
export const laneX = (lane: number) => (lane - 1) * LANE_WIDTH;

export type GameState = "intro" | "running" | "levelComplete" | "gameOver" | "victory";

export interface Popup {
  text: string;
  color: string;
  /** world x (m) and height (m) near the player */
  x: number;
  h: number;
  born: number;
  big?: boolean;
}

export interface Particle {
  x: number; // screen-space fractions are resolved by the renderer; these are world units
  y: number; // height (m)
  z: number; // metres ahead of the player
  vx: number;
  vy: number;
  vz: number;
  life: number;
  maxLife: number;
  color: string;
  size: number;
  glyph?: string;
}

export interface Hint {
  expected: ExpectedAction;
  /** e.g. "LASER AHEAD" */
  label: string;
  /** e.g. "JUMP ↑" */
  action: string;
  urgent: boolean;
  /** For MOVE: which way to go. */
  direction?: "left" | "right";
}

/** Result of mapping a gesture onto the game (for feedback + stats). */
export interface ActionResult {
  gesture: GestureKind;
  applied: boolean;
  /** Feedback label e.g. "✓ JUMP", or a reason e.g. "SHIELD RECHARGING". */
  label: string;
}

export interface RunStats {
  gestures: number;
  failedAttempts: number;
  errorsCorrected: number;
  damageTaken: number;
  obstaclesCleared: number;
  hacks: number;
  perfectJumps: number;
  gestureCounts: Partial<Record<GestureKind, number>>;
}

export const emptyRunStats = (): RunStats => ({
  gestures: 0,
  failedAttempts: 0,
  errorsCorrected: 0,
  damageTaken: 0,
  obstaclesCleared: 0,
  hacks: 0,
  perfectJumps: 0,
  gestureCounts: {},
});
