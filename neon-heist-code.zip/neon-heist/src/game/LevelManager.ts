import { LEVELS, type LevelDef } from "../levels";
import { Block, Drone } from "./Enemy";
import { LaserLow, LaserWall } from "./Laser";
import { Terminal } from "./Terminal";

export type Entity = LaserLow | LaserWall | Block | Drone | Terminal;

/** Builds the entities of a level from its declarative definition. */
export function buildLevel(def: LevelDef): Entity[] {
  let id = 0;
  return def.events.map((e): Entity => {
    id++;
    switch (e.type) {
      case "laserLow":
        return new LaserLow(id, e.at);
      case "laserWall":
        return new LaserWall(id, e.at, e.lanes);
      case "block":
        return new Block(id, e.at, e.from, e.to);
      case "drone":
        return new Drone(id, e.at);
      case "terminal":
        return new Terminal(id, e.at, "terminal");
      case "door":
        return new Terminal(id, e.at, "door");
      case "core":
        return new Terminal(id, e.at, "core");
    }
  });
}

export class LevelManager {
  index = 0;
  get def(): LevelDef {
    return LEVELS[this.index];
  }
  get count(): number {
    return LEVELS.length;
  }
  get isLast(): boolean {
    return this.index >= LEVELS.length - 1;
  }
  /** Track length = the final objective's position. */
  get length(): number {
    return Math.max(...this.def.events.map((e) => e.at));
  }
}
