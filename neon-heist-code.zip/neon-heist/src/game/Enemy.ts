import { laneX } from "./types";

/**
 * Moving security crate: slides from one lane to another while approaching,
 * and settles in its final lane (telegraphed on the floor) before it arrives.
 */
export class Block {
  readonly kind = "block" as const;
  static readonly HEIGHT = 1.1;
  /** Starts sliding at this distance and settles at SETTLE_Z. */
  static readonly SLIDE_START_Z = 26;
  static readonly SETTLE_Z = 10;
  passed = false;
  hit = false;
  constructor(
    readonly id: number,
    readonly at: number,
    readonly from: number,
    readonly to: number,
  ) {}

  /** Lane position (fractional) when the crate is `z` metres ahead. */
  laneAt(z: number): number {
    if (z >= Block.SLIDE_START_Z) return this.from;
    if (z <= Block.SETTLE_Z) return this.to;
    const k = (Block.SLIDE_START_Z - z) / (Block.SLIDE_START_Z - Block.SETTLE_Z);
    const s = k * k * (3 - 2 * k);
    return this.from + (this.to - this.from) * s;
  }

  xAt(z: number): number {
    return laneX(this.laneAt(z));
  }

  blocks(lane: number): boolean {
    return this.to === lane;
  }
}

export type DronePhase = "waiting" | "enter" | "charge" | "fire" | "leave" | "done";

/**
 * Security drone: flies in, charges a beam (telegraphed), fires.
 * Only an active SHIELD blocks the shot.
 */
export class Drone {
  readonly kind = "drone" as const;
  static readonly T = { enter: 900, charge: 2600, fire: 260, leave: 900 } as const;
  static readonly HOVER_Z = 7;
  static readonly HOVER_H = 2.6;
  phase: DronePhase = "waiting";
  phaseStart = 0;
  /** null until it fires. */
  blocked: boolean | null = null;
  x = 0;
  passed = false;
  constructor(
    readonly id: number,
    readonly at: number,
  ) {}

  /** Advance the attack; returns "fire" exactly once, at the moment of the shot. */
  update(clock: number, distance: number, playerX: number, dt: number): "fire" | null {
    const follow = 1 - Math.exp(-dt * 2.5);
    this.x += (playerX - this.x) * follow;
    const elapsed = clock - this.phaseStart;
    switch (this.phase) {
      case "waiting":
        if (distance >= this.at) this.go("enter", clock, playerX);
        return null;
      case "enter":
        if (elapsed >= Drone.T.enter) this.go("charge", clock);
        return null;
      case "charge":
        if (elapsed >= Drone.T.charge) {
          this.go("fire", clock);
          return "fire";
        }
        return null;
      case "fire":
        if (elapsed >= Drone.T.fire) this.go("leave", clock);
        return null;
      case "leave":
        if (elapsed >= Drone.T.leave) {
          this.go("done", clock);
          this.passed = true;
        }
        return null;
      case "done":
        return null;
    }
  }

  /** 0..1 progress of the current phase. */
  progress(clock: number): number {
    const d = this.phase === "enter" ? Drone.T.enter : this.phase === "charge" ? Drone.T.charge : this.phase === "fire" ? Drone.T.fire : Drone.T.leave;
    return Math.min(1, Math.max(0, (clock - this.phaseStart) / d));
  }

  remainingChargeMs(clock: number): number {
    return this.phase === "charge" ? Math.max(0, Drone.T.charge - (clock - this.phaseStart)) : 0;
  }

  private go(p: DronePhase, clock: number, x?: number) {
    this.phase = p;
    this.phaseStart = clock;
    if (x !== undefined) this.x = x;
  }
}
