import type { ExpectedAction, GestureError, GestureEvent, GestureKind } from "../types/gesture";
import { LEVELS, type LevelDef } from "../levels";
import { Block, Drone } from "./Enemy";
import { LaserLow, LaserWall } from "./Laser";
import { Terminal } from "./Terminal";
import { PLAYER, Player } from "./Player";
import { resolvePasses, type Obstacle } from "./CollisionSystem";
import { buildLevel, type Entity } from "./LevelManager";
import { emptyRunStats, type ActionResult, type GameState, type Hint, type Particle, type Popup, type RunStats } from "./types";

export type SoundName = "jump" | "hack" | "shield" | "laserHit" | "error" | "success" | "levelComplete" | "gameOver" | "blocked" | "move";

export const SCORE = {
  obstacle: 100,
  hack: 250,
  perfectJump: 50,
  error: -25,
  damage: -100,
  blocked: 100,
} as const;

const INTRO_MS = 2200;
const MAX_HP = 3;

/** Gesture labels for "✓ …" confirmations. */
export const GESTURE_LABEL: Record<GestureKind, string> = {
  MOVE_LEFT: "MOVE LEFT",
  MOVE_RIGHT: "MOVE RIGHT",
  JUMP: "JUMP",
  HACK: "HACK",
  SHIELD: "SHIELD",
};

export interface EngineOptions {
  sound?: (s: SoundName) => void;
  reducedMotion?: boolean;
}

/**
 * GameEngine — pure game simulation (no DOM): world, player, collisions,
 * score/combo/HP, adaptive difficulty, particles. Advanced by a fixed-rate
 * `update(dt)` from the rAF loop; rendered by renderer.ts.
 * Uses its own clock so pausing (tracking lost) freezes everything.
 */
export class GameEngine {
  levelIndex = 0;
  level: LevelDef = LEVELS[0];
  state: GameState = "intro";
  stateSince = 0;
  clock = 0;
  distance = 0;
  speed = 0;
  hp = MAX_HP;
  readonly maxHp = MAX_HP;
  score = 0;
  private levelStartScore = 0;
  streak = 0;
  combo = 1;
  paused = false;
  difficulty = 1;
  hintLeadS = 3.4;
  private recent: number[] = [];
  entities: Entity[] = [];
  readonly player = new Player();
  particles: Particle[] = [];
  popups: Popup[] = [];
  shakeUntil = 0;
  shakeMag = 0;
  flashUntil = 0;
  flashColor = "#ff3b5c";
  stats: RunStats = emptyRunStats();
  /** Active play time across all levels (ms). */
  activeMs = 0;
  hint: Hint | null = null;
  private lastPenaltyAt = -Infinity;
  private pendingErrors: Array<{ gesture?: GestureKind; t: number }> = [];
  private readonly sound: (s: SoundName) => void;
  readonly reducedMotion: boolean;

  constructor(opts: EngineOptions = {}) {
    this.sound = opts.sound ?? (() => {});
    this.reducedMotion = !!opts.reducedMotion;
    this.startLevel(0);
  }

  // ------------------------------------------------------------ lifecycle
  startLevel(index: number): void {
    this.levelIndex = index;
    this.level = LEVELS[index];
    this.entities = buildLevel(this.level);
    this.distance = 0;
    this.hp = MAX_HP;
    this.player.reset();
    this.particles = [];
    this.popups = [];
    this.streak = 0;
    this.combo = 1;
    this.levelStartScore = this.score;
    this.setState("intro");
  }

  /** TRY AGAIN: replay the current level from its starting score. */
  restartLevel(): void {
    this.score = this.levelStartScore;
    this.startLevel(this.levelIndex);
  }

  nextLevel(): void {
    if (this.levelIndex < LEVELS.length - 1) this.startLevel(this.levelIndex + 1);
  }

  /** Full restart (PLAY AGAIN). */
  resetRun(): void {
    this.score = 0;
    this.stats = emptyRunStats();
    this.activeMs = 0;
    this.difficulty = 1;
    this.recent = [];
    this.startLevel(0);
  }

  get trackLength(): number {
    return Math.max(...this.level.events.map((e) => e.at));
  }

  get progress(): number {
    return Math.min(1, this.distance / this.trackLength);
  }

  private setState(s: GameState) {
    this.state = s;
    this.stateSince = this.clock;
  }

  // ------------------------------------------------------------ queries
  z(e: { at: number }): number {
    return e.at - this.distance;
  }

  activeTerminal(): Terminal | null {
    for (const e of this.entities) if (e instanceof Terminal && (e.state === "waiting" || e.state === "hacking")) return e;
    return null;
  }

  chargingDrone(): Drone | null {
    for (const e of this.entities) if (e instanceof Drone && (e.phase === "charge" || e.phase === "enter")) return e;
    return null;
  }

  private nextObstacle(): Obstacle | null {
    let best: Obstacle | null = null;
    for (const e of this.entities) {
      if (e instanceof LaserLow || e instanceof LaserWall || e instanceof Block) {
        if (e.passed) continue;
        if (!best || e.at < best.at) best = e;
      }
    }
    return best;
  }

  /** What the game expects from the player right now (drives hints + context-aware errors). */
  get expected(): ExpectedAction {
    return this.hint?.expected ?? null;
  }

  private computeHint(): Hint | null {
    if (this.state !== "running") return null;
    const drone = this.chargingDrone();
    if (drone) {
      const urgent = drone.phase === "charge" && drone.remainingChargeMs(this.clock) < 1300;
      const shielded = this.player.shieldActive(this.clock);
      if (drone.phase === "enter") return { expected: null, label: "DRONE INCOMING", action: "GET READY TO SHIELD ✋", urgent: false };
      return { expected: shielded ? null : "SHIELD", label: "DRONE CHARGING", action: shielded ? "SHIELD UP ✓" : "SHIELD — OPEN PALM ✋", urgent: urgent && !shielded };
    }
    const term = this.activeTerminal();
    if (term) {
      return term.state === "hacking"
        ? { expected: null, label: term.label, action: "HACKING…", urgent: false }
        : { expected: "HACK", label: term.label, action: "HACK — PINCH 🤏", urgent: false };
    }
    const o = this.nextObstacle();
    if (!o || this.speed <= 0) return null;
    const tta = (o.at - this.distance) / this.speed;
    if (tta > this.hintLeadS) return null;
    if (o instanceof LaserLow) {
      return { expected: "JUMP", label: "LASER AHEAD", action: tta < 1.3 ? "JUMP NOW — BOTH HANDS UP ↑↑" : "GET READY TO JUMP ↑↑", urgent: tta < 1.3 };
    }
    const blocked = o instanceof LaserWall ? o.blocks(this.player.lane) : o.blocks(this.player.lane);
    const label = o instanceof LaserWall ? "LASER WALL" : "SECURITY CRATE";
    if (!blocked) return { expected: null, label, action: "SAFE LANE — HOLD ✓", urgent: false };
    const safe = o instanceof LaserWall ? o.safeLanes() : [0, 1, 2].filter((l) => l !== o.to);
    const lane = this.player.lane;
    const nearest = safe.reduce((a, b) => (Math.abs(b - lane) < Math.abs(a - lane) ? b : a));
    const direction = nearest < lane ? "left" : "right";
    return { expected: "MOVE", label, action: direction === "left" ? "MOVE LEFT ←" : "MOVE RIGHT →", urgent: tta < 1.5, direction };
  }

  // ------------------------------------------------------------ input
  /**
   * triggerGameAction — maps a recognised gesture onto the game.
   * Returns what happened, for the "✓ JUMP" feedback and statistics.
   */
  handleGesture(ev: GestureEvent): ActionResult {
    const g = ev.gesture;
    const now = this.clock;
    const playing = this.state === "running" && !this.paused;
    if (!playing) return { gesture: g, applied: false, label: GESTURE_LABEL[g] };

    let applied = false;
    let label = `✓ ${GESTURE_LABEL[g]}`;
    const p = this.player;
    switch (g) {
      case "MOVE_LEFT":
        applied = p.moveLeft();
        if (!applied) label = "WALL — CAN'T MOVE LEFT";
        else this.sound("move");
        break;
      case "MOVE_RIGHT":
        applied = p.moveRight();
        if (!applied) label = "WALL — CAN'T MOVE RIGHT";
        else this.sound("move");
        break;
      case "JUMP": {
        applied = p.jump(now);
        if (applied) {
          this.sound("jump");
          const o = this.nextObstacle();
          if (o instanceof LaserLow && this.speed > 0) {
            const tta = (o.at - this.distance) / this.speed;
            if (tta >= 0.35 && tta <= 1.0) o.perfect = true;
          }
        } else label = "ALREADY IN THE AIR";
        break;
      }
      case "SHIELD": {
        const r = p.activateShield(now);
        applied = r === "on";
        if (applied) this.sound("shield");
        else label = r === "active" ? "SHIELD ALREADY ACTIVE" : "SHIELD RECHARGING";
        break;
      }
      case "HACK": {
        const term = this.activeTerminal();
        if (term && term.state === "waiting") {
          term.state = "hacking";
          term.hackStart = now;
          p.hackUntil = now + PLAYER.hackMs;
          applied = true;
          this.sound("hack");
        } else label = term ? "HACK IN PROGRESS" : "NO TERMINAL IN RANGE";
        break;
      }
    }

    if (applied) {
      this.stats.gestures++;
      this.stats.gestureCounts[g] = (this.stats.gestureCounts[g] ?? 0) + 1;
      const idx = this.pendingErrors.findIndex((e) => e.gesture === g && ev.t - e.t < 8000);
      if (idx >= 0) {
        this.stats.errorsCorrected++;
        this.pendingErrors.splice(idx, 1);
      }
      this.bumpStreak();
    }
    return { gesture: g, applied, label };
  }

  /** A failed gesture attempt from the Error Engine (score penalty, combo reset). */
  handleFailure(err: GestureError, visionT: number): void {
    if (this.state !== "running" || this.paused) return;
    this.stats.failedAttempts++;
    this.pendingErrors.push({ gesture: err.gesture, t: visionT });
    if (this.pendingErrors.length > 10) this.pendingErrors.shift();
    this.breakStreak();
    this.outcome(0);
    if (this.clock - this.lastPenaltyAt > 1200) {
      this.lastPenaltyAt = this.clock;
      this.addScore(SCORE.error, "−25", "#fbbf24");
    }
  }

  private bumpStreak() {
    this.streak++;
    const combo = Math.min(4, 1 + Math.floor(this.streak / 4));
    if (combo > this.combo) this.popup(`COMBO x${combo}`, "#c084fc", true);
    this.combo = combo;
  }

  private breakStreak() {
    this.streak = 0;
    this.combo = 1;
  }

  private addScore(points: number, text: string, color: string) {
    const pts = points > 0 ? points * this.combo : points;
    this.score = Math.max(0, this.score + pts);
    this.popup(points > 0 && this.combo > 1 ? `+${pts}` : text, color);
  }

  private popup(text: string, color: string, big = false) {
    this.popups.push({ text, color, x: this.player.x, h: this.player.height + 1.6, born: this.clock, big });
    if (this.popups.length > 8) this.popups.shift();
  }

  /** Adaptive difficulty: recent success rate nudges speed and hint timing. */
  private outcome(success: 0 | 1) {
    this.recent.push(success);
    if (this.recent.length > 8) this.recent.shift();
    if (this.recent.length < 4) return;
    const rate = this.recent.reduce((a, b) => a + b, 0) / this.recent.length;
    const target = rate > 0.85 ? 1.12 : rate < 0.5 ? 0.86 : 1;
    this.difficulty += (target - this.difficulty) * 0.35;
    this.hintLeadS = this.difficulty < 0.95 ? 4.6 : 3.4;
  }

  private damage(reason: string) {
    const now = this.clock;
    if (!this.player.hit(now)) return;
    this.hp--;
    this.stats.damageTaken++;
    this.breakStreak();
    this.outcome(0);
    this.addScore(SCORE.damage, "−100", "#ff3b5c");
    this.popup(reason, "#ff3b5c");
    this.sound("laserHit");
    this.flashUntil = now + 220;
    this.flashColor = "#ff3b5c";
    if (!this.reducedMotion) {
      this.shakeUntil = now + 380;
      this.shakeMag = 14;
    }
    this.burst(this.player.x, 0.9, 0.2, "#ff3b5c", 18);
    if (this.hp <= 0) {
      this.setState("gameOver");
      this.sound("gameOver");
    }
  }

  // ------------------------------------------------------------ simulation
  update(dtMs: number): void {
    const dt = Math.min(0.05, dtMs / 1000);
    if (this.paused) return;
    this.clock += dt * 1000;
    const now = this.clock;

    if (this.state === "intro" && now - this.stateSince >= INTRO_MS) this.setState("running");
    const running = this.state === "running";

    // Terminals stop the run until hacked.
    let stopAt = Infinity;
    for (const e of this.entities) {
      if (!(e instanceof Terminal) || e.state === "done") continue;
      const stopDistance = e.at - e.stopZ;
      stopAt = Math.min(stopAt, stopDistance);
      if (running && e.state === "locked" && this.distance >= stopDistance - 1e-6) e.state = "waiting";
      if (e.state === "hacking" && now - e.hackStart >= PLAYER.hackMs) this.completeHack(e);
    }

    const prev = this.distance;
    this.speed = running ? this.level.speed * this.difficulty : 0;
    if (running) {
      this.distance = Math.min(stopAt, this.distance + this.speed * dt);
      this.activeMs += dt * 1000;
      if (this.distance >= stopAt) this.speed = 0;
    }

    // Obstacles passing the player
    if (running) {
      const obstacles = this.entities.filter((e): e is Obstacle => e instanceof LaserLow || e instanceof LaserWall || e instanceof Block);
      for (const { obstacle, hit } of resolvePasses(obstacles, prev, this.distance, this.player)) {
        if (hit) this.damage(obstacle instanceof LaserLow ? "LASER HIT" : obstacle instanceof Block ? "CRATE HIT" : "LASER WALL");
        else {
          this.stats.obstaclesCleared++;
          this.outcome(1);
          this.bumpStreak();
          this.addScore(SCORE.obstacle, "+100", "#5eead4");
          if (obstacle instanceof LaserLow && obstacle.perfect) {
            this.stats.perfectJumps++;
            this.addScore(SCORE.perfectJump, "PERFECT +50", "#a5b4fc");
          }
        }
      }
      // Drones
      for (const e of this.entities) {
        if (!(e instanceof Drone)) continue;
        if (e.update(now, this.distance, this.player.x, dt) === "fire") {
          if (this.player.shieldActive(now)) {
            e.blocked = true;
            this.stats.obstaclesCleared++;
            this.outcome(1);
            this.bumpStreak();
            this.addScore(SCORE.blocked, "BLOCKED +100", "#5eead4");
            this.sound("blocked");
            this.burst(this.player.x, 1.4, 0.4, "#67e8f9", 22);
          } else {
            e.blocked = false;
            this.damage("DRONE HIT");
          }
        }
      }
    }

    this.player.update(dt, now, running && this.speed > 0);
    if (this.player.airborne && this.player.height > 0.2 && Math.random() < 0.6 && !this.reducedMotion) {
      this.particles.push({ x: this.player.x + (Math.random() - 0.5) * 0.3, y: this.player.height + 0.2, z: 0.2, vx: 0, vy: -0.4, vz: -1.5, life: 0.35, maxLife: 0.35, color: "#67e8f9", size: 2 });
    }
    const hacking = this.activeTerminal();
    if (hacking?.state === "hacking" && Math.random() < 0.7) {
      const tz = this.z(hacking);
      this.particles.push({ x: hacking.variant === "terminal" ? 2.2 : 0, y: 0.8 + Math.random() * 1.4, z: tz, vx: (this.player.x - (hacking.variant === "terminal" ? 2.2 : 0)) * 0.9, vy: (Math.random() - 0.5) * 0.6, vz: -tz * 0.9, life: 1, maxLife: 1, color: "#5eead4", size: 11, glyph: Math.random() < 0.5 ? "0" : "1" });
    }
    this.updateParticles(dt);
    this.popups = this.popups.filter((p) => now - p.born < 1100);
    this.hint = this.computeHint();
  }

  private completeHack(t: Terminal) {
    t.state = "done";
    t.doneAt = this.clock;
    t.passed = true;
    this.stats.hacks++;
    this.outcome(1);
    this.bumpStreak();
    this.addScore(SCORE.hack, "+250", "#5eead4");
    this.popup(t.variant === "door" ? "DOOR UNLOCKED" : t.variant === "core" ? "DATA CORE EXTRACTED" : "TERMINAL HACKED", "#5eead4", true);
    this.burst(t.variant === "terminal" ? 2.2 : 0, 1.2, this.z(t), "#5eead4", 36);
    if (t.variant === "door" || t.variant === "core") {
      const last = this.levelIndex >= LEVELS.length - 1;
      this.setState(last ? "victory" : "levelComplete");
      this.sound("levelComplete");
      this.burst(0, 1.5, 4, "#c084fc", 60);
    } else this.sound("success");
  }

  burst(x: number, h: number, z: number, color: string, n: number): void {
    const count = this.reducedMotion ? Math.ceil(n / 3) : n;
    for (let i = 0; i < count; i++) {
      const a = Math.random() * Math.PI * 2;
      const s = 1 + Math.random() * 2.5;
      this.particles.push({ x, y: h, z, vx: Math.cos(a) * s, vy: Math.sin(a) * s + 1, vz: (Math.random() - 0.5) * 2, life: 0.9, maxLife: 0.9, color, size: 2 + Math.random() * 2 });
    }
    if (this.particles.length > 320) this.particles.splice(0, this.particles.length - 320);
  }

  private updateParticles(dt: number) {
    for (const p of this.particles) {
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.z += p.vz * dt;
      p.vy -= 2.5 * dt;
      p.life -= dt;
    }
    this.particles = this.particles.filter((p) => p.life > 0);
  }
}

/** triggerGameAction(engine, event) — the gesture → game action mapping. */
export function triggerGameAction(engine: GameEngine, ev: GestureEvent): ActionResult {
  return engine.handleGesture(ev);
}
