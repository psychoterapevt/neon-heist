/** Low horizontal laser across the whole corridor — must be jumped. */
export class LaserLow {
  readonly kind = "laserLow" as const;
  static readonly HEIGHT = 0.45; // metres
  passed = false;
  hit = false;
  /** Set when the jump was timed perfectly (bonus on clear). */
  perfect = false;
  constructor(
    readonly id: number,
    readonly at: number,
  ) {}
}

/** Vertical laser curtain that blocks specific lanes — move to a free lane. */
export class LaserWall {
  readonly kind = "laserWall" as const;
  static readonly HEIGHT = 2.3;
  passed = false;
  hit = false;
  constructor(
    readonly id: number,
    readonly at: number,
    readonly lanes: number[],
  ) {}

  blocks(lane: number): boolean {
    return this.lanes.includes(lane);
  }

  safeLanes(): number[] {
    return [0, 1, 2].filter((l) => !this.lanes.includes(l));
  }
}
