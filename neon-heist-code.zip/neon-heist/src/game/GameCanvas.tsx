import { useEffect, useRef } from "react";
import type { GameEngine } from "./GameEngine";
import { renderGame } from "./renderer";

/**
 * Game world canvas. Its own requestAnimationFrame loop:
 * fixed-step simulation (60 Hz) + one render per display frame.
 * Independent from the vision loop — gesture events are queued into the engine.
 */
export default function GameCanvas({ engine, onTick }: { engine: GameEngine; onTick?: (now: number) => void }) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const onTickRef = useRef(onTick);
  onTickRef.current = onTick;

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d", { alpha: false });
    if (!ctx) return;
    let raf = 0;
    let last = performance.now();
    let acc = 0;
    const STEP = 1000 / 60;
    let cssW = 0;
    let cssH = 0;

    const resize = () => {
      const dpr = Math.min(2, window.devicePixelRatio || 1);
      cssW = canvas.clientWidth;
      cssH = canvas.clientHeight;
      canvas.width = Math.max(1, Math.round(cssW * dpr));
      canvas.height = Math.max(1, Math.round(cssH * dpr));
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };
    resize();
    const ro = new ResizeObserver(resize);
    ro.observe(canvas);

    const frame = (now: number) => {
      acc += Math.min(250, now - last);
      last = now;
      while (acc >= STEP) {
        engine.update(STEP);
        acc -= STEP;
      }
      renderGame(ctx, cssW, cssH, engine, now);
      onTickRef.current?.(now);
      raf = requestAnimationFrame(frame);
    };
    raf = requestAnimationFrame(frame);
    return () => {
      cancelAnimationFrame(raf);
      ro.disconnect();
    };
  }, [engine]);

  return (
    <canvas
      ref={canvasRef}
      className="absolute inset-0 h-full w-full"
      role="img"
      aria-label="Game view: your hacker runs through a security corridor"
    />
  );
}
