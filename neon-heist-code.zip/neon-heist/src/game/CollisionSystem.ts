import { Block } from "./Enemy";
import { LaserLow, LaserWall } from "./Laser";
import type { Player } from "./Player";
import { laneX } from "./types";

export type Obstacle = LaserLow | LaserWall | Block;

/** Half-width of the player's body for lane collisions (metres). */
export const PLAYER_HALF_WIDTH = 0.45;
/** Half-width of a lane obstacle (laser curtain / crate). */
const OBSTACLE_HALF_WIDTH = 0.55;

/**
 * Collision test at the moment an obstacle passes the player plane (z crosses 0).
 * - LaserLow: hit unless the player's feet are above the beam.
 * - LaserWall: hit if the player's body overlaps a blocked lane.
 * - Block: hit if the player overlaps the crate's lateral position.
 */
export function collides(o: Obstacle, player: Player): boolean {
  if (o instanceof LaserLow) return player.height < LaserLow.HEIGHT + 0.05;
  if (o instanceof LaserWall) {
    return o.lanes.some((l) => Math.abs(player.x - laneX(l)) < PLAYER_HALF_WIDTH + OBSTACLE_HALF_WIDTH - 0.2);
  }
  return player.height < Block.HEIGHT && Math.abs(player.x - o.xAt(0)) < PLAYER_HALF_WIDTH + OBSTACLE_HALF_WIDTH - 0.2;
}

/**
 * Checks every obstacle whose z crossed 0 during this step.
 * Returns the obstacles that were passed, each with its outcome.
 */
export function resolvePasses(
  obstacles: Obstacle[],
  prevDistance: number,
  distance: number,
  player: Player,
): Array<{ obstacle: Obstacle; hit: boolean }> {
  const out: Array<{ obstacle: Obstacle; hit: boolean }> = [];
  for (const o of obstacles) {
    if (o.passed) continue;
    if (prevDistance < o.at && distance >= o.at) {
      o.passed = true;
      o.hit = collides(o, player);
      out.push({ obstacle: o, hit: o.hit });
    }
  }
  return out;
}
