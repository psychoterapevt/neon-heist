import type { GameEngine } from "./GameEngine";
import { Block, Drone } from "./Enemy";
import { LaserLow, LaserWall } from "./Laser";
import { Terminal } from "./Terminal";
import { PLAYER, type Player } from "./Player";
import { laneX } from "./types";

/**
 * Pseudo-3D canvas renderer (one-point perspective corridor).
 * World: x = metres right of centre, h = metres above the floor, z = metres ahead.
 */
interface View {
  w: number;
  h: number;
  cx: number;
  horizonY: number;
  focal: number;
  z0: number;
  camH: number;
}

const HALF_W = 2.8; // corridor half width (m)
const WALL_H = 3.4;
const FAR = 60;

const C = {
  bgTop: "#05070d",
  bgBottom: "#0a0f1c",
  wall: "#0c1322",
  floor: "#0a1020",
  grid: "94, 234, 212", // teal rgb
  lane: "103, 232, 249",
  laser: "255, 59, 92",
  amber: "251, 191, 36",
  violet: "192, 132, 252",
  cyan: "#67e8f9",
  teal: "#5eead4",
};

function makeView(w: number, h: number): View {
  const z0 = 3.2;
  const horizonY = h * 0.34;
  // The 3 lanes (4.8 m) span ~half the screen width at the player's depth (capped by height).
  const focal = (Math.min(0.5 * w, 0.78 * h) * z0) / 4.8;
  const groundY0 = h * 0.86;
  const camH = ((groundY0 - horizonY) * z0) / focal;
  return { w, h, cx: w / 2, horizonY, focal, z0, camH };
}

function P(v: View, x: number, hgt: number, z: number) {
  const p = v.focal / Math.max(0.05, z + v.z0);
  return { x: v.cx + x * p, y: v.horizonY + (v.camH - hgt) * p, s: p };
}

const fogAlpha = (z: number) => Math.max(0, Math.min(1, 1 - z / FAR));

function line(ctx: CanvasRenderingContext2D, a: { x: number; y: number }, b: { x: number; y: number }) {
  ctx.beginPath();
  ctx.moveTo(a.x, a.y);
  ctx.lineTo(b.x, b.y);
  ctx.stroke();
}

/** Glow line without shadowBlur (cheap): 3 passes with decreasing width. */
function glowLine(ctx: CanvasRenderingContext2D, a: { x: number; y: number }, b: { x: number; y: number }, rgb: string, width: number, alpha: number) {
  ctx.lineCap = "round";
  for (const [k, al] of [
    [4, 0.12],
    [2, 0.28],
    [1, 1],
  ] as const) {
    ctx.strokeStyle = `rgba(${rgb}, ${al * alpha})`;
    ctx.lineWidth = Math.max(1, width * k);
    line(ctx, a, b);
  }
  ctx.strokeStyle = `rgba(255,255,255,${0.7 * alpha})`;
  ctx.lineWidth = Math.max(0.5, width * 0.35);
  line(ctx, a, b);
}

function drawCorridor(ctx: CanvasRenderingContext2D, v: View, e: GameEngine) {
  const g = ctx.createLinearGradient(0, 0, 0, v.h);
  g.addColorStop(0, C.bgTop);
  g.addColorStop(1, C.bgBottom);
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, v.w, v.h);

  const nearZ = -2.6;
  const quad = (pts: Array<{ x: number; y: number }>, fill: string | CanvasGradient) => {
    ctx.fillStyle = fill;
    ctx.beginPath();
    pts.forEach((p, i) => (i ? ctx.lineTo(p.x, p.y) : ctx.moveTo(p.x, p.y)));
    ctx.closePath();
    ctx.fill();
  };
  // floor, walls, ceiling
  const fl = [P(v, -HALF_W, 0, nearZ), P(v, HALF_W, 0, nearZ), P(v, HALF_W, 0, FAR), P(v, -HALF_W, 0, FAR)];
  const floorG = ctx.createLinearGradient(0, v.horizonY, 0, v.h);
  floorG.addColorStop(0, "#060a14");
  floorG.addColorStop(1, "#0d1528");
  quad(fl, floorG);
  const wallG = ctx.createLinearGradient(0, 0, v.cx, 0);
  wallG.addColorStop(0, "#101a2e");
  wallG.addColorStop(1, "#070b15");
  quad([P(v, -HALF_W, 0, nearZ), P(v, -HALF_W, WALL_H, nearZ), P(v, -HALF_W, WALL_H, FAR), P(v, -HALF_W, 0, FAR)], wallG);
  const wallG2 = ctx.createLinearGradient(v.w, 0, v.cx, 0);
  wallG2.addColorStop(0, "#101a2e");
  wallG2.addColorStop(1, "#070b15");
  quad([P(v, HALF_W, 0, nearZ), P(v, HALF_W, WALL_H, nearZ), P(v, HALF_W, WALL_H, FAR), P(v, HALF_W, 0, FAR)], wallG2);
  quad([P(v, -HALF_W, WALL_H, nearZ), P(v, HALF_W, WALL_H, nearZ), P(v, HALF_W, WALL_H, FAR), P(v, -HALF_W, WALL_H, FAR)], "#05080f");

  // scrolling cross lines (floor) + wall panel seams + ceiling lights
  const spacing = 2;
  const off = e.distance % spacing;
  ctx.lineWidth = 1;
  for (let z = spacing - off; z < FAR; z += spacing) {
    const a = fogAlpha(z);
    ctx.strokeStyle = `rgba(${C.grid}, ${0.13 * a})`;
    line(ctx, P(v, -HALF_W, 0, z), P(v, HALF_W, 0, z));
  }
  const seam = 4;
  const off2 = e.distance % seam;
  for (let z = seam - off2; z < FAR; z += seam) {
    const a = fogAlpha(z);
    ctx.strokeStyle = `rgba(148, 163, 184, ${0.12 * a})`;
    line(ctx, P(v, -HALF_W, 0, z), P(v, -HALF_W, WALL_H, z));
    line(ctx, P(v, HALF_W, 0, z), P(v, HALF_W, WALL_H, z));
    // ceiling light bar
    ctx.strokeStyle = `rgba(226, 232, 240, ${0.35 * a})`;
    ctx.lineWidth = Math.max(1, 3 * P(v, 0, 0, z).s * 0.02);
    line(ctx, P(v, -0.9, WALL_H, z), P(v, 0.9, WALL_H, z));
    ctx.lineWidth = 1;
  }
  // lane lines
  for (const x of [-2.4, -0.8, 0.8, 2.4]) {
    ctx.strokeStyle = `rgba(${C.lane}, ${Math.abs(x) > 2 ? 0.18 : 0.12})`;
    ctx.lineWidth = 1.5;
    line(ctx, P(v, x, 0, nearZ), P(v, x, 0, FAR));
  }
  // neon strips along walls
  for (const x of [-HALF_W, HALF_W]) {
    glowLine(ctx, P(v, x, 0.35, nearZ), P(v, x, 0.35, FAR), "103, 232, 249", 1.2, 0.35);
  }
  // current lane highlight
  const lx = laneX(e.player.lane);
  ctx.fillStyle = "rgba(103, 232, 249, 0.045)";
  ctx.beginPath();
  const l1 = P(v, lx - 0.8, 0, nearZ);
  const l2 = P(v, lx + 0.8, 0, nearZ);
  const l3 = P(v, lx + 0.8, 0, 22);
  const l4 = P(v, lx - 0.8, 0, 22);
  ctx.moveTo(l1.x, l1.y);
  ctx.lineTo(l2.x, l2.y);
  ctx.lineTo(l3.x, l3.y);
  ctx.lineTo(l4.x, l4.y);
  ctx.fill();
  // horizon glow
  const hg = ctx.createRadialGradient(v.cx, v.horizonY, 0, v.cx, v.horizonY, v.w * 0.25);
  hg.addColorStop(0, "rgba(103, 232, 249, 0.10)");
  hg.addColorStop(1, "rgba(103, 232, 249, 0)");
  ctx.fillStyle = hg;
  ctx.fillRect(0, 0, v.w, v.h * 0.7);
}

function drawLaserLow(ctx: CanvasRenderingContext2D, v: View, o: LaserLow, z: number, t: number) {
  const a = fogAlpha(z) * (o.hit ? 0.4 : 1);
  const pulse = 0.8 + 0.2 * Math.sin(t / 90);
  const L = P(v, -HALF_W + 0.1, LaserLow.HEIGHT, z);
  const R = P(v, HALF_W - 0.1, LaserLow.HEIGHT, z);
  // emitters
  ctx.fillStyle = `rgba(30, 41, 59, ${a})`;
  for (const x of [-HALF_W + 0.1, HALF_W - 0.1]) {
    const b = P(v, x, 0, z);
    const tp = P(v, x, 0.8, z);
    ctx.fillRect(b.x - b.s * 0.08, tp.y, b.s * 0.16, b.y - tp.y);
  }
  glowLine(ctx, L, R, C.laser, Math.max(1.2, L.s * 0.025), a * pulse);
  // floor reflection
  const f1 = P(v, -HALF_W, 0, z);
  const f2 = P(v, HALF_W, 0, z);
  ctx.strokeStyle = `rgba(${C.laser}, ${0.18 * a})`;
  ctx.lineWidth = Math.max(1, f1.s * 0.05);
  line(ctx, f1, f2);
}

function drawLaserWall(ctx: CanvasRenderingContext2D, v: View, o: LaserWall, z: number, t: number) {
  const a = fogAlpha(z) * (o.hit ? 0.4 : 1);
  for (const lane of o.lanes) {
    const x = laneX(lane);
    // floor danger zone
    const q = [P(v, x - 0.75, 0, z - 0.4), P(v, x + 0.75, 0, z - 0.4), P(v, x + 0.75, 0, z + 0.4), P(v, x - 0.75, 0, z + 0.4)];
    ctx.fillStyle = `rgba(${C.laser}, ${0.14 * a})`;
    ctx.beginPath();
    q.forEach((p, i) => (i ? ctx.lineTo(p.x, p.y) : ctx.moveTo(p.x, p.y)));
    ctx.fill();
    for (let i = 0; i < 4; i++) {
      const bx = x - 0.6 + i * 0.4;
      const flick = 0.75 + 0.25 * Math.sin(t / 70 + i * 1.7 + lane);
      glowLine(ctx, P(v, bx, 0, z), P(v, bx, LaserWall.HEIGHT, z), C.laser, Math.max(1, P(v, 0, 0, z).s * 0.012), a * flick);
    }
    const top1 = P(v, x - 0.75, LaserWall.HEIGHT, z);
    const top2 = P(v, x + 0.75, LaserWall.HEIGHT, z);
    ctx.fillStyle = `rgba(51, 65, 85, ${a})`;
    ctx.fillRect(top1.x, top1.y - top1.s * 0.08, top2.x - top1.x, top1.s * 0.1);
  }
}

function drawBlock(ctx: CanvasRenderingContext2D, v: View, o: Block, z: number, t: number) {
  const a = fogAlpha(z) * (o.hit ? 0.45 : 1);
  const x = o.xAt(z);
  // telegraph the destination lane on the floor near the player
  if (z > 0 && z < Block.SLIDE_START_Z + 4) {
    const tx = laneX(o.to);
    const pulse = 0.5 + 0.5 * Math.sin(t / 160);
    ctx.fillStyle = `rgba(${C.amber}, ${0.08 + 0.08 * pulse})`;
    const q = [P(v, tx - 0.75, 0, Math.max(0, z - 6)), P(v, tx + 0.75, 0, Math.max(0, z - 6)), P(v, tx + 0.75, 0, z), P(v, tx - 0.75, 0, z)];
    ctx.beginPath();
    q.forEach((p, i) => (i ? ctx.lineTo(p.x, p.y) : ctx.moveTo(p.x, p.y)));
    ctx.fill();
  }
  const w = 0.62;
  const H = Block.HEIGHT;
  const d = 0.9;
  const f = [P(v, x - w, 0, z), P(v, x + w, 0, z), P(v, x + w, H, z), P(v, x - w, H, z)];
  const b = [P(v, x - w, 0, z + d), P(v, x + w, 0, z + d), P(v, x + w, H, z + d), P(v, x - w, H, z + d)];
  const poly = (pts: Array<{ x: number; y: number }>, fill: string, stroke?: string) => {
    ctx.beginPath();
    pts.forEach((p, i) => (i ? ctx.lineTo(p.x, p.y) : ctx.moveTo(p.x, p.y)));
    ctx.closePath();
    ctx.fillStyle = fill;
    ctx.fill();
    if (stroke) {
      ctx.strokeStyle = stroke;
      ctx.lineWidth = 1.5;
      ctx.stroke();
    }
  };
  poly([f[3], f[2], b[2], b[3]], `rgba(71, 85, 105, ${a})`); // top
  if (x > 0.05) poly([f[0], f[3], b[3], b[0]], `rgba(30, 41, 59, ${a})`);
  if (x < -0.05) poly([f[1], f[2], b[2], b[1]], `rgba(30, 41, 59, ${a})`);
  poly(f, `rgba(15, 23, 42, ${a})`, `rgba(${C.amber}, ${0.9 * a})`);
  // hazard stripes
  ctx.save();
  ctx.beginPath();
  ctx.rect(f[0].x, f[2].y, f[1].x - f[0].x, f[0].y - f[2].y);
  ctx.clip();
  ctx.strokeStyle = `rgba(${C.amber}, ${0.55 * a})`;
  ctx.lineWidth = Math.max(1, f[0].s * 0.08);
  const hgt = f[0].y - f[2].y;
  for (let i = -4; i < 8; i++) {
    const sx = f[0].x + (i * (f[1].x - f[0].x)) / 5;
    line(ctx, { x: sx, y: f[0].y }, { x: sx + hgt * 0.6, y: f[2].y });
  }
  ctx.restore();
}

function drawDrone(ctx: CanvasRenderingContext2D, v: View, d: Drone, e: GameEngine, t: number) {
  if (d.phase === "waiting" || d.phase === "done") return;
  const k = d.progress(e.clock);
  let h = Drone.HOVER_H + Math.sin(t / 260) * 0.08;
  let z = Drone.HOVER_Z;
  if (d.phase === "enter") {
    h += (1 - k) * 3;
    z += (1 - k) * 14;
  }
  if (d.phase === "leave") {
    h += k * 4;
    z += k * 6;
  }
  const c = P(v, d.x, h, z);
  const r = c.s * 0.34;
  const player = P(v, e.player.x, e.player.height + 1.1, 0);

  // charge beam (telegraph) / fire
  if (d.phase === "charge") {
    ctx.setLineDash([6, 8]);
    ctx.strokeStyle = `rgba(${C.laser}, ${0.25 + 0.5 * k})`;
    ctx.lineWidth = 1 + 3 * k;
    line(ctx, c, player);
    ctx.setLineDash([]);
    // target reticle on the player
    ctx.strokeStyle = `rgba(${C.laser}, ${0.4 + 0.5 * k})`;
    ctx.lineWidth = 2;
    const rr = player.s * (0.9 - 0.4 * k);
    ctx.beginPath();
    ctx.arc(player.x, player.y, rr, 0, Math.PI * 2);
    ctx.stroke();
    for (let i = 0; i < 4; i++) {
      const ang = (i * Math.PI) / 2;
      line(ctx, { x: player.x + Math.cos(ang) * rr * 0.7, y: player.y + Math.sin(ang) * rr * 0.7 }, { x: player.x + Math.cos(ang) * rr * 1.25, y: player.y + Math.sin(ang) * rr * 1.25 });
    }
  }
  if (d.phase === "fire") {
    const end = d.blocked ? { x: player.x + (c.x - player.x) * 0.22, y: player.y + (c.y - player.y) * 0.22 } : player;
    glowLine(ctx, c, end, C.laser, Math.max(3, c.s * 0.05), 1);
  }

  // body
  ctx.save();
  ctx.translate(c.x, c.y);
  ctx.strokeStyle = "rgba(148, 163, 184, 0.9)";
  ctx.lineWidth = Math.max(1, r * 0.12);
  for (const s of [-1, 1]) {
    line(ctx, { x: s * r * 0.6, y: 0 }, { x: s * r * 1.6, y: -r * 0.35 });
    ctx.beginPath();
    ctx.ellipse(s * r * 1.6, -r * 0.4, r * 0.55, r * 0.12, 0, 0, Math.PI * 2);
    ctx.stroke();
  }
  ctx.fillStyle = "#1e293b";
  ctx.beginPath();
  ctx.ellipse(0, 0, r, r * 0.62, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.strokeStyle = "rgba(226, 232, 240, 0.35)";
  ctx.lineWidth = Math.max(1, r * 0.06);
  ctx.stroke();
  const eye = d.phase === "charge" ? 0.5 + 0.5 * Math.sin(t / (60 - 40 * k)) : 0.8;
  const eg = ctx.createRadialGradient(0, r * 0.1, 0, 0, r * 0.1, r * 0.7);
  eg.addColorStop(0, `rgba(255, 90, 110, ${eye})`);
  eg.addColorStop(1, "rgba(255, 59, 92, 0)");
  ctx.fillStyle = eg;
  ctx.beginPath();
  ctx.arc(0, r * 0.1, r * 0.7, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = "#fecdd3";
  ctx.beginPath();
  ctx.arc(0, r * 0.1, r * 0.16, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

function drawTerminal(ctx: CanvasRenderingContext2D, v: View, o: Terminal, e: GameEngine, z: number, t: number) {
  const a = fogAlpha(z);
  const prog = o.progress(e.clock, PLAYER.hackMs);
  const col = o.state === "done" ? "52, 211, 153" : o.state === "waiting" ? "103, 232, 249" : o.state === "hacking" ? "94, 234, 212" : "148, 163, 184";
  const pulse = o.state === "waiting" ? 0.6 + 0.4 * Math.sin(t / 180) : 1;

  if (o.variant === "terminal") {
    const x = 2.25;
    const f = [P(v, x - 0.45, 0, z), P(v, x + 0.45, 0, z), P(v, x + 0.45, 1.7, z), P(v, x - 0.45, 1.7, z)];
    ctx.fillStyle = `rgba(15, 23, 42, ${a})`;
    ctx.beginPath();
    f.forEach((p, i) => (i ? ctx.lineTo(p.x, p.y) : ctx.moveTo(p.x, p.y)));
    ctx.closePath();
    ctx.fill();
    ctx.strokeStyle = `rgba(${col}, ${0.8 * a * pulse})`;
    ctx.lineWidth = 2;
    ctx.stroke();
    const s1 = P(v, x - 0.35, 1.55, z);
    const s2 = P(v, x + 0.35, 0.9, z);
    ctx.fillStyle = `rgba(${col}, ${0.18 * a * pulse})`;
    ctx.fillRect(s1.x, s1.y, s2.x - s1.x, s2.y - s1.y);
    if (o.state === "hacking" || o.state === "done") {
      ctx.fillStyle = `rgba(${col}, ${0.85 * a})`;
      ctx.fillRect(s1.x + 2, s2.y - (s2.y - s1.y) * 0.2, (s2.x - s1.x - 4) * prog, (s2.y - s1.y) * 0.12);
    }
    ctx.fillStyle = `rgba(${col}, ${a})`;
    ctx.font = `700 ${Math.max(8, s1.s * 0.14)}px ui-monospace, monospace`;
    ctx.textAlign = "center";
    ctx.fillText(o.state === "done" ? "OK" : o.state === "hacking" ? `${Math.round(prog * 100)}%` : "LOCK", (s1.x + s2.x) / 2, (s1.y + s2.y) / 2);
    return;
  }

  if (o.variant === "door") {
    const open = o.state === "done" ? Math.min(1, (e.clock - o.doneAt) / 800) : 0;
    const H = 3.1;
    const frameL = [P(v, -HALF_W, 0, z), P(v, -HALF_W, H, z)];
    const frameR = [P(v, HALF_W, 0, z), P(v, HALF_W, H, z)];
    for (const side of [-1, 1]) {
      const inner = side * (0.02 + open * 2.6);
      const outer = side * HALF_W;
      const q = [P(v, inner, 0, z), P(v, outer, 0, z), P(v, outer, H, z), P(v, inner, H, z)];
      ctx.fillStyle = `rgba(17, 24, 39, ${a})`;
      ctx.beginPath();
      q.forEach((p, i) => (i ? ctx.lineTo(p.x, p.y) : ctx.moveTo(p.x, p.y)));
      ctx.closePath();
      ctx.fill();
      ctx.strokeStyle = `rgba(${col}, ${0.6 * a * pulse})`;
      ctx.lineWidth = 2;
      ctx.stroke();
      // panel lines
      ctx.strokeStyle = `rgba(148, 163, 184, ${0.15 * a})`;
      for (let i = 1; i < 4; i++) line(ctx, P(v, inner, (H * i) / 4, z), P(v, outer, (H * i) / 4, z));
    }
    glowLine(ctx, frameL[0], frameL[1], col, 2, a * pulse);
    glowLine(ctx, frameR[0], frameR[1], col, 2, a * pulse);
    if (open < 1) {
      const lc = P(v, 0, 1.6, z);
      ctx.fillStyle = `rgba(${col}, ${a})`;
      ctx.strokeStyle = `rgba(${col}, ${a})`;
      ctx.lineWidth = Math.max(2, lc.s * 0.04);
      const s = lc.s * 0.18;
      ctx.strokeRect(lc.x - s, lc.y - s * 0.2, s * 2, s * 1.4);
      ctx.beginPath();
      ctx.arc(lc.x, lc.y - s * 0.2, s * 0.65, Math.PI, 0);
      ctx.stroke();
      if (o.state === "hacking") {
        ctx.beginPath();
        ctx.arc(lc.x, lc.y + s * 0.5, s * 1.6, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * prog);
        ctx.stroke();
      }
    }
    return;
  }

  // core
  const c = P(v, 0, 1.5 + Math.sin(t / 400) * 0.1, z);
  const r = c.s * 0.55;
  const glow = ctx.createRadialGradient(c.x, c.y, 0, c.x, c.y, r * 3);
  glow.addColorStop(0, `rgba(${o.state === "done" ? "52, 211, 153" : "192, 132, 252"}, ${0.35 * a})`);
  glow.addColorStop(1, "rgba(192, 132, 252, 0)");
  ctx.fillStyle = glow;
  ctx.fillRect(c.x - r * 3, c.y - r * 3, r * 6, r * 6);
  const ped1 = P(v, -0.5, 0, z);
  const ped2 = P(v, 0.5, 0.6, z);
  ctx.fillStyle = `rgba(30, 41, 59, ${a})`;
  ctx.fillRect(ped1.x, ped2.y, ped2.x - ped1.x, ped1.y - ped2.y);
  if (o.state !== "done" || e.clock - o.doneAt < 600) {
    ctx.save();
    ctx.translate(c.x, c.y);
    ctx.rotate(t / 1200);
    ctx.strokeStyle = `rgba(233, 213, 255, ${a})`;
    ctx.fillStyle = `rgba(${C.violet}, ${0.35 * a})`;
    ctx.lineWidth = 2;
    ctx.beginPath();
    for (let i = 0; i < 6; i++) {
      const ang = (i * Math.PI) / 3;
      const px = Math.cos(ang) * r;
      const py = Math.sin(ang) * r * 1.3;
      if (i) ctx.lineTo(px, py);
      else ctx.moveTo(px, py);
    }
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
    ctx.restore();
    if (o.state === "hacking") {
      ctx.strokeStyle = C.teal;
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.arc(c.x, c.y, r * 1.6, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * prog);
      ctx.stroke();
    }
  }
}

function drawPlayer(ctx: CanvasRenderingContext2D, v: View, p: Player, e: GameEngine, t: number) {
  const now = e.clock;
  const ground = P(v, p.x, 0, 0);
  const s = ground.s; // px per metre
  // shadow
  const shadowK = Math.max(0.35, 1 - p.height / 2.5);
  ctx.fillStyle = `rgba(0,0,0,${0.45 * shadowK})`;
  ctx.beginPath();
  ctx.ellipse(ground.x, ground.y, s * 0.42 * shadowK, s * 0.1 * shadowK, 0, 0, Math.PI * 2);
  ctx.fill();

  const invuln = now < p.invulnerableUntil;
  if (invuln && Math.floor(now / 90) % 2 === 0) return; // hit blink
  const base = P(v, p.x, p.height, 0);
  const crouch = p.jumpQueuedAt !== null ? 0.88 : 1; // anticipation squash
  const airborne = p.height > 0.02;
  const hurt = now - p.hitAt < 300;
  const running = e.speed > 0 && !airborne;
  const phase = p.runPhase;

  ctx.save();
  ctx.translate(base.x, base.y);
  ctx.scale(s, -s * crouch); // local units: metres, y up
  const lw = 0.02 * (1 / s) * 60;
  ctx.lineWidth = Math.max(0.02, lw);
  ctx.lineCap = "round";
  ctx.lineJoin = "round";

  // legs
  const legLift = (i: number) => (running ? Math.max(0, Math.sin(phase + i * Math.PI)) * 0.16 : 0);
  const tuck = airborne ? 0.22 : 0;
  ctx.fillStyle = hurt ? "#7f1d1d" : "#111827";
  for (const [i, lx] of [
    [0, -0.14],
    [1, 0.14],
  ] as const) {
    const foot = legLift(i) + tuck;
    ctx.beginPath();
    ctx.roundRect(lx - 0.08, foot, 0.16, 0.78 - foot, 0.05);
    ctx.fill();
    ctx.fillStyle = "#67e8f9";
    ctx.fillRect(lx - 0.08, foot, 0.16, 0.035);
    ctx.fillStyle = hurt ? "#7f1d1d" : "#111827";
  }
  // arms
  const hacking = p.hacking(now);
  const shield = p.shieldActive(now);
  ctx.strokeStyle = hurt ? "#991b1b" : "#1f2937";
  ctx.lineWidth = 0.13;
  const swing = running ? Math.sin(phase) * 0.1 : 0;
  if (hacking) {
    line(ctx, { x: -0.3, y: 1.22 }, { x: -0.38, y: 0.85 + swing });
    line(ctx, { x: 0.3, y: 1.25 }, { x: 0.78, y: 1.35 });
  } else if (shield) {
    line(ctx, { x: -0.3, y: 1.22 }, { x: -0.45, y: 1.45 });
    line(ctx, { x: 0.3, y: 1.22 }, { x: 0.45, y: 1.45 });
  } else if (airborne) {
    line(ctx, { x: -0.3, y: 1.22 }, { x: -0.5, y: 1.62 });
    line(ctx, { x: 0.3, y: 1.22 }, { x: 0.5, y: 1.62 });
  } else {
    line(ctx, { x: -0.3, y: 1.22 }, { x: -0.36, y: 0.86 + swing });
    line(ctx, { x: 0.3, y: 1.22 }, { x: 0.36, y: 0.86 - swing });
  }
  // torso (jacket)
  ctx.fillStyle = hurt ? "#7f1d1d" : "#1b2437";
  ctx.beginPath();
  ctx.moveTo(-0.3, 0.74);
  ctx.lineTo(0.3, 0.74);
  ctx.lineTo(0.34, 1.3);
  ctx.quadraticCurveTo(0, 1.4, -0.34, 1.3);
  ctx.closePath();
  ctx.fill();
  // backpack with glowing strip
  ctx.fillStyle = "#0f172a";
  ctx.beginPath();
  ctx.roundRect(-0.2, 0.86, 0.4, 0.4, 0.05);
  ctx.fill();
  ctx.fillStyle = shield ? "#a5f3fc" : "#5eead4";
  ctx.fillRect(-0.14, 1.02, 0.28, 0.045);
  ctx.fillRect(-0.14, 1.1, 0.18, 0.03);
  // hood / head
  ctx.fillStyle = hurt ? "#991b1b" : "#111827";
  ctx.beginPath();
  ctx.ellipse(0, 1.54, 0.2, 0.22, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.strokeStyle = "rgba(244, 114, 182, 0.9)";
  ctx.lineWidth = 0.03;
  ctx.beginPath();
  ctx.ellipse(0, 1.54, 0.2, 0.22, 0, Math.PI * 0.05, Math.PI * 0.45);
  ctx.stroke();
  ctx.beginPath();
  ctx.ellipse(0, 1.54, 0.2, 0.22, 0, Math.PI * 0.55, Math.PI * 0.95);
  ctx.stroke();
  ctx.restore();

  // shield bubble
  if (shield) {
    const left = p.shieldUntil - now;
    const blink = left < 500 ? (Math.floor(now / 80) % 2 ? 0.3 : 1) : 1;
    const c = P(v, p.x, p.height + 0.95, 0);
    const R = s * 0.95;
    ctx.save();
    ctx.globalCompositeOperation = "lighter";
    const g = ctx.createRadialGradient(c.x, c.y, R * 0.6, c.x, c.y, R);
    g.addColorStop(0, "rgba(103, 232, 249, 0)");
    g.addColorStop(1, `rgba(103, 232, 249, ${0.35 * blink})`);
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.ellipse(c.x, c.y, R * 0.85, R, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = `rgba(165, 243, 252, ${0.8 * blink})`;
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.ellipse(c.x, c.y, R * 0.85, R, 0, 0, Math.PI * 2);
    ctx.stroke();
    // energy ring
    const k = (t % 900) / 900;
    ctx.strokeStyle = `rgba(165, 243, 252, ${(1 - k) * 0.6 * blink})`;
    ctx.beginPath();
    ctx.ellipse(c.x, c.y, R * 0.85 * (0.6 + 0.4 * k), R * (0.6 + 0.4 * k), 0, 0, Math.PI * 2);
    ctx.stroke();
    ctx.restore();
  }
}

/** Renders one frame of the game. */
export function renderGame(ctx: CanvasRenderingContext2D, w: number, h: number, e: GameEngine, t: number): void {
  const v = makeView(w, h);
  ctx.save();
  if (e.clock < e.shakeUntil && !e.reducedMotion) {
    const k = (e.shakeUntil - e.clock) / 380;
    ctx.translate((Math.random() - 0.5) * e.shakeMag * k, (Math.random() - 0.5) * e.shakeMag * k);
  }
  drawCorridor(ctx, v, e);

  const drawables = e.entities
    .map((ent) => ({ ent, z: ent instanceof Drone ? Drone.HOVER_Z : ent.at - e.distance }))
    .filter((d) => d.z < FAR && d.z > -0.8 && !(d.ent instanceof Terminal && d.ent.state === "done" && d.ent.variant === "terminal" && d.z < 0.5))
    .sort((a, b) => b.z - a.z);
  let playerDrawn = false;
  for (const { ent, z } of drawables) {
    if (!playerDrawn && z < 0.3) {
      drawPlayer(ctx, v, e.player, e, t);
      playerDrawn = true;
    }
    if (ent instanceof LaserLow) drawLaserLow(ctx, v, ent, z, t);
    else if (ent instanceof LaserWall) drawLaserWall(ctx, v, ent, z, t);
    else if (ent instanceof Block) drawBlock(ctx, v, ent, z, t);
    else if (ent instanceof Terminal) drawTerminal(ctx, v, ent, e, z, t);
  }
  if (!playerDrawn) drawPlayer(ctx, v, e.player, e, t);
  for (const ent of e.entities) if (ent instanceof Drone) drawDrone(ctx, v, ent, e, t);

  // particles
  for (const p of e.particles) {
    const q = P(v, p.x, p.y, Math.max(-0.5, p.z));
    const a = Math.max(0, p.life / p.maxLife);
    if (p.glyph) {
      ctx.fillStyle = `rgba(94, 234, 212, ${a})`;
      ctx.font = `700 ${Math.max(9, q.s * 0.12)}px ui-monospace, monospace`;
      ctx.fillText(p.glyph, q.x, q.y);
    } else {
      ctx.fillStyle = p.color;
      ctx.globalAlpha = a;
      ctx.fillRect(q.x - p.size / 2, q.y - p.size / 2, p.size, p.size);
      ctx.globalAlpha = 1;
    }
  }
  // score popups
  ctx.textAlign = "center";
  for (const pop of e.popups) {
    const age = (e.clock - pop.born) / 1100;
    const q = P(v, pop.x, pop.h + age * 0.8, 0);
    ctx.globalAlpha = Math.max(0, 1 - age);
    ctx.font = `800 ${pop.big ? Math.max(18, v.h * 0.04) : Math.max(14, v.h * 0.028)}px ui-sans-serif, system-ui, sans-serif`;
    ctx.fillStyle = "rgba(0,0,0,0.6)";
    ctx.fillText(pop.text, q.x + 2, q.y + 2);
    ctx.fillStyle = pop.color;
    ctx.fillText(pop.text, q.x, q.y);
    ctx.globalAlpha = 1;
  }
  ctx.restore();

  // hit flash + vignette
  if (e.clock < e.flashUntil) {
    ctx.fillStyle = `rgba(255, 59, 92, ${0.25 * ((e.flashUntil - e.clock) / 220)})`;
    ctx.fillRect(0, 0, w, h);
  }
  const vg = ctx.createRadialGradient(w / 2, h / 2, Math.min(w, h) * 0.35, w / 2, h / 2, Math.max(w, h) * 0.75);
  vg.addColorStop(0, "rgba(0,0,0,0)");
  vg.addColorStop(1, "rgba(0,0,0,0.55)");
  ctx.fillStyle = vg;
  ctx.fillRect(0, 0, w, h);
}
