/**
 * Local stats (localStorage): only numbers — never images, video or landmarks.
 */
export interface Attempt {
  id: string;
  endedAt: number;
  result: "victory" | "gameOver" | "quit";
  score: number;
  timeMs: number;
  level: number;
  gestures: number;
  errors: number;
  successRate: number;
}

export interface StatsSnapshot {
  bestScore: number;
  /** Fastest completed mission (ms), null if none. */
  bestTimeMs: number | null;
  missionsCompleted: number;
  /** Lifetime gesture accuracy 0..100. */
  gestureAccuracy: number;
  totalRuns: number;
  recent: Attempt[];
}

const KEY = "neonheist.stats.v1";

interface Stored {
  bestScore: number;
  bestTimeMs: number | null;
  missionsCompleted: number;
  totalGestures: number;
  totalErrors: number;
  totalRuns: number;
  recent: Attempt[];
}

const EMPTY: Stored = { bestScore: 0, bestTimeMs: null, missionsCompleted: 0, totalGestures: 0, totalErrors: 0, totalRuns: 0, recent: [] };

function read(): Stored {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return { ...EMPTY };
    const p = JSON.parse(raw) as Partial<Stored>;
    return {
      bestScore: Number(p.bestScore) || 0,
      bestTimeMs: typeof p.bestTimeMs === "number" ? p.bestTimeMs : null,
      missionsCompleted: Number(p.missionsCompleted) || 0,
      totalGestures: Number(p.totalGestures) || 0,
      totalErrors: Number(p.totalErrors) || 0,
      totalRuns: Number(p.totalRuns) || 0,
      recent: Array.isArray(p.recent) ? p.recent.slice(0, 5) : [],
    };
  } catch {
    return { ...EMPTY };
  }
}

function snapshot(s: Stored): StatsSnapshot {
  const attempts = s.totalGestures + s.totalErrors;
  return {
    bestScore: s.bestScore,
    bestTimeMs: s.bestTimeMs,
    missionsCompleted: s.missionsCompleted,
    gestureAccuracy: attempts ? Math.round((s.totalGestures / attempts) * 100) : 0,
    totalRuns: s.totalRuns,
    recent: s.recent,
  };
}

export function loadStats(): StatsSnapshot {
  return snapshot(read());
}

export function saveAttempt(a: Omit<Attempt, "id">): StatsSnapshot {
  const s = read();
  const entry: Attempt = { ...a, id: `${a.endedAt}-${Math.random().toString(36).slice(2, 6)}` };
  const next: Stored = {
    bestScore: Math.max(s.bestScore, a.score),
    bestTimeMs: a.result === "victory" ? (s.bestTimeMs === null ? a.timeMs : Math.min(s.bestTimeMs, a.timeMs)) : s.bestTimeMs,
    missionsCompleted: s.missionsCompleted + (a.result === "victory" ? 1 : 0),
    totalGestures: s.totalGestures + a.gestures,
    totalErrors: s.totalErrors + a.errors,
    totalRuns: s.totalRuns + 1,
    recent: [entry, ...s.recent].slice(0, 5),
  };
  try {
    localStorage.setItem(KEY, JSON.stringify(next));
  } catch {
    /* storage unavailable — results still shown */
  }
  return snapshot(next);
}

export function formatTime(ms: number): string {
  const s = Math.round(ms / 1000);
  return `${String(Math.floor(s / 60)).padStart(2, "0")}:${String(s % 60).padStart(2, "0")}`;
}
