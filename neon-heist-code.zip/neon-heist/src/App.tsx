import { useCallback, useState } from "react";
import StartScreen from "./components/StartScreen";
import StatsScreen from "./components/StatsScreen";
import GameSession from "./components/GameSession";
import { loadStats, type StatsSnapshot } from "./storage/statsStorage";
import { soundManager } from "./audio/soundManager";

type Screen = "start" | "play" | "stats";

export default function App() {
  const [screen, setScreen] = useState<Screen>("start");
  const [stats, setStats] = useState<StatsSnapshot>(() => loadStats());
  const [runs, setRuns] = useState(0);
  const [highContrast, setHighContrast] = useState(false);

  const play = useCallback(() => {
    soundManager.unlock();
    setRuns((r) => r + 1);
    setScreen("play");
  }, []);

  return (
    <div className={highContrast ? "hc" : ""}>
      {screen === "start" && <StartScreen stats={stats} onStart={play} onStats={() => setScreen("stats")} />}
      {screen === "stats" && <StatsScreen stats={stats} onBack={() => setScreen("start")} onPlay={play} />}
      {screen === "play" && (
        <GameSession
          key={runs}
          skipTutorial={runs > 1}
          highContrast={highContrast}
          onToggleContrast={() => setHighContrast((h) => !h)}
          onExit={() => {
            setStats(loadStats());
            setScreen("start");
          }}
          onViewStats={() => {
            setStats(loadStats());
            setScreen("stats");
          }}
          onSaved={setStats}
        />
      )}
    </div>
  );
}
