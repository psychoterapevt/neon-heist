import { formatTime } from "../storage/statsStorage";
import StatTile from "./StatTile";
import { successRate, type RunSummary } from "./runSummary";

export default function VictoryScreen({ run, onPlayAgain, onStats }: { run: RunSummary; onPlayAgain: () => void; onStats: () => void }) {
  return (
    <div className="absolute inset-0 z-30 overflow-y-auto bg-black/80 p-4 backdrop-blur-sm">
      <div className="mx-auto flex min-h-full max-w-3xl animate-fade-up flex-col items-center justify-center py-8 text-center">
        <p className="font-mono text-xs font-bold tracking-[0.4em] text-emerald-300">DATA CORE EXTRACTED</p>
        <h2 className="text-glow mt-3 font-mono text-5xl font-black tracking-[0.08em] text-white sm:text-7xl">HEIST COMPLETE</h2>
        <dl className="mt-10 grid w-full grid-cols-2 gap-3 text-left sm:grid-cols-3">
          <StatTile k="Score" v={run.score.toLocaleString("en-US")} accent="text-neon-cyan" />
          <StatTile k="Time" v={formatTime(run.timeMs)} />
          <StatTile k="Gestures" v={run.stats.gestures} />
          <StatTile k="Success rate" v={`${successRate(run.stats)}%`} />
          <StatTile k="Errors corrected" v={run.stats.errorsCorrected} accent="text-warn" />
          <StatTile k="Levels" v={`${run.levelsDone} / 3`} accent="text-emerald-300" />
        </dl>
        <p className="mt-8 font-mono text-sm font-bold tracking-[0.25em] text-slate-300">&ldquo;YOUR BODY WAS THE CONTROLLER.&rdquo;</p>
        <div className="mt-8 flex flex-col gap-3 sm:flex-row">
          <button type="button" className="btn-neon" onClick={onPlayAgain}>
            Play again
          </button>
          <button type="button" className="btn-ghost" onClick={onStats}>
            View stats
          </button>
        </div>
      </div>
    </div>
  );
}
