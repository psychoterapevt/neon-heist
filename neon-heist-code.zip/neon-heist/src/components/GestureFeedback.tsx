/** Short "✓ JUMP" confirmation (or an info label such as "SHIELD RECHARGING"). */
export default function GestureFeedback({ label, applied, seq, confidence }: { label: string | null; applied: boolean; seq: number; confidence?: number }) {
  if (!label) return null;
  return (
    <div
      key={seq}
      role="status"
      aria-live="polite"
      className={`animate-pop-in rounded-xl border px-4 py-2 font-mono text-base font-bold tracking-[0.16em] sm:text-lg ${
        applied ? "border-emerald-400/60 bg-emerald-950/90 text-emerald-200" : "border-sky-300/40 bg-slate-950/90 text-sky-100"
      }`}
    >
      {label}
      {applied && confidence !== undefined && <span className="ml-2 text-xs text-emerald-300/80">{Math.round(confidence * 100)}%</span>}
    </div>
  );
}
