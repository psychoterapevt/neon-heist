import { useCallback, useEffect, useRef, useState } from "react";
import { useCamera } from "../hooks/useCamera";
import { useVision } from "../hooks/useVision";
import { useGestureController } from "../hooks/useGestureController";
import { useReducedMotion } from "../hooks/useReducedMotion";
import { ALL_ENABLED, type ControllerOutput } from "../gestures/gestureController";
import { GameEngine, triggerGameAction } from "../game/GameEngine";
import GameCanvas from "../game/GameCanvas";
import { renderOverlay } from "../vision/skeleton";
import { soundManager } from "../audio/soundManager";
import { saveAttempt, type StatsSnapshot } from "../storage/statsStorage";
import { POSE } from "../types/vision";
import type { ExpectedAction, GestureKind } from "../types/gesture";
import CameraPreview from "./CameraPreview";
import CameraSetup from "./CameraSetup";
import PermissionGate from "./PermissionGate";
import Tutorial, { TUTORIAL_STEPS } from "./Tutorial";
import HUD, { HintBanner, type HudState } from "./HUD";
import ErrorFeedback from "./ErrorFeedback";
import GestureFeedback from "./GestureFeedback";
import GameOver from "./GameOver";
import VictoryScreen from "./VictoryScreen";
import { successRate, type RunSummary } from "./runSummary";
import PrivacyBadge from "./PrivacyBadge";
import { CloseIcon, ContrastIcon, SoundOff, SoundOn } from "./icons";

type Step = "permission" | "setup" | "tutorial" | "game";

const EXPECTED_FOR: Record<GestureKind, ExpectedAction> = {
  MOVE_LEFT: "MOVE",
  MOVE_RIGHT: "MOVE",
  JUMP: "JUMP",
  HACK: "HACK",
  SHIELD: "SHIELD",
};
const NONE_ENABLED: Record<GestureKind, boolean> = { MOVE_LEFT: false, MOVE_RIGHT: false, JUMP: false, HACK: false, SHIELD: false };

function hudFrom(e: GameEngine): HudState {
  return {
    level: e.levelIndex + 1,
    levelName: e.level.name,
    objective: e.level.objective,
    hp: e.hp,
    maxHp: e.maxHp,
    score: e.score,
    combo: e.combo,
    progress: e.progress,
    hint: e.hint,
    difficulty: e.difficulty,
    shieldActive: e.player.shieldActive(e.clock),
    shieldReady: e.clock >= e.player.shieldReadyAt,
  };
}

export default function GameSession({
  skipTutorial,
  highContrast,
  onToggleContrast,
  onExit,
  onViewStats,
  onSaved,
}: {
  skipTutorial: boolean;
  highContrast: boolean;
  onToggleContrast: () => void;
  onExit: () => void;
  onViewStats: () => void;
  onSaved: (s: StatsSnapshot) => void;
}) {
  const cam = useCamera();
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const reduced = useReducedMotion();
  const [step, setStep] = useState<Step>("permission");
  const stepRef = useRef(step);
  stepRef.current = step;
  const [muted, setMuted] = useState(soundManager.muted);

  const engineRef = useRef<GameEngine | null>(null);
  if (!engineRef.current) engineRef.current = new GameEngine({ sound: (s) => soundManager.play(s), reducedMotion: reduced });
  const engine = engineRef.current;
  const [hud, setHud] = useState<HudState>(() => hudFrom(engine));
  const [gameState, setGameState] = useState(engine.state);
  const [run, setRun] = useState<RunSummary | null>(null);
  const [feedback, setFeedback] = useState<{ label: string; applied: boolean; seq: number; confidence?: number } | null>(null);
  const successUntil = useRef(0);
  const lastHud = useRef(0);
  const savedFor = useRef<string | null>(null);
  const nextTimer = useRef<number | null>(null);
  const lastCtx = useRef("");

  // tutorial
  const [tutIdx, setTutIdx] = useState(0);
  const tutIdxRef = useRef(0);
  const [tutDone, setTutDone] = useState<boolean[]>(TUTORIAL_STEPS.map(() => false));
  const tutLock = useRef(false);

  // setup
  const [goodSince, setGoodSince] = useState<number | null>(null);
  const [setupReady, setSetupReady] = useState(false);

  const showFeedback = useCallback((label: string, applied: boolean, confidence?: number) => {
    setFeedback((f) => ({ label, applied, confidence, seq: (f?.seq ?? 0) + 1 }));
  }, []);

  const onOutput = useCallback(
    (out: ControllerOutput) => {
      const st = stepRef.current;
      const canvas = canvasRef.current;
      const video = videoRef.current;
      const ctx = canvas?.getContext("2d");
      if (canvas && video && ctx) {
        renderOverlay(ctx, canvas.clientWidth, canvas.clientHeight, video.videoWidth, video.videoHeight, out.snapshot, {
          now: out.snapshot.t,
          successUntil: successUntil.current,
          reducedMotion: reduced,
          bodyDetail: "full",
        });
      }
      if (out.prompts.some((p) => p.severity !== "info") && (st === "tutorial" || st === "game")) soundManager.play("error");

      if (st === "tutorial") {
        const target = TUTORIAL_STEPS[tutIdxRef.current]?.g;
        for (const ev of out.events) {
          if (ev.gesture !== target || tutLock.current) continue;
          tutLock.current = true;
          successUntil.current = ev.t + 450;
          soundManager.play("success");
          showFeedback(`✓ ${TUTORIAL_STEPS[tutIdxRef.current].title}`, true, ev.confidence);
          const i = tutIdxRef.current;
          setTutDone((d) => d.map((v, j) => (j === i ? true : v)));
          window.setTimeout(() => {
            tutLock.current = false;
            if (i + 1 < TUTORIAL_STEPS.length) {
              tutIdxRef.current = i + 1;
              setTutIdx(i + 1);
            }
          }, 900);
        }
      } else if (st === "game") {
        const e = engineRef.current!;
        e.paused = out.snapshot.tracking !== "tracking" && (e.state === "running" || e.state === "intro");
        for (const f of out.failures) e.handleFailure(f, out.snapshot.t);
        for (const ev of out.events) {
          const r = triggerGameAction(e, ev);
          if (r.applied) successUntil.current = ev.t + 400;
          showFeedback(r.label, r.applied, r.applied ? ev.confidence : undefined);
        }
      }
    },
    [reduced, showFeedback],
  );

  const controller = useGestureController(onOutput);
  const snap = controller.snapshot;
  const setContext = controller.setContext;

  const vision = useVision(videoRef, step === "permission" ? null : cam.stream, {
    poseEvery: 2,
    onFrame: controller.process,
  });

  useEffect(() => {
    if (cam.status === "ready" && step === "permission") setStep("setup");
  }, [cam.status, step]);

  // controller context per step
  useEffect(() => {
    if (step === "setup" || step === "permission") setContext({ mode: "setup", expected: null, enabled: NONE_ENABLED });
    if (step === "tutorial") {
      const g = TUTORIAL_STEPS[tutIdx].g;
      setContext({ mode: "tutorial", expected: EXPECTED_FOR[g], enabled: { ...NONE_ENABLED, [g]: true } });
    }
    if (step === "game") {
      lastCtx.current = "";
      soundManager.startAmbience();
    }
    return () => {
      if (step === "game") soundManager.stopAmbience();
    };
  }, [step, tutIdx, setContext]);

  // game tick: keep the recognizer's context in sync with the level, publish HUD, handle state changes
  const onTick = useCallback(
    (now: number) => {
      const e = engineRef.current!;
      const running = e.state === "running";
      const key = `${running}|${e.expected}`;
      if (key !== lastCtx.current) {
        lastCtx.current = key;
        setContext({ mode: "game", expected: e.expected, enabled: running ? ALL_ENABLED : NONE_ENABLED });
      }
      if (now - lastHud.current > 100) {
        lastHud.current = now;
        setHud(hudFrom(e));
        setGameState(e.state);
      }
      if ((e.state === "gameOver" || e.state === "victory") && savedFor.current !== `${e.state}-${e.stateSince}`) {
        savedFor.current = `${e.state}-${e.stateSince}`;
        const summary: RunSummary = {
          score: e.score,
          timeMs: e.activeMs,
          level: e.levelIndex + 1,
          levelsDone: e.state === "victory" ? 3 : e.levelIndex,
          stats: { ...e.stats },
        };
        setRun(summary);
        setGameState(e.state);
        onSaved(
          saveAttempt({
            endedAt: Date.now(),
            result: e.state === "victory" ? "victory" : "gameOver",
            score: summary.score,
            timeMs: summary.timeMs,
            level: summary.level,
            gestures: summary.stats.gestures,
            errors: summary.stats.failedAttempts,
            successRate: successRate(summary.stats),
          }),
        );
      }
      if (e.state === "levelComplete" && nextTimer.current === null) {
        nextTimer.current = window.setTimeout(() => {
          nextTimer.current = null;
          engineRef.current!.nextLevel();
        }, 3200);
      }
    },
    [onSaved, setContext],
  );

  // setup: GOOD POSITION (with headroom for jumping) held → READY → tutorial
  const pose = snap?.pose ?? null;
  let headroom = false;
  if (pose) {
    const le = pose[POSE.LEFT_EYE];
    const ls = pose[POSE.LEFT_SHOULDER];
    const rs = pose[POSE.RIGHT_SHOULDER];
    const sw = Math.abs((ls?.x ?? 0) - (rs?.x ?? 0));
    headroom = !!le && le.y - 0.75 * sw > 0.0;
  }
  const good = vision.status === "ready" && snap?.position?.status === "GOOD_POSITION" && headroom;
  const nowT = snap?.t ?? 0;
  useEffect(() => {
    if (step !== "setup") return;
    if (good) setGoodSince((g) => g ?? nowT);
    else if (!setupReady) setGoodSince(null);
  }, [good, nowT, step, setupReady]);
  useEffect(() => {
    if (step === "setup" && !setupReady && goodSince !== null && nowT - goodSince > 1000) {
      setSetupReady(true);
      soundManager.play("success");
    }
  }, [goodSince, nowT, step, setupReady]);
  const afterSetup = useCallback(() => setStep(skipTutorial ? "game" : "tutorial"), [skipTutorial]);
  useEffect(() => {
    if (!setupReady || step !== "setup") return;
    const id = window.setTimeout(afterSetup, 1200);
    return () => window.clearTimeout(id);
  }, [setupReady, step, afterSetup]);

  useEffect(() => {
    if (!feedback) return;
    const id = window.setTimeout(() => setFeedback(null), 900);
    return () => window.clearTimeout(id);
  }, [feedback]);

  useEffect(
    () => () => {
      if (nextTimer.current !== null) window.clearTimeout(nextTimer.current);
      soundManager.stopAmbience();
    },
    [],
  );

  const exit = () => {
    cam.stop();
    onExit();
  };

  if (step === "permission" || cam.status === "error" || vision.status === "error") {
    return <PermissionGate status={cam.status} cameraError={cam.error} visionError={vision.error} onAllow={() => void cam.start()} onBack={exit} />;
  }

  const inGame = step === "game";
  const controls = (
    <div className={`flex gap-2 ${inGame ? "absolute right-3 top-[100px] z-20 flex-col sm:right-5 sm:top-[222px] sm:flex-row" : ""}`}>
      <button type="button" className="icon-btn" aria-label={muted ? "Unmute" : "Mute"} aria-pressed={muted} onClick={() => { soundManager.setMuted(!muted); setMuted(!muted); }}>
        {muted ? <SoundOff /> : <SoundOn />}
      </button>
      <button type="button" className="icon-btn" aria-label="High contrast" aria-pressed={highContrast} onClick={onToggleContrast}>
        <ContrastIcon />
      </button>
      <button type="button" className="icon-btn" aria-label="Exit to menu" onClick={exit}>
        <CloseIcon />
      </button>
    </div>
  );

  return (
    <div className={inGame ? "relative h-[100dvh] overflow-hidden bg-void-950" : "mx-auto grid min-h-[100dvh] max-w-[1400px] content-start gap-4 p-4 sm:p-6 lg:grid-cols-[minmax(0,1fr)_420px] lg:gap-6"}>
      {inGame && (
        <div className="absolute inset-0">
          <GameCanvas engine={engine} onTick={onTick} />
          <HUD s={hud} />
          <div className="pointer-events-none absolute inset-x-0 bottom-0 z-10 flex flex-col items-center gap-2 p-3 pb-[max(12px,env(safe-area-inset-bottom))] sm:p-5">
            <div className="flex min-h-[48px] flex-col items-center gap-2">
              <ErrorFeedback error={snap?.error ?? null} seq={snap?.errorSeq ?? 0} ready={snap?.ready ?? false} />
              <GestureFeedback label={feedback?.label ?? null} applied={feedback?.applied ?? false} seq={feedback?.seq ?? 0} confidence={feedback?.confidence} />
            </div>
            <HintBanner hint={hud.hint} shieldActive={hud.shieldActive} shieldReady={hud.shieldReady} />
          </div>
          {gameState === "intro" && !engine.paused && (
            <div className="pointer-events-none absolute inset-0 z-20 grid place-items-center">
              <div key={hud.level} className="animate-fade-up text-center">
                <div className="font-mono text-sm font-bold tracking-[0.5em] text-neon-pink">LEVEL {hud.level}</div>
                <div className="text-glow mt-2 font-mono text-5xl font-black tracking-[0.12em] text-white sm:text-7xl">{hud.levelName}</div>
                <div className="mt-4 font-mono text-sm tracking-[0.2em] text-slate-300">OBJECTIVE · {hud.objective.toUpperCase()}</div>
              </div>
            </div>
          )}
          {gameState === "levelComplete" && (
            <div className="pointer-events-none absolute inset-0 z-20 grid place-items-center bg-black/40">
              <div className="animate-fade-up text-center">
                <div className="font-mono text-sm font-bold tracking-[0.5em] text-emerald-300">DOOR UNLOCKED</div>
                <div className="text-glow mt-2 font-mono text-5xl font-black tracking-[0.1em] text-white sm:text-6xl">LEVEL COMPLETE</div>
                <div className="mt-4 font-mono text-lg text-slate-200">SCORE {hud.score.toLocaleString("en-US")}</div>
                <div className="mt-2 font-mono text-xs tracking-[0.3em] text-slate-400">NEXT LEVEL INCOMING…</div>
              </div>
            </div>
          )}
          {snap && snap.tracking !== "tracking" && (gameState === "running" || gameState === "intro") && (
            <div className="absolute inset-0 z-20 grid place-items-center bg-black/60 p-4" role="alert">
              <div className="panel max-w-md border-danger/50 p-6 text-center">
                <div className="animate-blink font-mono text-2xl font-black tracking-[0.2em] text-danger">
                  {snap.tracking === "multiple" ? "⚠ TOO MANY PLAYERS" : "⚠ TRACKING LOST"}
                </div>
                <p className="mt-2 text-slate-200">
                  {snap.tracking === "multiple" ? "Only one player should be visible." : "Step back into view — upper body and hands. The game is paused."}
                </p>
              </div>
            </div>
          )}
          {gameState === "gameOver" && run && (
            <GameOver
              run={run}
              onRetry={() => {
                engine.restartLevel();
                setRun(null);
              }}
              onMenu={exit}
            />
          )}
          {gameState === "victory" && run && (
            <VictoryScreen
              run={run}
              onPlayAgain={() => {
                engine.resetRun();
                setRun(null);
              }}
              onStats={() => {
                cam.stop();
                onViewStats();
              }}
            />
          )}
        </div>
      )}

      <div
        className={
          inGame
            ? "absolute right-3 top-3 z-20 h-[84px] w-[112px] sm:right-5 sm:top-5 sm:h-[195px] sm:w-[260px]"
            : "relative aspect-[4/3] w-full sm:aspect-video lg:max-h-[calc(100dvh-48px)]"
        }
      >
        <CameraPreview
          stream={cam.stream}
          videoRef={videoRef}
          canvasRef={canvasRef}
          tracking={vision.status === "ready" ? (snap?.tracking ?? null) : null}
          compact={inGame}
          className="absolute inset-0"
        >
          {!inGame && vision.status !== "ready" && (
            <div className="absolute inset-0 grid place-items-center bg-black/60 font-mono text-sm tracking-widest text-slate-200">LOADING TRACKING MODELS…</div>
          )}
          {!inGame && step === "tutorial" && (
            <div className="absolute inset-x-3 bottom-3 flex justify-center">
              <GestureFeedback label={feedback?.label ?? null} applied={feedback?.applied ?? false} seq={feedback?.seq ?? 0} confidence={feedback?.confidence} />
            </div>
          )}
        </CameraPreview>
      </div>

      {inGame ? (
        controls
      ) : (
        <aside className="space-y-4">
          <div className="flex items-center justify-between">
            <PrivacyBadge short />
            {controls}
          </div>
          {step === "setup" && (
            <CameraSetup
              position={snap?.position ?? null}
              handsVisible={!!snap?.hand}
              headroom={headroom}
              visionReady={vision.status === "ready"}
              stage={vision.stage}
              ready={setupReady}
              readyProgress={goodSince !== null ? Math.min(1, (nowT - goodSince) / 1000) : 0}
              onContinue={afterSetup}
            />
          )}
          {step === "tutorial" && (
            <Tutorial
              index={tutIdx}
              done={tutDone}
              error={snap?.error ?? null}
              errorSeq={snap?.errorSeq ?? 0}
              ready={snap?.ready ?? false}
              onStart={() => setStep("game")}
              onSkip={() => setStep("game")}
            />
          )}
        </aside>
      )}
    </div>
  );
}
