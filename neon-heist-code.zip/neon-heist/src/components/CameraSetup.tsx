import type { PositionCheck, PositionStatus } from "../vision/poseMetrics";
import type { VisionStage } from "../hooks/useVision";

const STATUS: Record<PositionStatus, { label: string; hint: string; tone: "ok" | "warn" | "bad" }> = {
  GOOD_POSITION: { label: "READY", hint: "Hold still…", tone: "ok" },
  NO_PERSON: { label: "STEP INTO VIEW", hint: "Stand in front of the camera.", tone: "warn" },
  MULTIPLE_PEOPLE: { label: "ONE PLAYER ONLY", hint: "Only one player should be visible.", tone: "bad" },
  MOVE_BACK: { label: "MOVE BACK", hint: "Step back so your upper body and raised hands fit.", tone: "warn" },
  MOVE_CLOSER: { label: "MOVE CLOSER", hint: "You're too far away.", tone: "warn" },
  SHOW_FACE: { label: "SHOW YOUR FACE", hint: "Face the camera.", tone: "warn" },
  SHOW_SHOULDERS: { label: "SHOW YOUR SHOULDERS", hint: "Both shoulders must be visible.", tone: "warn" },
  SHOW_YOUR_HAND: { label: "SHOW YOUR HANDS", hint: "Raise a hand to chest level.", tone: "warn" },
  LOW_LIGHT: { label: "MORE LIGHT", hint: "It's too dark — face a light source.", tone: "warn" },
};

const TONE = {
  ok: "border-emerald-400/50 bg-emerald-400/10 text-emerald-200",
  warn: "border-warn/50 bg-warn/10 text-amber-100",
  bad: "border-danger/50 bg-danger/10 text-red-100",
};

export default function CameraSetup({
  position,
  handsVisible,
  headroom,
  visionReady,
  stage,
  ready,
  readyProgress,
  onContinue,
}: {
  position: PositionCheck | null;
  handsVisible: boolean;
  /** true when there is room above the head for a jump. */
  headroom: boolean;
  visionReady: boolean;
  stage: VisionStage;
  ready: boolean;
  readyProgress: number;
  onContinue: () => void;
}) {
  let status: PositionStatus = position?.status ?? "NO_PERSON";
  if (status === "GOOD_POSITION" && !headroom) status = "MOVE_BACK";
  const info = STATUS[status];
  const checks: Array<[string, boolean]> = [
    ["Face", !!position?.checks.face],
    ["Shoulders", !!position?.checks.shoulders],
    ["Hands", handsVisible],
    ["Room to jump", headroom],
    ["One player", position?.checks.singlePerson ?? true],
    ["Light", position?.checks.light ?? true],
  ];
  return (
    <div className="panel space-y-5 p-5 sm:p-6">
      <div>
        <p className="hud-label">Camera setup</p>
        <h2 className="mt-2 text-xl font-semibold leading-snug">Stand where your upper body and hands are visible.</h2>
      </div>
      <div role="status" aria-live="polite">
        {!visionReady ? (
          <div className="rounded-xl border border-white/10 px-4 py-3 font-mono text-sm tracking-wider text-slate-300">
            <span className="mr-2 inline-block h-2 w-2 animate-blink rounded-full bg-neon-cyan" />
            {stage === "pose-model" ? "LOADING BODY TRACKING…" : "LOADING HAND TRACKING…"}
          </div>
        ) : ready ? (
          <div className={`rounded-xl border px-4 py-3 ${TONE.ok}`}>
            <div className="font-mono text-2xl font-black tracking-[0.2em]">READY</div>
            <div className="text-sm opacity-80">Starting training…</div>
          </div>
        ) : (
          <div className={`rounded-xl border px-4 py-3 ${TONE[info.tone]}`}>
            <div className="font-mono text-2xl font-black tracking-[0.16em]">{info.label}</div>
            <div className="text-sm opacity-85">{info.hint}</div>
            {status === "GOOD_POSITION" && (
              <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-black/30">
                <div className="h-full bg-emerald-400" style={{ width: `${readyProgress * 100}%` }} />
              </div>
            )}
          </div>
        )}
      </div>
      <ul className="grid grid-cols-2 gap-2 font-mono text-xs font-semibold uppercase tracking-wider sm:grid-cols-3">
        {checks.map(([k, ok]) => (
          <li key={k} className={`rounded-lg border px-2.5 py-2 ${ok ? "border-emerald-400/30 text-emerald-200" : "border-white/10 text-slate-500"}`}>
            {ok ? "✓" : "·"} {k}
          </li>
        ))}
      </ul>
      <button type="button" onClick={onContinue} disabled={!visionReady} className="btn-ghost w-full">
        {ready ? "Continue" : "Skip check"}
      </button>
    </div>
  );
}
