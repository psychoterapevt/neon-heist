import type { Hint } from "../game/types";

export interface HudState {
  level: number;
  levelName: string;
  objective: string;
  hp: number;
  maxHp: number;
  score: number;
  combo: number;
  progress: number;
  hint: Hint | null;
  difficulty: number;
  shieldActive: boolean;
  shieldReady: boolean;
}

function Hearts({ hp, max }: { hp: number; max: number }) {
  return (
    <div className="flex gap-1" role="img" aria-label={`${hp} of ${max} HP`}>
      {Array.from({ length: max }, (_, i) => (
        <svg key={i} viewBox="0 0 24 24" className={`h-6 w-6 sm:h-7 sm:w-7 ${i < hp ? "text-danger drop-shadow-[0_0_6px_rgba(255,59,92,0.7)]" : "text-slate-700"}`} aria-hidden="true">
          <path fill="currentColor" d="M12 21s-7.5-4.6-9.6-9.2C.9 8.4 3 4.5 6.8 4.5c2.1 0 3.6 1.2 5.2 3 1.6-1.8 3.1-3 5.2-3 3.8 0 5.9 3.9 4.4 7.3C19.5 16.4 12 21 12 21Z" />
        </svg>
      ))}
    </div>
  );
}

/** Top HUD: level (left), objective + progress (center), HP / score / combo (right of it). */
export default function HUD({ s }: { s: HudState }) {
  return (
    <div className="pointer-events-none absolute inset-x-0 top-0 z-10 flex flex-wrap items-start gap-2 p-3 pr-[132px] md:flex-nowrap sm:gap-5 sm:p-5 sm:pr-[300px]">
      <div className="panel shrink-0 px-3 py-1.5 sm:px-4 sm:py-2">
        <div className="hud-label">Level {s.level}</div>
        <div className="font-mono text-base font-bold tracking-[0.14em] text-neon-cyan sm:text-xl">{s.levelName}</div>
      </div>
      <div className="hidden min-w-0 flex-1 flex-col items-center md:flex">
        <div className="panel max-w-md px-4 py-2 text-center">
          <div className="hud-label">Objective</div>
          <div className="truncate text-sm font-semibold text-slate-100">{s.objective}</div>
          <div className="mt-1.5 h-1 w-56 overflow-hidden rounded-full bg-white/10">
            <div className="h-full rounded-full bg-neon-cyan" style={{ width: `${Math.round(s.progress * 100)}%` }} />
          </div>
        </div>
      </div>
      <div className="panel ml-auto flex shrink-0 items-center gap-3 px-3 py-2 sm:gap-5 sm:px-4 md:ml-0">
        <Hearts hp={s.hp} max={s.maxHp} />
        <div>
          <div className="hud-label">Score</div>
          <div className="font-mono text-lg font-bold tabular-nums text-white sm:text-2xl">{s.score.toLocaleString("en-US")}</div>
        </div>
        {s.combo > 1 && (
          <div key={s.combo} className="animate-pop-in rounded-lg bg-neon-violet/20 px-2 py-1 font-mono text-sm font-extrabold text-neon-violet">
            COMBO x{s.combo}
          </div>
        )}
      </div>
    </div>
  );
}

/** Bottom hint banner: what to do next (context from the level). */
export function HintBanner({ hint, shieldActive, shieldReady }: { hint: Hint | null; shieldActive: boolean; shieldReady: boolean }) {
  return (
    <div className="flex flex-wrap items-center justify-center gap-2">
      {hint && (
        <div
          data-expected={hint.expected ?? ""}
          data-urgent={hint.urgent ? "1" : "0"}
          data-direction={hint.direction ?? ""}
          className={`rounded-xl border px-4 py-2 font-mono text-sm font-bold tracking-[0.14em] sm:text-base ${
            hint.urgent ? "animate-blink border-danger/60 bg-danger/20 text-white" : "border-white/15 bg-void-950/80 text-slate-100"
          }`}
        >
          <span className="text-slate-400">{hint.label} · </span>
          {hint.action}
        </div>
      )}
      <div className={`rounded-xl border px-3 py-2 font-mono text-xs font-bold tracking-widest ${shieldActive ? "border-neon-cyan/60 bg-neon-cyan/20 text-neon-cyan" : shieldReady ? "border-white/10 bg-void-950/70 text-slate-400" : "border-white/10 bg-void-950/70 text-slate-600"}`}>
        {shieldActive ? "SHIELD ACTIVE" : shieldReady ? "SHIELD READY" : "SHIELD RECHARGING"}
      </div>
    </div>
  );
}
