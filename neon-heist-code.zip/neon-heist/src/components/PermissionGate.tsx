import type { CameraError, CameraStatus } from "../hooks/useCamera";
import PrivacyBadge from "./PrivacyBadge";
import { Logo } from "./icons";

/** Explains the camera BEFORE the browser prompt; handles denied / missing camera. */
export default function PermissionGate({
  status,
  cameraError,
  visionError,
  onAllow,
  onBack,
}: {
  status: CameraStatus;
  cameraError: CameraError | null;
  visionError: string | null;
  onAllow: () => void;
  onBack: () => void;
}) {
  const failed = status === "error" || !!visionError;
  return (
    <div className="grid min-h-[100dvh] place-items-center px-5 py-10">
      <div className="panel w-full max-w-lg animate-fade-up p-7 sm:p-9">
        <div className="flex items-center justify-between">
          <Logo width={34} height={34} />
          <PrivacyBadge short />
        </div>
        <h1 className="mt-6 font-mono text-2xl font-black tracking-[0.08em] text-white">
          {visionError ? "TRACKING COULD NOT START" : cameraError?.title.toUpperCase() ?? "CAMERA REQUIRED"}
        </h1>
        {failed ? (
          <p className="mt-3 leading-relaxed text-slate-300" role="alert">
            {visionError ?? cameraError?.message}
          </p>
        ) : (
          <>
            <p className="mt-3 leading-relaxed text-slate-300">
              NEON HEIST reads your body movements through the webcam. Your browser will ask for camera access.
            </p>
            <ul className="mt-5 space-y-2 text-sm text-slate-300">
              <li>🔒 Camera processing happens locally in your browser.</li>
              <li>🎥 Nothing is recorded, stored or uploaded.</li>
              <li>🧍 Stand ~1.5–2 m away so your raised hands are visible.</li>
            </ul>
          </>
        )}
        <div className="mt-8 flex flex-col gap-3 sm:flex-row">
          {visionError ? (
            <button type="button" className="btn-neon flex-1" onClick={() => window.location.reload()}>
              Reload
            </button>
          ) : (
            <button type="button" className="btn-neon flex-1" onClick={onAllow} disabled={status === "requesting"}>
              {status === "requesting" ? "Waiting…" : failed ? "Try again" : "Allow camera"}
            </button>
          )}
          <button type="button" className="btn-ghost" onClick={onBack}>
            Back
          </button>
        </div>
      </div>
    </div>
  );
}
