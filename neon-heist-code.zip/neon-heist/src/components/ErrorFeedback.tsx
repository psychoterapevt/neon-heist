import type { GestureError } from "../types/gesture";
import { CheckIcon } from "./icons";

/** Small pictogram that explains the error without words. */
function ErrorDiagram({ error }: { error: GestureError }) {
  const v = error.visual;
  const stroke = "#fbbf24";
  if (v?.kind === "trajectory") {
    const p = Math.max(0.05, Math.min(1, error.progress ?? 0.5));
    const flip = error.direction === "left";
    return (
      <svg viewBox="0 0 160 46" className="h-11 w-40" aria-hidden="true" style={{ transform: flip ? "scaleX(-1)" : undefined }}>
        <line x1="14" y1="24" x2="138" y2="24" stroke={stroke} strokeWidth="2.5" strokeDasharray="6 5" />
        <path d="M138 16 l12 8 -12 8 z" fill={stroke} />
        <line x1="14" y1="24" x2={14 + 124 * p} y2="24" stroke="#ff3b5c" strokeWidth="6" strokeLinecap="round" />
        <circle cx="14" cy="24" r="6" fill="#f8fafc" />
        <text x="10" y="9" fill="#cbd5e1" fontSize="9" fontFamily="ui-monospace,monospace" style={{ transform: flip ? "scaleX(-1)" : undefined, transformOrigin: "14px 9px" }}>
          HAND
        </text>
        <text x="80" y="43" fill={stroke} fontSize="8.5" fontFamily="ui-monospace,monospace" textAnchor="middle" style={{ transform: flip ? "scaleX(-1)" : undefined, transformOrigin: "80px 43px" }}>
          MINIMUM DISTANCE
        </text>
      </svg>
    );
  }
  if (v?.kind === "jump") {
    const both = error.type !== "ONE_HAND_TOO_LOW";
    return (
      <svg viewBox="0 0 90 60" className="h-14 w-24" aria-hidden="true">
        <line x1="4" y1="14" x2="86" y2="14" stroke={stroke} strokeWidth="2" strokeDasharray="5 4" />
        <circle cx="45" cy="28" r="6" fill="none" stroke="#e2e8f0" strokeWidth="2.5" />
        <path d="M36 58c0-10 4-16 9-16s9 6 9 16" fill="none" stroke="#e2e8f0" strokeWidth="2.5" />
        <path d={both ? "M37 44 L28 26" : "M37 44 L26 16"} stroke={both ? "#ff3b5c" : "#34d399"} strokeWidth="3" strokeLinecap="round" />
        <path d="M53 44 L62 26" stroke="#ff3b5c" strokeWidth="3" strokeLinecap="round" />
        {both && <path d="M22 20 l6 -8 6 8" fill="none" stroke={stroke} strokeWidth="2.5" />}
        <path d="M56 20 l6 -8 6 8" fill="none" stroke={stroke} strokeWidth="2.5" />
      </svg>
    );
  }
  if (v?.kind === "pinch-gap") {
    return (
      <svg viewBox="0 0 90 50" className="h-12 w-24" aria-hidden="true">
        <circle cx="22" cy="25" r="7" fill="#e2e8f0" />
        <circle cx="68" cy="25" r="7" fill="#e2e8f0" />
        <path d="M34 25h10M56 25h-10" stroke={stroke} strokeWidth="3" strokeLinecap="round" />
        <path d="M40 19l6 6-6 6M50 19l-6 6 6 6" fill="none" stroke={stroke} strokeWidth="2.5" />
        <text x="22" y="46" textAnchor="middle" fill="#94a3b8" fontSize="8" fontFamily="ui-monospace,monospace">THUMB</text>
        <text x="68" y="46" textAnchor="middle" fill="#94a3b8" fontSize="8" fontFamily="ui-monospace,monospace">INDEX</text>
      </svg>
    );
  }
  if (v?.kind === "arrow") {
    const rot = { up: -90, down: 90, left: 180, right: 0, center: 0 }[v.direction];
    return (
      <svg viewBox="0 0 60 60" className="h-12 w-12" aria-hidden="true">
        <g transform={`rotate(${rot} 30 30)`}>
          <path d="M10 30h34M34 18l12 12-12 12" fill="none" stroke={stroke} strokeWidth="5" strokeLinecap="round" strokeLinejoin="round" />
        </g>
      </svg>
    );
  }
  // open hand / turn palm
  return (
    <svg viewBox="0 0 48 48" className="h-12 w-12" aria-hidden="true" fill="none" stroke={stroke} strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round">
      <path d="M17 24V11.5a2.5 2.5 0 0 1 5 0V22M22 21V8.5a2.5 2.5 0 0 1 5 0V22M27 21.5V10.5a2.5 2.5 0 0 1 5 0V24M32 24v-7a2.5 2.5 0 0 1 5 0v11c0 8-5 14-12 14-5.5 0-8.5-2.5-11-7l-4.3-7.6a2.4 2.4 0 0 1 4-2.6L17 29" />
    </svg>
  );
}

/**
 * ERROR MODE card: one prioritized instruction + diagram. "✓ READY" once fixed.
 */
export default function ErrorFeedback({
  error,
  seq,
  ready,
  compact = false,
}: {
  error: GestureError | null;
  seq: number;
  ready: boolean;
  compact?: boolean;
}) {
  if (!error) {
    return (
      <div role="status" aria-live="polite">
        {ready && (
          <div className="flex animate-pop-in items-center gap-2 rounded-xl border border-emerald-400/40 bg-emerald-400/15 px-3 py-2 font-mono text-sm font-bold tracking-widest text-emerald-200">
            <CheckIcon width={16} height={16} /> READY
          </div>
        )}
      </div>
    );
  }
  const hard = error.severity === "error";
  return (
    <div role="status" aria-live="assertive">
      <div
        key={seq}
        className={`flex animate-pop-in items-center gap-3 rounded-xl border px-3 py-2.5 ${
          hard ? "border-danger/60 bg-danger/15" : "border-warn/50 bg-void-950/85"
        } ${compact ? "" : "sm:gap-4 sm:px-4 sm:py-3"}`}
      >
        {!compact && (
          <div className="hidden shrink-0 sm:block">
            <ErrorDiagram error={error} />
          </div>
        )}
        <div className="min-w-0">
          <div className={`font-mono text-[11px] font-bold tracking-[0.2em] ${hard ? "text-danger" : "text-warn"}`}>⚠ {error.title}</div>
          <div className={`font-semibold leading-snug text-white ${compact ? "text-sm" : "text-base sm:text-lg"}`}>{error.message}</div>
        </div>
      </div>
    </div>
  );
}
