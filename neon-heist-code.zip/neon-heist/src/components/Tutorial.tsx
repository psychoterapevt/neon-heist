import type { GestureError, GestureKind } from "../types/gesture";
import ErrorFeedback from "./ErrorFeedback";
import { CheckIcon, GestureGlyph } from "./icons";

export const TUTORIAL_STEPS: Array<{ g: GestureKind; title: string; arrow: string; how: string }> = [
  { g: "MOVE_LEFT", title: "MOVE LEFT", arrow: "←", how: "Sweep your hand quickly to the left." },
  { g: "MOVE_RIGHT", title: "MOVE RIGHT", arrow: "→", how: "Sweep your hand quickly to the right." },
  { g: "JUMP", title: "JUMP", arrow: "↑", how: "Raise BOTH hands above your head." },
  { g: "HACK", title: "HACK", arrow: "🤏", how: "Pinch: touch thumb and index fingertips." },
  { g: "SHIELD", title: "SHIELD", arrow: "✋", how: "Show an open palm to the camera." },
];

export default function Tutorial({
  index,
  done,
  error,
  errorSeq,
  ready,
  onStart,
  onSkip,
}: {
  index: number;
  done: boolean[];
  error: GestureError | null;
  errorSeq: number;
  ready: boolean;
  onStart: () => void;
  onSkip: () => void;
}) {
  const finished = done.every(Boolean);
  const step = TUTORIAL_STEPS[Math.min(index, TUTORIAL_STEPS.length - 1)];
  const current = done[index];
  return (
    <div className="panel space-y-5 p-5 sm:p-6">
      <div>
        <p className="hud-label">Training · try every gesture</p>
        <ol className="mt-3 grid grid-cols-5 gap-1.5" aria-label="Gestures to practise">
          {TUTORIAL_STEPS.map((s, i) => (
            <li
              key={s.g}
              aria-current={i === index && !finished ? "step" : undefined}
              className={`rounded-lg border px-1 py-2 text-center font-mono text-[10px] font-bold leading-tight tracking-wider ${
                done[i] ? "border-emerald-400/40 bg-emerald-400/10 text-emerald-200" : i === index ? "border-neon-cyan/60 bg-neon-cyan/10 text-white" : "border-white/10 text-slate-500"
              }`}
            >
              <div className="text-base">{done[i] ? "✓" : s.arrow}</div>
              {s.title}
            </li>
          ))}
        </ol>
      </div>

      {finished ? (
        <div className="animate-fade-up space-y-4 text-center">
          <div className="font-mono text-3xl font-black tracking-[0.12em] text-emerald-300">You&apos;re ready.</div>
          <p className="text-slate-300">All five gestures recognised.</p>
          <button type="button" className="btn-neon w-full" onClick={onStart}>
            Start mission
          </button>
        </div>
      ) : (
        <>
          <div className={`flex items-center gap-4 rounded-xl border p-4 ${current ? "border-emerald-400/50 bg-emerald-400/10" : "border-white/10 bg-black/30"}`}>
            <div className="grid h-20 w-20 shrink-0 place-items-center rounded-xl bg-black/40">
              <GestureGlyph g={step.g} className={`h-12 w-12 ${current ? "text-emerald-300" : "animate-float text-neon-cyan"}`} />
            </div>
            <div role="status" aria-live="polite">
              {current ? (
                <div className="flex items-center gap-2 font-mono text-2xl font-black tracking-widest text-emerald-300">
                  <CheckIcon width={24} height={24} /> READY
                </div>
              ) : (
                <>
                  <div className="hud-label">Try</div>
                  <div className="font-mono text-2xl font-black tracking-[0.12em] text-white">
                    {step.title} <span className="text-neon-cyan">{step.arrow}</span>
                  </div>
                  <div className="mt-1 text-sm text-slate-300">{step.how}</div>
                </>
              )}
            </div>
          </div>
          <div className="min-h-[64px]">
            <ErrorFeedback error={error} seq={errorSeq} ready={ready && !current} />
          </div>
        </>
      )}
      <button type="button" onClick={onSkip} className="w-full text-center font-mono text-xs tracking-widest text-slate-500 hover:text-slate-300">
        SKIP TRAINING
      </button>
    </div>
  );
}
