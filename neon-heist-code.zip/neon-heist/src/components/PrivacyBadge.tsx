import { LockIcon } from "./icons";

export default function PrivacyBadge({ className = "", short = false }: { className?: string; short?: boolean }) {
  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full border border-emerald-400/30 bg-emerald-400/10 px-2.5 py-1 font-mono text-[11px] font-semibold uppercase tracking-wider text-emerald-200 ${className}`}
      title="Camera processing happens locally in your browser. No video is uploaded or stored."
    >
      <LockIcon width={12} height={12} strokeWidth={2.4} />
      {short ? "Local" : "Camera processing happens locally"}
    </span>
  );
}
