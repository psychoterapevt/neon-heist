import PrivacyBadge from "./PrivacyBadge";
import { GestureGlyph, Logo } from "./icons";
import type { StatsSnapshot } from "../storage/statsStorage";

const GESTURES = [
  { g: "MOVE_LEFT" as const, name: "Move left", how: "Sweep your hand left" },
  { g: "MOVE_RIGHT" as const, name: "Move right", how: "Sweep your hand right" },
  { g: "JUMP" as const, name: "Jump", how: "Both hands above your head" },
  { g: "HACK" as const, name: "Hack", how: "Pinch thumb + index" },
  { g: "SHIELD" as const, name: "Shield", how: "Open palm to the camera" },
];

export default function StartScreen({ onStart, onStats, stats }: { onStart: () => void; onStats: () => void; stats: StatsSnapshot }) {
  return (
    <div className="relative min-h-[100dvh] overflow-hidden">
      <div className="grid-floor pointer-events-none absolute inset-0" aria-hidden="true" />
      <div className="pointer-events-none absolute left-1/2 top-1/3 h-[420px] w-[820px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-neon-cyan/10 blur-[110px]" aria-hidden="true" />
      <header className="relative z-10 mx-auto flex max-w-6xl items-center justify-between px-5 py-5">
        <div className="flex items-center gap-2">
          <Logo width={30} height={30} />
          <span className="font-mono text-sm font-bold tracking-[0.3em] text-slate-300">NEON HEIST</span>
        </div>
        <PrivacyBadge className="hidden sm:inline-flex" />
      </header>

      <main className="relative z-10 mx-auto flex max-w-6xl flex-col items-center px-5 pb-16 pt-6 text-center sm:pt-12">
        <p className="font-mono text-xs font-bold tracking-[0.4em] text-neon-pink">A MOTION-CONTROLLED HEIST</p>
        <h1 className="text-glow mt-4 font-mono text-5xl font-black tracking-[0.12em] text-white sm:text-7xl lg:text-8xl">
          NEON <span className="text-neon-cyan">HEIST</span>
        </h1>
        <p className="mt-4 font-mono text-sm font-bold tracking-[0.35em] text-slate-300 sm:text-base">YOUR BODY IS THE CONTROLLER</p>
        <p className="mt-8 max-w-md whitespace-pre-line text-lg leading-relaxed text-slate-300">
          {"Break into the facility.\nAvoid the security system.\nSteal the Core."}
        </p>

        <div className="mt-10 flex flex-col items-center gap-3 sm:flex-row">
          <button type="button" className="btn-neon h-14 px-10 text-base" onClick={onStart}>
            Start heist
          </button>
          {stats.totalRuns > 0 && (
            <button type="button" className="btn-ghost" onClick={onStats}>
              Stats · best {stats.bestScore.toLocaleString("en-US")}
            </button>
          )}
        </div>

        <div className="mt-6 flex flex-wrap justify-center gap-x-6 gap-y-2 font-mono text-xs font-bold tracking-[0.2em] text-slate-400">
          <span>5 GESTURES</span>
          <span className="text-slate-600">/</span>
          <span>NO KEYBOARD</span>
          <span className="text-slate-600">/</span>
          <span>NO MOUSE</span>
        </div>

        <ul className="mt-12 grid w-full max-w-4xl grid-cols-2 gap-3 sm:grid-cols-5" aria-label="Gestures">
          {GESTURES.map((x) => (
            <li key={x.g} className="panel flex flex-col items-center gap-2 px-3 py-4">
              <GestureGlyph g={x.g} className="h-10 w-10 text-neon-cyan" />
              <div className="font-mono text-sm font-bold uppercase tracking-widest text-white">{x.name}</div>
              <div className="text-xs text-slate-400">{x.how}</div>
            </li>
          ))}
        </ul>

        <p className="mt-10 max-w-lg text-sm text-slate-400">
          You&apos;ll need a webcam and room to raise both hands. Stand about 1.5–2 m from the screen.
        </p>
        <PrivacyBadge className="mt-4 sm:hidden" />
      </main>
    </div>
  );
}
