import type { SVGProps } from "react";

type P = SVGProps<SVGSVGElement>;
const base = (p: P) => ({
  width: 20,
  height: 20,
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: 1.9,
  strokeLinecap: "round" as const,
  strokeLinejoin: "round" as const,
  "aria-hidden": true,
  ...p,
});

export const Logo = (p: P) => (
  <svg {...base(p)} viewBox="0 0 64 64" strokeWidth={4}>
    <path d="M14 46 L32 14 L50 46 Z" stroke="#67e8f9" />
    <line x1="6" y1="38" x2="58" y2="38" stroke="#ff3b5c" strokeWidth="3" />
    <circle cx="32" cy="30" r="4" fill="#f472b6" stroke="none" />
  </svg>
);
export const LockIcon = (p: P) => (
  <svg {...base(p)}>
    <rect x="5" y="11" width="14" height="9" rx="2.5" />
    <path d="M8 11V8a4 4 0 0 1 8 0v3" />
  </svg>
);
export const SoundOn = (p: P) => (
  <svg {...base(p)}>
    <path d="M4 10v4h4l5 4V6L8 10H4Z" />
    <path d="M16.5 8.5a5 5 0 0 1 0 7M19 6a8.5 8.5 0 0 1 0 12" />
  </svg>
);
export const SoundOff = (p: P) => (
  <svg {...base(p)}>
    <path d="M4 10v4h4l5 4V6L8 10H4Z" />
    <path d="m17 9 5 6M22 9l-5 6" />
  </svg>
);
export const CloseIcon = (p: P) => (
  <svg {...base(p)}>
    <path d="M6 6l12 12M18 6 6 18" />
  </svg>
);
export const ContrastIcon = (p: P) => (
  <svg {...base(p)}>
    <circle cx="12" cy="12" r="8" />
    <path d="M12 4v16a8 8 0 0 0 0-16Z" fill="currentColor" />
  </svg>
);
export const CheckIcon = (p: P) => (
  <svg {...base(p)} strokeWidth={2.6}>
    <path d="m5 12.5 4.5 4.5L19 7.5" />
  </svg>
);

/** Gesture pictograms (original drawings). */
export function GestureGlyph({ g, className = "h-10 w-10" }: { g: "MOVE_LEFT" | "MOVE_RIGHT" | "JUMP" | "HACK" | "SHIELD"; className?: string }) {
  const common = { className, viewBox: "0 0 48 48", fill: "none", stroke: "currentColor", strokeWidth: 2.6, strokeLinecap: "round" as const, strokeLinejoin: "round" as const, "aria-hidden": true };
  if (g === "MOVE_LEFT" || g === "MOVE_RIGHT")
    return (
      <svg {...common} style={{ transform: g === "MOVE_LEFT" ? "scaleX(-1)" : undefined }}>
        <path d="M6 14h22M22 8l6 6-6 6" />
        <path d="M18 40V26.5a2.5 2.5 0 0 1 5 0V34M23 33V23.5a2.5 2.5 0 0 1 5 0V33M28 33v-7.5a2.5 2.5 0 0 1 5 0V34M33 34v-5a2.5 2.5 0 0 1 5 0v6" />
      </svg>
    );
  if (g === "JUMP")
    return (
      <svg {...common}>
        <circle cx="24" cy="22" r="4.5" />
        <path d="M17 44c0-6 3-10 7-10s7 4 7 10" />
        <path d="M18 30 12 12M30 30l6-18" />
        <path d="M9 9l3-4 3 4M33 9l3-4 3 4" />
      </svg>
    );
  if (g === "HACK")
    return (
      <svg {...common}>
        <path d="M14 30c-2-5 0-12 6-15 5-2.5 10-1 12 2" />
        <path d="M32 17c1 4-2 7-6 7" />
        <circle cx="26.5" cy="23.5" r="2" fill="currentColor" />
        <path d="M14 30c1.5 6 6 10 12 10 7 0 11-5 11-12V19" />
      </svg>
    );
  return (
    <svg {...common}>
      <path d="M17 24V11.5a2.5 2.5 0 0 1 5 0V22M22 21V8.5a2.5 2.5 0 0 1 5 0V22M27 21.5V10.5a2.5 2.5 0 0 1 5 0V24M32 24v-7a2.5 2.5 0 0 1 5 0v11c0 8-5 14-12 14-5.5 0-8.5-2.5-11-7l-4.3-7.6a2.4 2.4 0 0 1 4-2.6L17 29" />
    </svg>
  );
}
