import type { RunStats } from "../game/types";

export interface RunSummary {
  score: number;
  timeMs: number;
  level: number;
  levelsDone: number;
  stats: RunStats;
}

/** successful gestures / (successful + failed attempts), 0..100 */
export const successRate = (s: RunStats) =>
  s.gestures + s.failedAttempts ? Math.round((s.gestures / (s.gestures + s.failedAttempts)) * 100) : 0;
