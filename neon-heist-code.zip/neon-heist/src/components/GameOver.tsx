import StatTile from "./StatTile";
import type { RunSummary } from "./runSummary";

export default function GameOver({ run, onRetry, onMenu }: { run: RunSummary; onRetry: () => void; onMenu: () => void }) {
  return (
    <div className="absolute inset-0 z-30 grid place-items-center bg-black/75 p-4 backdrop-blur-sm">
      <div className="w-full max-w-xl animate-fade-up text-center">
        <p className="font-mono text-xs font-bold tracking-[0.4em] text-danger">ALARM TRIGGERED</p>
        <h2 className="mt-3 font-mono text-5xl font-black tracking-[0.1em] text-white sm:text-6xl">GAME OVER</h2>
        <p className="mt-3 text-lg text-slate-300">&ldquo;Security system detected you.&rdquo;</p>
        <dl className="mt-8 grid grid-cols-2 gap-3 text-left sm:grid-cols-4">
          <StatTile k="Score" v={run.score.toLocaleString("en-US")} />
          <StatTile k="Level" v={`${run.level} / 3`} />
          <StatTile k="Gestures" v={run.stats.gestures} />
          <StatTile k="Errors" v={run.stats.failedAttempts} accent="text-warn" />
        </dl>
        <div className="mt-8 flex flex-col justify-center gap-3 sm:flex-row">
          <button type="button" className="btn-neon" onClick={onRetry}>
            Try again
          </button>
          <button type="button" className="btn-ghost" onClick={onMenu}>
            Main menu
          </button>
        </div>
      </div>
    </div>
  );
}
