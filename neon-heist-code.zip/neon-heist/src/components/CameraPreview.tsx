import { useEffect, type ReactNode, type RefObject } from "react";
import SkeletonOverlay from "./SkeletonOverlay";
import type { TrackingStatus } from "../gestures/gestureController";

/**
 * Live mirrored camera + skeleton overlay. The same element is reused for setup,
 * tutorial (large) and gameplay (small window in the top-right corner).
 */
export default function CameraPreview({
  stream,
  videoRef,
  canvasRef,
  tracking,
  className = "",
  compact = false,
  children,
}: {
  stream: MediaStream | null;
  videoRef: RefObject<HTMLVideoElement | null>;
  canvasRef: RefObject<HTMLCanvasElement | null>;
  tracking: TrackingStatus | null;
  className?: string;
  compact?: boolean;
  children?: ReactNode;
}) {
  useEffect(() => {
    const v = videoRef.current;
    if (!v) return;
    if (v.srcObject !== stream) v.srcObject = stream;
    if (stream) v.play().catch(() => {});
  }, [stream, videoRef]);

  const ok = tracking === "tracking";
  return (
    <div className={`overflow-hidden rounded-2xl border bg-black ${ok ? "border-neon-cyan/40" : tracking ? "border-danger/60" : "border-white/10"} ${className}`}>
      <video
        ref={videoRef}
        className="absolute inset-0 h-full w-full -scale-x-100 object-cover opacity-80"
        autoPlay
        muted
        playsInline
        aria-label="Your camera (mirrored), processed locally"
      />
      <SkeletonOverlay canvasRef={canvasRef} />
      <div className={`absolute left-2 top-2 flex items-center gap-2 ${compact ? "" : "left-3 top-3"}`}>
        <span className={`rounded-md bg-black/70 px-2 py-0.5 font-mono text-[10px] font-bold tracking-[0.2em] text-slate-300 ${compact ? "hidden sm:inline" : ""}`}>CAMERA</span>
        {tracking && (
          <span
            role="status"
            className={`rounded-md bg-black/70 px-2 py-0.5 font-mono text-[10px] font-bold tracking-[0.14em] ${ok ? "text-emerald-300" : "animate-blink text-danger"}`}
          >
            {ok ? "● TRACKING" : tracking === "multiple" ? "⚠ 1 PLAYER ONLY" : "⚠ TRACKING LOST"}
          </span>
        )}
      </div>
      {children}
    </div>
  );
}
