export default function Tile({ k, v, accent = "text-white" }: { k: string; v: string | number; accent?: string }) {
  return (
    <div className="panel px-4 py-3">
      <dt className="hud-label">{k}</dt>
      <dd className={`mt-1 font-mono text-2xl font-bold tabular-nums sm:text-3xl ${accent}`}>{v}</dd>
    </div>
  );
}
