import { formatTime, type StatsSnapshot } from "../storage/statsStorage";

export default function StatsScreen({ stats, onBack, onPlay }: { stats: StatsSnapshot; onBack: () => void; onPlay: () => void }) {
  const tiles: Array<[string, string]> = [
    ["Best score", stats.bestScore.toLocaleString("en-US")],
    ["Best time", stats.bestTimeMs !== null ? formatTime(stats.bestTimeMs) : "—"],
    ["Missions completed", String(stats.missionsCompleted)],
    ["Gesture accuracy", stats.totalRuns ? `${stats.gestureAccuracy}%` : "—"],
  ];
  return (
    <div className="mx-auto min-h-[100dvh] max-w-4xl px-5 py-10">
      <p className="hud-label">Session stats · saved on this device</p>
      <h1 className="mt-2 font-mono text-4xl font-black tracking-[0.1em] text-white">AGENT RECORD</h1>
      <dl className="mt-8 grid grid-cols-2 gap-3 lg:grid-cols-4">
        {tiles.map(([k, v]) => (
          <div key={k} className="panel p-5">
            <dt className="hud-label">{k}</dt>
            <dd className="mt-2 font-mono text-3xl font-bold tabular-nums text-neon-cyan">{v}</dd>
          </div>
        ))}
      </dl>
      <h2 className="hud-label mt-10">Last {Math.min(5, stats.recent.length)} attempts</h2>
      {stats.recent.length === 0 ? (
        <p className="mt-3 text-slate-400">No attempts yet.</p>
      ) : (
        <div className="panel mt-3 overflow-x-auto">
          <table className="w-full min-w-[520px] text-left font-mono text-sm">
            <thead className="text-[11px] uppercase tracking-widest text-slate-500">
              <tr>
                {["Result", "Score", "Time", "Level", "Gestures", "Accuracy"].map((h) => (
                  <th key={h} className="px-4 py-3 font-semibold">
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {stats.recent.map((a) => (
                <tr key={a.id} className="border-t border-white/5">
                  <td className={`px-4 py-3 font-bold ${a.result === "victory" ? "text-emerald-300" : a.result === "gameOver" ? "text-danger" : "text-slate-400"}`}>
                    {a.result === "victory" ? "COMPLETE" : a.result === "gameOver" ? "CAUGHT" : "ABORTED"}
                  </td>
                  <td className="px-4 py-3 tabular-nums">{a.score.toLocaleString("en-US")}</td>
                  <td className="px-4 py-3 tabular-nums">{formatTime(a.timeMs)}</td>
                  <td className="px-4 py-3">{a.level} / 3</td>
                  <td className="px-4 py-3 tabular-nums">{a.gestures}</td>
                  <td className="px-4 py-3 tabular-nums">{a.successRate}%</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      <div className="mt-10 flex flex-wrap gap-3">
        <button type="button" className="btn-neon" onClick={onPlay}>
          Play again
        </button>
        <button type="button" className="btn-ghost" onClick={onBack}>
          Main menu
        </button>
      </div>
    </div>
  );
}
